
/* ===== Kalendar: hafta / oy / yil, 2005–2300 (hisob-kitob asosida, internetsiz) ===== */
(function(){
const A=new Date(2005,0,1),Z=new Date(2300,11,31),L3=(a,b,c)=>[a,b,c];
Object.assign(S,{
cal:L3("Kalendar","Календарь","Takvim"),
calS:L3("Hafta, oy, yil · 2005–2300","Неделя, месяц, год · 2005–2300","Hafta, ay, yıl · 2005–2300"),
cl_rng:L3("Kalendar 2005–2300 yillar oralig’ida","Календарь: 2005–2300 годы","Takvim 2005–2300 yılları arasında"),
cl_plan:L3("📋 Kun rejasi","📋 План дня","📋 Gün planı"),
cl_none:L3("Bu kunga reja yo’q","На этот день планов нет","Bu gün için plan yok"),
cl_hn:L3("🌙 hijriy sana va hayitlar taxminiy (±1 kun)","🌙 дата хиджры и праздники приблизительны (±1 день)","🌙 hicri tarih ve bayramlar yaklaşık (±1 gün)"),
cl_in:L3("{n} kun keyin","через {n} дн.","{n} gün sonra"),
cl_ago:L3("{n} kun oldin","{n} дн. назад","{n} gün önce"),
cl_doy:L3("yilning {n}-kuni","{n}-й день года","yılın {n}. günü"),
cl_wk:L3("{n}-hafta","{n}-я неделя","{n}. hafta")});
const WF=[["Dushanba","Seshanba","Chorshanba","Payshanba","Juma","Shanba","Yakshanba"],["Понедельник","Вторник","Среда","Четверг","Пятница","Суббота","Воскресенье"],["Pazartesi","Salı","Çarşamba","Perşembe","Cuma","Cumartesi","Pazar"]];
const MG=["января","февраля","марта","апреля","мая","июня","июля","августа","сентября","октября","ноября","декабря"];
const HN=[["Muharram","Safar","Rabi’ul-avval","Rabi’ul-oxir","Jumodil-avval","Jumodil-oxir","Rajab","Sha’bon","Ramazon","Shavvol","Zulqa’da","Zulhijja"],["Мухаррам","Сафар","Раби-уль-авваль","Раби-уль-ахир","Джумада-ль-уля","Джумада-ль-ахира","Раджаб","Шаабан","Рамадан","Шавваль","Зуль-каада","Зуль-хиджжа"],["Muharrem","Safer","Rebiülevvel","Rebiülahir","Cemaziyelevvel","Cemaziyelahir","Recep","Şaban","Ramazan","Şevval","Zilkade","Zilhicce"]];
const FH={"1-1":L3("Yangi yil","Новый год","Yılbaşı"),"1-14":L3("Vatan himoyachilari kuni","День защитников Родины","Vatan Savunucuları Günü"),"3-8":L3("Xalqaro xotin-qizlar kuni","Международный женский день","Dünya Kadınlar Günü"),"3-21":L3("Navro’z","Навруз","Nevruz"),"5-9":L3("Xotira va qadrlash kuni","День памяти и почестей","Anma ve Onurlandırma Günü"),"9-1":L3("Mustaqillik kuni","День независимости","Bağımsızlık Günü"),"10-1":L3("O’qituvchi va murabbiylar kuni","День учителей и наставников","Öğretmenler ve Mentorlar Günü"),"12-8":L3("Konstitutsiya kuni","День Конституции","Anayasa Günü")};
const HH={"10-1":L3("Ro’za hayit","Ураза-байрам","Ramazan Bayramı"),"12-10":L3("Qurbon hayit","Курбан-байрам","Kurban Bayramı")};
const CV={m:'m',d:new Date(),s:new Date()};
const pd=k=>{const a=k.split('-').map(Number);return new Date(a[0],a[1]-1,a[2])};
const inR=d=>d>=A&&d<=Z,U=d=>Date.UTC(d.getFullYear(),d.getMonth(),d.getDate());
const hij=d=>{let l=Math.round(U(d)/864e5)+2440588-1948440+10632;const n=Math.floor((l-1)/10631);l=l-10631*n+354;const j=Math.floor((10985-l)/5316)*Math.floor(50*l/17719)+Math.floor(l/5670)*Math.floor(43*l/15238);l=l-Math.floor((30-j)/15)*Math.floor(17719*j/50)-Math.floor(j/16)*Math.floor(15238*j/43)+29;const m=Math.floor(24*l/709);return[30*n+j-30,m,l-Math.floor(709*m/24)]};
const isoW=d=>{const x=new Date(U(d));x.setUTCDate(x.getUTCDate()+4-(x.getUTCDay()||7));return Math.ceil(((x-Date.UTC(x.getUTCFullYear(),0,1))/864e5+1)/7)};
function hol(d){const i=I(),r=[],a=FH[(d.getMonth()+1)+'-'+d.getDate()],h=hij(d),b=HH[h[1]+'-'+h[2]];if(a)r.push(a[i]);if(b)r.push('≈ '+b[i]);return r}
function cell(d,om,mini){if(!inR(d)||(om&&mini))return'<i class="cd x"></i>';const k=dk(d),H=hol(d);
return `<button class="cd${om?' o':''}${(d.getDay()+6)%7>4?' we':''}${H.length?' hl':''}${dI(k).length?' pl':''}${k==dk(new Date())?' td':''}${k==dk(CV.s)?' sel':''}" data-k="${k}">${d.getDate()}</button>`}
function mGrid(y,m,mini){const f=new Date(y,m,1),s=ws(f),n=Math.ceil(((f.getDay()+6)%7+new Date(y,m+1,0).getDate())/7);let h='';
for(let r=0;r<n;r++){const rs=shift('d',s,r*7);if(!mini)h+=`<span class="cw">${isoW(shift('d',rs,3))}</span>`;for(let c=0;c<7;c++){const d=shift('d',rs,c);h+=cell(d,d.getMonth()!=m,mini)}}return h}
const wh=(cl)=>WN[LI()].map((x,i)=>`<span class="cwh${i>4?' we':''}">${cl?x[0]:x}</span>`).join('');
const monthH=()=>`<div class="cg"><span></span>${wh(0)}${mGrid(CV.d.getFullYear(),CV.d.getMonth(),0)}</div>`;
const yearH=()=>{const y=CV.d.getFullYear(),i=I();let h='<div class="yg">';for(let m=0;m<12;m++)h+=`<div class="ym"><button class="yt" data-m="${m}">${MN[i][m]}</button><div class="mg">${wh(1)}${mGrid(y,m,1)}</div></div>`;return h+'</div>'};
function weekH(){const s=ws(CV.d),i=I();let h='';for(let q=0;q<7;q++){const d=shift('d',s,q);if(!inR(d))continue;const k=dk(d),L=dI(k),H=hol(d),j=hij(d);
h+=`<button class="wr${k==dk(new Date())?' td':''}${k==dk(CV.s)?' sel':''}${q>4?' we':''}" data-k="${k}"><div class="wd"><b>${d.getDate()}</b><span>${WN[i][q]}</span></div><div class="wb"><div>${H.map(x=>`<span class="tg h">${esc(x)}</span>`).join('')}<span class="mu" style="font-size:.74rem">🌙 ${j[2]} ${HN[i][j[1]-1]}</span></div>${L.length?L.slice(0,3).map(x=>`<div class="wi${x.done?' dn':''}">${x.time} · ${esc(x.text)}</div>`).join('')+(L.length>3?`<div class="mu">+${L.length-3}</div>`:''):'<div class="mu">—</div>'}</div></button>`}return h}
function detail(){const i=I(),d=CV.s,k=dk(d),H=hol(d),j=hij(d),L=dI(k),n=Math.round((U(d)-U(new Date()))/864e5),y=d.getFullYear(),dy=Math.round((U(d)-Date.UTC(y,0,0))/864e5),ln=Math.round((Date.UTC(y+1,0,0)-Date.UTC(y,0,0))/864e5),
rel=n==0?t('today'):n>0?t('cl_in').replace('{n}',n):t('cl_ago').replace('{n}',-n);
return `<div class="card"><b>${WF[i][(d.getDay()+6)%7]}, ${d.getDate()} ${i==1?MG[d.getMonth()]:MN[i][d.getMonth()]} ${y}</b><div style="margin-top:.5rem"><span class="tg">${rel}</span><span class="tg">${t('cl_doy').replace('{n}',dy)} / ${ln}</span><span class="tg">${t('cl_wk').replace('{n}',isoW(d))}</span><span class="tg">🌙 ${j[2]} ${HN[i][j[1]-1]} ${j[0]}</span></div>${H.map(x=>`<div class="tg h">🎉 ${esc(x)}</div>`).join('')}<div class="mu" style="font-size:.72rem;margin:.2rem 0 .5rem">${t('cl_hn')}</div>${L.length?L.slice(0,10).map(x=>`<div class="wi${x.done?' dn':''}">${x.done?'✅':'•'} ${x.time} · ${esc(x.text)}</div>`).join('')+(L.length>10?`<div class="mu">+${L.length-10}</div>`:''):`<div class="mu">${t('cl_none')}</div>`}<button class="btn pri" data-a="pl" style="width:100%;margin-top:.6rem">${t('cl_plan')}</button></div>`}
function cLab(){const d=CV.d,m=MN[LI()];if(CV.m=='y')return''+d.getFullYear();if(CV.m=='m')return m[d.getMonth()]+' '+d.getFullYear();const a=ws(d),b=shift('d',a,6);return a.getDate()+' '+m[a.getMonth()].slice(0,3)+' – '+b.getDate()+' '+m[b.getMonth()].slice(0,3)+' '+b.getFullYear()}
function selFor(x,md){const T=new Date(),same=md=='y'?x.getFullYear()==T.getFullYear():md=='m'?x.getFullYear()==T.getFullYear()&&x.getMonth()==T.getMonth():dk(ws(x))==dk(ws(T));return same?T:x}
function step(n){const d=CV.d,y=d.getFullYear(),x=CV.m=='w'?shift('d',d,7*n):CV.m=='m'?new Date(y,d.getMonth()+n,1):new Date(y+n,d.getMonth(),1);if(x<A||x>Z){toast(t('cl_rng'));return}CV.d=x;CV.s=selFor(x,CV.m);draw()}
function vCal(){push(()=>t('cal'),b=>{const i=I(),y=CV.d.getFullYear(),m=CV.d.getMonth();let yo='';for(let q=2005;q<=2300;q++)yo+=`<option${q==y?' selected':''}>${q}</option>`;
b.innerHTML=`<div class="cl" id="clw"><div class="seg">${[['w',1],['m',2],['y',3]].map(a=>`<button data-md="${a[0]}" class="${CV.m==a[0]?'on':''}">${t('pn')[a[1]]}</button>`).join('')}</div>
<div class="nv"><button data-st="-1" aria-label="‹">‹</button><button class="lb" data-st="0">${cLab()}${CV.m=='w'?`<small class="mu">${t('cl_wk').replace('{n}',isoW(shift('d',ws(CV.d),3)))}</small>`:''}</button><button data-st="1" aria-label="›">›</button></div>
<div class="sel2"><select id="clY">${yo}</select>${CV.m=='y'?'':`<select id="clM">${MN[i].map((x,q)=>`<option value="${q}"${q==m?' selected':''}>${x}</option>`).join('')}</select>`}</div>${CV.m=='m'?monthH():CV.m=='w'?weekH():yearH()}${detail()}</div>`;
const w=$('#clw'),jump=()=>{const yy=+$('#clY').value,mm=$('#clM')?+$('#clM').value:CV.d.getMonth(),x=CV.m=='w'?new Date(yy,mm,Math.min(CV.d.getDate(),new Date(yy,mm+1,0).getDate())):new Date(yy,mm,1);CV.d=x;CV.s=selFor(x,CV.m);draw()};
$('#clY').onchange=jump;if($('#clM'))$('#clM').onchange=jump;
w.onclick=e=>{const x=e.target.closest('[data-md],[data-st],[data-k],[data-m],[data-a]');if(!x)return;const q=x.dataset;
if(q.md){CV.m=q.md;CV.d=new Date(CV.s);draw();return}
if(q.st!==undefined){if(q.st=='0'){CV.d=new Date();CV.s=new Date();draw()}else step(+q.st);return}
if(q.k){const d=pd(q.k);CV.s=d;CV.d=d;if(CV.m=='y')CV.m='m';draw();return}
if(q.m!==undefined){CV.m='m';CV.d=new Date(CV.d.getFullYear(),+q.m,1);CV.s=selFor(CV.d,'m');draw();return}
if(q.a=='pl'){cur=new Date(CV.s.getFullYear(),CV.s.getMonth(),CV.s.getDate());tp='d';vTime()}};
let X=0,Y=0;w.ontouchstart=e=>{X=e.touches[0].clientX;Y=e.touches[0].clientY};w.ontouchend=e=>{const c=e.changedTouches[0],dx=c.clientX-X,dy=c.clientY-Y;if(Math.abs(dx)>60&&Math.abs(dx)>2*Math.abs(dy))step(dx<0?1:-1)}})}
const G0=GOM;GOM=function(){const o=G0();o.cal=vCal;return o};
applyAll();
})();
