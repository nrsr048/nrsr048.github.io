
/* ===== v11: jonli fon (faqat bosh sahifada, tinch, batareyani tejaydi) ===== */
(function(){
const cv=document.createElement('canvas');cv.id='lw';document.body.insertBefore(cv,document.body.firstChild);
const H=document.getElementById('home'),V=document.getElementById('view'),x=cv.getContext('2d');
if(H){H.style.position='relative';H.style.zIndex='1'}
let W=0,Hh=0,raf=0,last=0,stars=[],shoot=null,nextShoot=0,run=false;
const mode=()=>(D.set&&D.set.lw)||'stars';
const rgb=h=>{h=String(h||'').trim().replace('#','');if(h.length==3)h=h.replace(/(.)/g,'$1$1');const n=parseInt(h,16);return isNaN(n)?[139,92,255]:[n>>16&255,n>>8&255,n&255]};
const col=()=>{const s=getComputedStyle(document.documentElement);return{a:rgb(s.getPropertyValue('--g1')),b:rgb(s.getPropertyValue('--g2')),c:rgb(s.getPropertyValue('--g3')),light:document.documentElement.dataset.theme=='kun'}};
const rg=(c,a)=>'rgba('+c[0]+','+c[1]+','+c[2]+','+a+')';
function size(){const d=.7;W=cv.width=Math.max(2,Math.round(innerWidth*d));Hh=cv.height=Math.max(2,Math.round(innerHeight*d));stars=[];const n=Math.round(W*Hh/5200);for(let i=0;i<n;i++)stars.push({x:Math.random()*W,y:Math.random()*Hh,r:.4+Math.random()*1.3,p:Math.random()*6.28,s:.4+Math.random()*1.2,v:.02+Math.random()*.05})}
function stop(){run=false;cancelAnimationFrame(raf);x.clearRect(0,0,W,Hh)}
function frame(t){if(!run)return;raf=requestAnimationFrame(frame);if(t-last<33)return;const dt=Math.min(.1,(t-last)/1000);last=t;
 if(document.hidden||(V&&V.classList.contains('on'))||mode()=='off'){x.clearRect(0,0,W,Hh);return}
 const C=col(),T=t/1000;x.clearRect(0,0,W,Hh);const m=mode();
 if(m=='stars'){const base=C.light?C.b:[255,255,255];
  stars.forEach(s=>{s.y-=s.v*dt*60*.15;if(s.y<-3){s.y=Hh+3;s.x=Math.random()*W}const a=(.25+.55*(.5+.5*Math.sin(T*s.s+s.p)))*(C.light?.5:1);x.fillStyle=rg(base,a);x.beginPath();x.arc(s.x,s.y,s.r,0,6.283);x.fill()});
  if(!C.light){if(!shoot&&T>nextShoot){shoot={x:Math.random()*W*.8,y:Math.random()*Hh*.4,vx:5+Math.random()*3,vy:2.5+Math.random()*2,l:0};nextShoot=T+9+Math.random()*9}
   if(shoot){const s=shoot;s.x+=s.vx;s.y+=s.vy;s.l++;const g=x.createLinearGradient(s.x,s.y,s.x-s.vx*9,s.y-s.vy*9);g.addColorStop(0,'rgba(255,255,255,.85)');g.addColorStop(1,'rgba(255,255,255,0)');x.strokeStyle=g;x.lineWidth=1.4;x.beginPath();x.moveTo(s.x,s.y);x.lineTo(s.x-s.vx*9,s.y-s.vy*9);x.stroke();if(s.l>55||s.x>W||s.y>Hh)shoot=null}}}
 else if(m=='aurora'){x.globalCompositeOperation=C.light?'source-over':'lighter';[[C.a,.0,.16],[C.b,1.7,.18],[C.c,3.4,.12]].forEach(([c,ph,al],i)=>{const y0=Hh*(.22+i*.14);const g=x.createLinearGradient(0,y0-Hh*.12,0,y0+Hh*.2);g.addColorStop(0,rg(c,0));g.addColorStop(.5,rg(c,al*(C.light?.7:1)));g.addColorStop(1,rg(c,0));x.fillStyle=g;x.beginPath();x.moveTo(0,Hh);for(let px=0;px<=W;px+=8){const yy=y0+Math.sin(px/W*3.2+T*.22+ph)*Hh*.07+Math.sin(px/W*7+T*.13+ph*2)*Hh*.025;x.lineTo(px,yy)}x.lineTo(W,Hh);x.closePath();x.fill()});x.globalCompositeOperation='source-over'}
 else if(m=='waves'){[[C.b,.0,.55,.1],[C.a,2,.62,.12],[C.c,4,.7,.09]].forEach(([c,ph,lv,al])=>{x.fillStyle=rg(c,al*(C.light?.9:1));x.beginPath();x.moveTo(0,Hh);for(let px=0;px<=W;px+=8){x.lineTo(px,Hh*lv+Math.sin(px/W*4.2+T*.35+ph)*Hh*.025+Math.sin(px/W*9+T*.2+ph)*Hh*.01)}x.lineTo(W,Hh);x.closePath();x.fill()})}}
function start(){if(run||mode()=='off'||matchMedia('(prefers-reduced-motion:reduce)').matches)return;run=true;last=0;raf=requestAnimationFrame(frame)}
cv.style.cssText='position:fixed;inset:0;width:100%;height:100%;z-index:0;pointer-events:none';
size();addEventListener('resize',()=>{clearTimeout(size.t);size.t=setTimeout(size,200)});
document.addEventListener('visibilitychange',()=>{document.hidden?stop():start()});
if(V)new MutationObserver(()=>{V.classList.contains('on')?stop():start()}).observe(V,{attributes:true,attributeFilter:['class']});
window.lwApply=()=>{stop();start()};start();
})();
