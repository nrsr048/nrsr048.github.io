
/* ===== Bosh sahifa: guruhlash ===== */
(function(){
const P=(a,b,c)=>(LI()>2&&window.XP&&XP[a]&&XP[a][LI()-3])||[a,b,c][I()],H=document.getElementById('home'),hero=H.querySelector('.hero');
const GR=[[["Reja va vaqt","Планы и время","Plan ve zaman"],['time','cal','clock'],0,['time']],
[["Ibodat va bilim","Вера и знания","İbadet ve bilgi"],['nmz','hemis'],0,['nmz','hemis']],
[["Qidiruv, AI va hisob","Поиск, ИИ и расчёты","Arama, YZ ve hesap"],['srch','ai','trn','beton'],0,[]],
[["Til va o‘qish","Языки и чтение","Dil ve okuma"],['langs','read','lessons','prava'],0,[]],
[["Media","Медиа","Medya"],['music','movies','clips','pics','poem'],0,['poem']],
[["Vositalar","Инструменты","Araçlar"],['calc','notes','exp'],1,[]]];
let last=hero;
GR.forEach(([h,ks,c3,cp])=>{const els=ks.map(k=>H.querySelector('[data-go="'+k+'"]')).filter(Boolean);if(!els.length)return;
const t=document.createElement('h4');t.className='hg';t.dataset.h=JSON.stringify(h);t.textContent=h[I()];
const s=document.createElement('section');s.className='grid grp'+(c3?' g3':'');
els.forEach(e=>{e.classList.remove('w','tc');if(cp.includes(e.dataset.go))e.classList.add('w','tc');s.appendChild(e)});
last.after(t);t.after(s);last=s});
H.querySelectorAll('section.grid').forEach(s=>{if(!s.children.length)s.remove()});{const bt=H.querySelector('[data-go="beton"]');if(bt&&bt.parentNode)bt.parentNode.classList.add('g4')}
const A1=applyAll;applyAll=function(){A1();H.querySelectorAll('.hg').forEach(h=>h.textContent=(window.hdT?hdT(JSON.parse(h.dataset.h)):JSON.parse(h.dataset.h)[I()]))};
/* Vaqt rejimi: keyingi vazifa */
const sm=H.querySelector('[data-go="time"] small');if(sm)sm.removeAttribute('data-k');
function nx(){if(!sm)return;const n=new Date(),hm=String(n.getHours()).padStart(2,'0')+':'+String(n.getMinutes()).padStart(2,'0'),L=dI(dk(n)),u=L.filter(x=>!x.done).sort((a,b)=>(a.time||'99')<(b.time||'99')?-1:1),nt=u.find(x=>x.time&&x.time>=hm)||u[0];
sm.textContent=!L.length?S.timeS[I()]:!u.length?'✅ '+P('Bugungi vazifalar bajarildi','Все задачи на сегодня выполнены','Bugünkü görevler tamam'):P('Keyingi','Далее','Sıradaki')+': '+(nt.time?nt.time+' · ':'')+nt.text}
setInterval(nx,5000);nx();applyAll();
})();
