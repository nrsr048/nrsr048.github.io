/* ===== v7: profil paneli (Sozlamalar, Til, Mavzu, Telefon, Bulut, Akkaunt) ===== */
(function(){
const pT=(a,b,c)=>(LI()>2&&window.XP&&XP[a]&&XP[a][LI()-3])||[a,b,c][I()],cs=()=>{try{return JSON.parse(localStorage.getItem('sr_sb')||'null')}catch(e){return null}},
uid=()=>{let u=localStorage.getItem('sr_uid');if(!u){u=String(Math.floor(1e9+Math.random()*9e9));localStorage.setItem('sr_uid',u)}return u},
nmx=()=>(D.set.nm||'SR').trim()||'SR';
function chip(){const s=cs(),n=nmx();$('#pnm2').textContent=n;$('#pav').style.cssText=D.set.pic?"background-image:url('"+D.set.pic+"');background-size:cover;background-position:center":'';$('#pav').innerHTML=(D.set.pic?'':esc(n[0].toUpperCase()))+`<i class="${s?'on':''}"></i>`;
 $('#pst').textContent='👤 '+(s&&s.em?s.em.split('@')[0]:pT('Profil','Профиль','Profil'))+' ›'}
const row=(r,ic,c,l,v)=>`<button class="prow" data-r="${r}"><i style="background:${c}">${ic}</i><span>${l}</span><em>${esc(v||'')}</em><u>›</u></button>`;
function vProf(){push(()=>pT('Profil','Профиль','Profil'),b=>{const s=cs(),n=nmx(),th=['tun','kun','okean'],ln=['Oʻzbekcha','Русский','Türkçe','English','Тоҷикӣ','Deutsch','한국어'][I()];
 b.innerHTML=`<div class="pf"><div class="av big" data-r="pic" style="${D.set.pic?`background-image:url('${D.set.pic}');background-size:cover;background-position:center`:''}">${D.set.pic?'':esc(n[0].toUpperCase())}<em>📷</em></div>${D.set.pic?`<div class="hh"><b>⏱</b>${pT('Olib tashlash: rasmni bosib turing','Удалить: удерживайте фото','Kaldırmak için fotoğrafa basılı tut')}</div>`:''}<h2 data-r="nm" style="margin:.2rem 0 .5rem">${esc(n)} ✎</h2><div class="idp" data-r="id">ID: ${uid()} 📋</div></div>
<h4 class="sec">${pT('Sizning akkauntingiz','Ваш аккаунт','Hesabınız')}</h4><div class="pcard">${row('cl','☁️','#0ea5e9',pT('Bulut','Облако','Bulut'),s&&s.em?s.em:pT('Kirish','Войти','Giriş'))}${row('ph','📞','#22c55e',pT('Telefon raqam','Номер телефона','Telefon numarası'),D.set.ph||pT('Qo’shish','Добавить','Ekle'))}${row('ac','👤','#a855f7',pT('Akkaunt va zaxira','Аккаунт и резерв','Hesap ve yedek'),'')}</div>
<h4 class="sec">${pT('Umumiy','Общее','Genel')}</h4><div class="pcard">${row('sn','🔊','#ef4444',pT('Ovoz','Звук','Ses'),snDesc())}${row('sc','🛡️','#10b981',pT('Xavfsizlik','Безопасность','Güvenlik'),secDesc())}${row('st','⚙️','#64748b',pT('Sozlamalar','Настройки','Ayarlar'),'')}</div>`;
 b.onclick=e=>{const l=e.target.dataset.l;if(l){setLang(l);return}const r=(e.target.closest('[data-r]')||{dataset:{}}).dataset.r;if(!r)return;
  if(r=='cl')GOM().cloud();else if(r=='ac')GOM().acc();else if(r=='st')vSet();
  else if(r=='sn')vSnd();else if(r=='sc')vSec();
  else if(r=='th'){D.set.theme=th[(th.indexOf(D.set.theme)+1)%3];save();applyAll()}
  else if(r=='ph'){const v=prompt(pT('Telefon raqam','Номер телефона','Telefon numarası'),D.set.ph||'+998');if(v!==null){D.set.ph=v.trim();save();draw()}}
  else if(r=='pic'){if(D.set.pic)window.picMenu();else window.pickPic()}else if(r=='pd'){delete D.set.pic;save();applyAll();draw()}
  else if(r=='nm'){const v=prompt(pT('Ism','Имя','Ad'),nmx());if(v&&v.trim()){D.set.nm=v.trim();save();chip();draw()}}
  else if(r=='id'){try{navigator.clipboard.writeText(uid());toast('✓')}catch(x){}}}})}
$('#pc').onclick=vProf;
const A0=applyAll;applyAll=function(){A0();chip()};chip();setInterval(chip,1500);
})();
