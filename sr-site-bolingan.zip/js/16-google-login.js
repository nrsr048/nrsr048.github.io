/* ===== Google bilan kirish (Supabase OAuth). Qaytganda token #hash da keladi, mavjud kod uni o'zi qabul qiladi. ===== */
document.addEventListener('click',e=>{const b=e.target.closest('#cgo');if(!b)return;e.preventDefault();
  const C=window.SR_CFG||{},back=location.origin+location.pathname;
  location.href=C.SUPABASE_URL+'/auth/v1/authorize?provider=google&redirect_to='+encodeURIComponent(back)},true);
