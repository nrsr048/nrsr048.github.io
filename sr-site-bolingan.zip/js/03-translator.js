/* ===== v6: oflayn tarjimon + dastur ichidagi yordamchi (internetsiz) ===== */
const LTL=[['uz','O’zbekcha'],['ru','Русский'],['tr','Türkçe'],['en','English'],['tg','Тоҷикӣ'],['de','Deutsch'],['ko','한국어']];
const LTn=s=>String(s).toLowerCase().replace(/\u0307/g,'').replace(/[’'ʻ`´]/g,'').replace(/[ıİ]/g,'i').replace(/[çÇ]/g,'c').replace(/[ğĞ]/g,'g').replace(/[öÖ]/g,'o').replace(/[şŞ]/g,'s').replace(/[üÜ]/g,'u').replace(/[âîû]/g,m=>({â:'a',î:'i',û:'u'}[m])).replace(/[.,!?;:«»"()]/g,' ').replace(/\s+/g,' ').trim();
const PH=`Salom|Привет|Merhaba|Hello|Салом|Hallo|안녕하세요
Xayr|До свидания|Hoşça kal|Goodbye|Хайр|Auf Wiedersehen|안녕히 가세요
Xayrli tong|Доброе утро|Günaydın|Good morning|Субҳ ба хайр|Guten Morgen|좋은 아침입니다
Xayrli kech|Добрый вечер|İyi akşamlar|Good evening|Шоми хуш|Guten Abend|좋은 저녁입니다
Xayrli tun|Спокойной ночи|İyi geceler|Good night|Шаби хуш|Gute Nacht|안녕히 주무세요
Rahmat|Спасибо|Teşekkür ederim|Thank you|Ташаккур|Danke|감사합니다
Iltimos|Пожалуйста|Lütfen|Please|Лутфан|Bitte|부탁합니다
Kechirasiz|Извините|Affedersiniz|Excuse me|Бубахшед|Entschuldigung|실례합니다
Ha|Да|Evet|Yes|Ҳа|Ja|네
Yo’q|Нет|Hayır|No|Не|Nein|아니요
Ismingiz nima|Как вас зовут|Adınız nedir|What is your name|Номи шумо чист|Wie heißen Sie|성함이 어떻게 되세요
Ahvollaringiz qalay|Как дела|Nasılsın|How are you|Корҳо чӣ хел|Wie geht es dir|잘 지내요
Yaxshi rahmat|Хорошо спасибо|İyiyim teşekkürler|I am fine thank you|Хуб ташаккур|Gut danke|잘 지내요 감사합니다
Men tushunmayapman|Я не понимаю|Anlamıyorum|I do not understand|Ман намефаҳмам|Ich verstehe nicht|이해하지 못해요
Sekinroq gapiring|Говорите медленнее|Daha yavaş konuşun|Please speak slowly|Оҳистатар гап занед|Sprechen Sie bitte langsamer|천천히 말씀해 주세요
Bu qancha turadi|Сколько это стоит|Bu ne kadar|How much is this|Ин чанд пул аст|Wie viel kostet das|이거 얼마예요
Hojatxona qayerda|Где туалет|Tuvalet nerede|Where is the toilet|Ҳоҷатхона дар куҷост|Wo ist die Toilette|화장실이 어디예요
Menga yordam bering|Помогите мне|Bana yardım edin|Help me|Ба ман кумак кунед|Helfen Sie mir|도와주세요
Men talabaman|Я студент|Ben öğrenciyim|I am a student|Ман донишҷӯ ҳастам|Ich bin Student|저는 대학생입니다
Men O’zbekistondanman|Я из Узбекистана|Özbekistan’danım|I am from Uzbekistan|Ман аз Ӯзбекистон ҳастам|Ich komme aus Usbekistan|저는 우즈베키스탄에서 왔어요
Turkcha o’rganyapman|Я учу турецкий|Türkçe öğreniyorum|I am learning Turkish|Ман туркӣ меомӯзам|Ich lerne Türkisch|저는 터키어를 배우고 있어요
Bugun havo yaxshi|Сегодня хорошая погода|Bugün hava güzel|The weather is nice today|Имрӯз ҳаво хуб аст|Heute ist das Wetter schön|오늘 날씨가 좋아요
Suv bering|Дайте воды|Su verir misiniz|Water please|Об диҳед|Wasser bitte|물 주세요
Men ochman|Я голоден|Acıktım|I am hungry|Ман гурусна ҳастам|Ich habe Hunger|배가 고파요
Men charchadim|Я устал|Yoruldum|I am tired|Ман хаста шудам|Ich bin müde|피곤해요
Ko’rishguncha|До встречи|Görüşürüz|See you later|То дидор|Bis später|또 만나요
Yaxshi kun|Хорошего дня|İyi günler|Have a nice day|Рӯзи хуш|Einen schönen Tag|좋은 하루 되세요
Qayerga ketyapsiz|Куда вы идёте|Nereye gidiyorsunuz|Where are you going|Ба куҷо меравед|Wohin gehen Sie|어디 가세요
Soat necha|Сколько времени|Saat kaç|What time is it|Соат чанд аст|Wie spät ist es|지금 몇 시예요
Xush kelibsiz|Добро пожаловать|Hoş geldiniz|Welcome|Хуш омадед|Willkommen|환영합니다
Men kasalman|Я болен|Hastayım|I am sick|Ман бемор ҳастам|Ich bin krank|아파요
Men sizni tushunaman|Я вас понимаю|Sizi anlıyorum|I understand you|Ман шуморо мефаҳмам|Ich verstehe Sie|이해해요
Maktab|Школа|Okul|School|Мактаб|Schule|학교
Kitob|Книга|Kitap|Book|Китоб|Buch|책
Shahar|Город|Şehir|City|Шаҳр|Stadt|도시
Ish|Работа|İş|Work|Кор|Arbeit|일
Pul|Деньги|Para|Money|Пул|Geld|돈
Kun|День|Gün|Day|Рӯз|Tag|날
Tun|Ночь|Gece|Night|Шаб|Nacht|밤
Vaqt|Время|Zaman|Time|Вақт|Zeit|시간
Odam|Человек|İnsan|Person|Одам|Mensch|사람
Mashina|Машина|Araba|Car|Мошин|Auto|자동차
Telefon|Телефон|Telefon|Phone|Телефон|Telefon|전화기
Ko’cha|Улица|Sokak|Street|Кӯча|Straße|거리
Bozor|Рынок|Pazar|Market|Бозор|Markt|시장
Yangi|Новый|Yeni|New|Нав|Neu|새로운
Katta|Большой|Büyük|Big|Калон|Groß|큰
Kichik|Маленький|Küçük|Small|Хурд|Klein|작은
Chiroyli|Красивый|Güzel|Beautiful|Зебо|Schön|아름다운
Bugun|Сегодня|Bugün|Today|Имрӯз|Heute|오늘
Ertaga|Завтра|Yarın|Tomorrow|Пагоҳ|Morgen|내일
Kecha|Вчера|Dün|Yesterday|Дирӯз|Gestern|어제
Hozir|Сейчас|Şimdi|Now|Ҳоло|Jetzt|지금
Men|Я|Ben|I|Ман|Ich|저는
Sen|Ты|Sen|You|Ту|Du|너
Biz|Мы|Biz|We|Мо|Wir|우리
Siz|Вы|Siz|You (formal)|Шумо|Sie|당신
Salom, men talabaman|Привет, я студент|Merhaba, ben öğrenciyim|Hello, I am a student|Салом, ман донишҷӯ ҳастам|Hallo, ich bin Student|안녕하세요, 저는 대학생입니다
Sevaman|Люблю|Seviyorum|I love|Дӯст медорам|Ich liebe|사랑해요
Qayerda|Где|Nerede|Where|Дар куҷо|Wo|어디
Nima|Что|Ne|What|Чӣ|Was|무엇
Qachon|Когда|Ne zaman|When|Кай|Wann|언제
Nega|Почему|Neden|Why|Чаро|Warum|왜`;
let LTX=null;
function ltBuild(){const M=new Map(),R={},L=LTL.map(x=>x[0]);L.forEach(l=>R[l]=new Map());
 const reg=(e,l,w)=>{if(!w)return;w=String(w).trim();if(!e[l])e[l]=w;const k=LTn(w);if(k&&!R[l].has(k))R[l].set(k,e)};
 const ent=u=>{u=String(u).trim();const k=LTn(u);let e=M.get(k);if(!e){e={};M.set(k,e)}reg(e,'uz',u);return e};
 LS.forEach(l=>{if(l.t){const e=ent(l.t[0]);reg(e,'ru',l.t[1]);reg(e,'tr',l.t[2])}(l.uz||[]).forEach((w,i)=>{const e=ent(w);['en','ru','tg','de','ko'].forEach(g=>reg(e,g,l[g]&&l[g][i]))})});
 PH.split('\n').forEach(r=>{const a=r.split('|');const e=ent(a[0]);['ru','tr','en','tg','de','ko'].forEach((g,i)=>reg(e,g,a[i+1]))});
 trw().forEach(w=>{const alts=String(w[3]).split(/[,;]/).map(x=>x.replace(/\(.*?\)/g,'').trim()).filter(Boolean);alts.forEach(a=>reg(ent(a),'tr',w[2]));if(alts.length)R.tr.set(LTn(w[2]),R.tr.get(LTn(w[2]))||ent(alts[0]))});
 (D.ltc||[]).forEach(c=>{const e={};reg(e,c.f,c.a);reg(e,c.t,c.b)});
 LTX={R};return LTX}
const ltX=()=>LTX||ltBuild();
const SUF={tr:['lerin','larin','ler','lar','den','dan','ten','tan','nin','nun','in','un','de','da','te','ta','im','um','i','u','e','a','yor','mek','mak'],uz:['larni','ning','lar','ni','ga','da','dan','im','si']};
function ltFind(g,w){const R=ltX().R[g];let k=LTn(w),e=R.get(k);if(e)return[e,0];for(const x of(SUF[g]||[])){if(k.length>x.length+2&&k.endsWith(x)){e=R.get(k.slice(0,-x.length));if(e)return[e,1]}}return[null,0]}
function ltDetect(text){const ws=LTn(text).split(' ');let b='uz',bs=0;LTL.forEach(([g])=>{let c=0;ws.forEach(w=>{if(ltX().R[g].has(w))c++});if(c>bs){bs=c;b=g}});return b}
function ltTr(text,f,to){if(f==to)return{out:text,miss:[],found:1,tot:1};const R=ltX().R[f],all=LTn(text);let e=R.get(all);if(e&&e[to])return{out:e[to],miss:[],found:1,tot:1};
 const segs=text.split(/(?<=[.!?\n])/),res=[],miss=[];let found=0,tot=0;
 segs.forEach(sg=>{const m=sg.match(/^(.*?)([.!?\n]*)$/s),ws=m[1].trim().split(/\s+/).filter(Boolean),o=[];let i=0;
  while(i<ws.length){let hit=0;for(let n=Math.min(5,ws.length-i);n>=1;n--){const ph=ws.slice(i,i+n).join(' '),[x,ap]=ltFind(f,ph);if(x&&x[to]){let y=x[to];if(to!='de'&&(o.length||i)&&y.length>1&&y[1]==y[1].toLowerCase())y=y[0].toLowerCase()+y.slice(1);o.push(y);found+=n;tot+=n;i+=n;hit=1;break}}
   if(!hit){o.push(ws[i]);tot++;miss.push(ws[i]);i++}}
  res.push(o.join(' ')+m[2])});
 return{out:res.join(' ').trim(),miss:[...new Set(miss)],found,tot}}
function vTrn(){push(()=>t('x_tr'),b=>{const z=D.trn=D.trn||{f:'uz',t:'tr'},op=v=>LTL.map(l=>`<option value="${l[0]}" ${l[0]==v?'selected':''}>${l[1]}</option>`).join('');
 b.innerHTML=`<div class="add"><select id="tf">${op(z.f)}</select><button class="btn" id="tsw" style="flex:none">⇄</button><select id="tt">${op(z.t)}</select></div><textarea id="ti" style="margin-top:.6rem;min-height:7rem" placeholder="…"></textarea><button class="btn pri" id="tg" style="width:100%;margin-top:.6rem">${t('x_trgo')}</button><div class="card" id="to" style="min-height:4.5rem;white-space:pre-wrap;overflow-wrap:anywhere;margin-top:.6rem"></div><div id="tm" class="chips"></div><div class="row"><button class="btn" id="tsp">🔊</button><button class="btn" id="tcp">📋</button></div><p class="mu">📴 Oflayn: ${ltX().R.uz.size} uz · ${ltX().R.tr.size} tr · ${ltX().R.en.size} en · ${ltX().R.ru.size} ru so‘z/ibora. Topilmagan so‘zni ➕ bilan o‘zingiz qo‘shing.</p>`;
 const sv=()=>{z.f=$('#tf').value;z.t=$('#tt').value;save()};$('#tf').onchange=$('#tt').onchange=sv;
 const go=()=>{const q=$('#ti').value.trim();if(!q)return;sv();const r=ltTr(q,z.f,z.t);$('#to').textContent=r.out;$('#tm').innerHTML=r.miss.length?`<span class="mu" style="width:100%">${r.found}/${r.tot} · ➕</span>`+r.miss.slice(0,8).map(w=>`<button data-w="${esc(w)}">➕ ${esc(w)}</button>`).join(''):'';};
 $('#tg').onclick=go;
 $('#tm').onclick=e=>{const w=e.target.dataset.w;if(!w)return;const v=prompt(`“${w}” → ${z.t.toUpperCase()}`);if(v&&v.trim()){D.ltc=D.ltc||[];D.ltc.push({f:z.f,a:w,t:z.t,b:v.trim()});save();LTX=null;go()}};
 $('#tsw').onclick=()=>{const a=$('#tf').value;$('#tf').value=$('#tt').value;$('#tt').value=a;const o=$('#to').textContent;if(o)$('#ti').value=o;sv();go()};
 $('#tsp').onclick=()=>{const o=$('#to').textContent;if(o)speak(o,z.t)};$('#tcp').onclick=()=>{try{navigator.clipboard.writeText($('#to').textContent);toast('✓')}catch(e){}}})}
/* --- Dastur ichidagi yordamchi (internet va API kalit kerak emas) --- */
const LNM={turkcha:'tr',ruscha:'ru',inglizcha:'en',tojikcha:'tg',nemischa:'de',koreyscha:'ko',ozbekcha:'uz'},FL={uz:'🇺🇿',ru:'🇷🇺',tr:'🇹🇷',en:'🇬🇧',tg:'🇹🇯',de:'🇩🇪',ko:'🇰🇷'};
function ltAll(w){const R=ltX().R;for(const g of['uz','tr','ru','en','tg','de','ko']){const[e]=ltFind(g,w);if(e)return LTL.filter(l=>e[l[0]]).map(l=>FL[l[0]]+' '+e[l[0]]).join('\n')}return''}
function aiLocal(q){const raw=q.trim(),n=LTn(raw),now=new Date(),has=re=>re.test(n);
 try{const e=raw.replace(/,/g,'.').replace(/[xX]/g,'*');if(/\d/.test(e)&&/[+\-*/%×÷^−]/.test(e)&&/^[\d\s+\-*/().%×÷−]+$/.test(e)){const v=calc(e);if(isFinite(v))return'🧮 '+raw+' = '+(+v.toPrecision(12))}}catch(x){}
 if(has(/\b(dars|jadval|para)\b/)){const k=isoX(),add=has(/ertaga/)?1:0,d=new Date(now.getTime()+add*864e5),iso=new Date(d-d.getTimezoneOffset()*6e4).toISOString().slice(0,10),j=JD.find(x=>x[2]==iso);
  if(!j)return'📅 '+iso+' uchun dars jadvali kiritilmagan. Bor kunlar: '+JD.map(x=>x[1]).join('; ');
  return'📅 '+j[0]+', '+j[1]+'\n'+j[3].map(p=>`${p[5]} · ${p[0]}-para · ${p[1]} (${p[3]}, ${p[2]}, ${p[4]})`).join('\n')}
 if(has(/\b(xarajat|sarf|harajat)/)){const ks=days('m',now),tot=eSum(ks),td=eSum([dk(now)]);return`💸 Bugun: ${nf(td)} so‘m\nShu oy: ${nf(tot)} so‘m${D.budget?`\nByudjet: ${nf(D.budget)} (${Math.round(tot/D.budget*100)}%)`:''}`}
 if(has(/\b(ish|ishlar|reja|vazifa|topshiriq)/)){const L=dI(dk(now)),H=(D.hm&&D.hm.tasks||[]).filter(x=>!x.x);return'📝 Bugungi reja:\n'+(L.length?L.map(x=>(x.done?'✅ ':'⬜ ')+x.time+' '+x.text).join('\n'):'— yo‘q')+(H.length?'\n\n🎓 Topshiriqlar:\n'+H.map(x=>'• '+x.t+(x.d?' ('+x.d+')':'')).join('\n'):'')}
 if(has(/\b(soat|sana|bugun qaysi|vaqt)\b/)&&!has(/soat necha.*(turk|rus|ingliz)/))return'🕒 '+WN[0][(now.getDay()+6)%7]+', '+now.getDate()+' '+MN[0][now.getMonth()]+' '+now.getFullYear()+', '+pad(now.getHours())+':'+pad(now.getMinutes());
 let m=n.match(/^(?:tarjima|перевод|translate|cevir)\s*(.+)$/);if(m){const tx=raw.replace(/^\S+\s*[:\-]?\s*/,''),f=ltDetect(tx),to=f=='uz'?'tr':'uz',r=ltTr(tx,f,to);return`${FL[f]}→${FL[to]}\n${r.out}\n(${r.found}/${r.tot})`}
 m=n.match(/^(.+?) (turkcha|ruscha|inglizcha|tojikcha|nemischa|koreyscha|ozbekcha)\b/);if(m){const f=ltDetect(m[1]),to=LNM[m[2]],r=ltTr(raw.slice(0,raw.toLowerCase().lastIndexOf(m[2].slice(0,3))).trim()||m[1],f,to);return`${FL[to]} ${r.out}`+(r.miss.length?`\n❔ topilmadi: ${r.miss.join(', ')}`:'')}
 const core=n.replace(/ (nima|qanday|degani|manosi|deyiladi|nimani anglatadi)$/,'');if(core.split(' ').length<=5){const a=ltAll(core);if(a)return'📖 '+core+'\n'+a}
 const tk=core.split(' ').filter(w=>w.length>2&&!/^(qoida|qoidasi|grammatika|haqida|menga|tushuntir|tushuntiring|ayt|ayting)$/.test(w));
 if(tk.length){const sc=Object.entries(GR).flatMap(([k,a])=>a.map(g=>({g,k,s:tk.reduce((s,w)=>s+(LTn(g.t).includes(w)?3:0)+(LTn(g.r+' '+(g.f||'')).includes(w)?1:0),0)}))).filter(x=>x.s>=3).sort((a,b)=>b.s-a.s).slice(0,2);
  if(sc.length)return sc.map(x=>`📘 ${x.k} · ${x.g.t}\n${x.g.r}${x.g.f?'\n➡ '+x.g.f:''}${x.g.e&&x.g.e[0]?'\n💬 '+x.g.e.slice(0,2).map(y=>y[0]+' — '+y[1]).join('\n💬 '):''}`).join('\n\n')}
 return'🤖 Men dastur ichidagi yordamchiman (internetsiz). So‘rang:\n• “salom turkcha”, “su nima”, “tarjima: men talabaman”\n• “geniş zaman qoidasi”\n• “bugungi dars jadvali”, “xarajat”, “bugungi ish”\n• “12*(5+3)”'}
function vAI(){push(()=>t('x_ai'),b=>{if(!AH.length)AH.push({role:'assistant',content:'👋 Salom! Men SR ichidagi yordamchiman — internet va API kalit kerak emas. Turkcha qoidalar, lug‘at, tarjima, dars jadvali, reja va hisob-kitob bo‘yicha so‘rang.'});
 b.innerHTML=`<div class="ai"><div id="ch"></div><div class="chips" id="qc" style="margin:.6rem 0"></div></div><div class="add" style="position:sticky;bottom:0;background:var(--bg);padding:.5rem 0"><input id="cq" placeholder="${t('x_ask')}"><button class="btn pri" id="cs">➤</button><button class="btn" id="cc">🗑</button></div>`;
 const paint=()=>{$('#ch').innerHTML=AH.map(m=>`<div class="card ${m.role=='user'?'me':''}" style="white-space:pre-wrap;overflow-wrap:anywhere;${m.role=='user'?'':'border-left:4px solid var(--g3)'}">${esc(m.content)}</div>`).join('');b.scrollTop=b.scrollHeight};
 $('#qc').innerHTML=['salom turkcha','geniş zaman qoidasi','bugungi dars jadvali','12*(5+3)'].map(x=>`<button data-q="${esc(x)}">${esc(x)}</button>`).join('');
 const send=q=>{q=(q||$('#cq').value).trim();if(!q)return;$('#cq').value='';AH.push({role:'user',content:q});let a;try{a=aiLocal(q)}catch(e){a='⚠ '+e.message}AH.push({role:'assistant',content:a});paint();sfx('ok')};
 $('#qc').onclick=e=>{if(e.target.dataset.q)send(e.target.dataset.q)};$('#cs').onclick=()=>send();$('#cq').onkeydown=e=>{if(e.key=='Enter')send()};$('#cc').onclick=()=>{AH=[];draw()};paint()})}
Object.assign(S,{x_aiS:A3('Dastur ichida · internetsiz','Внутри приложения · офлайн','Uygulama içinde · çevrimdışı'),x_trS:A3('Oflayn · 7 til · baza','Офлайн · 7 языков · база','Çevrimdışı · 7 dil · veritabanı')});
function GOM(){return{srch:vSrch,time:vTime,langs:vLangs,notes:vNotes,read:vRead,exp:vExp,music:()=>vLib('music','🎧'),lessons:SO('lessons','🎓'),beton:()=>window.vBeton(),prava:SO('prava','🚗'),movies:()=>vLib('movies','🎬'),clips:()=>vLib('clips','📹'),calc:vCalc,ai:vAI,trn:vTrn,hemis:vHemis,pics:vPics,poem:vPoems,acc:vAcc}}
applyAll();
