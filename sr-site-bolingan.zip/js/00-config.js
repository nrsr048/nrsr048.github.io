/* Bitta joyda sozlamalar (yangi kod shu yerdan o'qiydi). Kalit "publishable" — ochiq bo'lishi mumkin; maxfiy kalitlarni (Brave, Claude) bu yerga YOZMANG. */
window.SR_CFG={SUPABASE_URL:'https://olqnhjokpufudfqyenwx.supabase.co',SUPABASE_KEY:'sb_publishable_QeOKzQgDKSV9nNoQj99M7w_tdcWHUs_',SEARCH_FN:'search'};
