
/* ===== Profil rasmi: bosib turib o'chirish (halqa to'lguncha), "Qaytarish" bilan ===== */
(function(){
const T=(a,b,c)=>[a,b,c][I()],HOLD=900;
window.picMenu=function(){window.pickPic()};            // oddiy bosish = rasmni almashtirish
let st=null,block=0;
function reset(el){if(!el)return;el.classList.remove('holding');el.style.removeProperty('--p');el.style.filter='';el.style.opacity='';el.style.transform='';}
function burst(el){const r=el.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,col=['#f87171','#fbbf24','#1cb0f6','#a78bfa','#34d399'];
 for(let i=0;i<18;i++){const d=document.createElement('i');d.style.cssText=`position:fixed;left:${cx}px;top:${cy}px;width:${6+Math.random()*6}px;height:${6+Math.random()*6}px;border-radius:50%;background:${col[i%5]};z-index:10001;pointer-events:none`;document.body.appendChild(d);
  const a=Math.random()*6.283,k=70+Math.random()*90;d.animate([{transform:'translate(-50%,-50%) scale(1)',opacity:1},{transform:`translate(calc(-50% + ${Math.cos(a)*k}px),calc(-50% + ${Math.sin(a)*k}px)) scale(.2)`,opacity:0}],{duration:650+Math.random()*250,easing:'cubic-bezier(.2,.7,.3,1)'}).onfinish=()=>d.remove()}}
function undoBar(old){const o=document.querySelector('.snk');if(o)o.remove();const n=document.createElement('div');n.className='snk';n.innerHTML='<span>🗑 '+T('Rasm olib tashlandi','Фото удалено','Fotoğraf kaldırıldı')+'</span><button>↩ '+T('Qaytarish','Вернуть','Geri al')+'</button>';document.body.appendChild(n);
 requestAnimationFrame(()=>n.classList.add('on'));let done=0;const close=()=>{n.classList.remove('on');setTimeout(()=>n.remove(),300)};
 n.querySelector('button').onclick=()=>{if(done)return;done=1;D.set.pic=old;save();applyAll();draw();close()};setTimeout(()=>{if(!done){done=1;close()}},6000)}
function finish(el){const old=D.set.pic;if(!old)return;block=Date.now();try{navigator.vibrate&&navigator.vibrate(40)}catch(e){}burst(el);
 el.animate([{transform:'scale(.85)',opacity:.4},{transform:'scale(.2)',opacity:0}],{duration:260,fill:'forwards'}).onfinish=()=>{delete D.set.pic;save();applyAll();draw();undoBar(old)}}
function stop(){if(!st)return;cancelAnimationFrame(st.raf);if(!st.done)reset(st.el);st=null}
document.addEventListener('pointerdown',e=>{const el=e.target.closest&&e.target.closest('.av.big');if(!el||!D.set.pic||st)return;
 if(!el.querySelector('.hr')){const r=document.createElement('span');r.className='hr';el.appendChild(r)}
 st={el,t0:performance.now(),x:e.clientX,y:e.clientY,done:0};
 const step=now=>{if(!st||st.el!==el)return;const p=Math.min(1,(now-st.t0)/HOLD);if(p>.12)el.classList.add('holding');el.style.setProperty('--p',p*100);el.style.filter=`blur(${p*3}px)`;el.style.opacity=1-p*.55;el.style.transform=`scale(${1-p*.08})`;
  if(p>=1){st.done=1;const s=st;st=null;reset(el);finish(el)}else st.raf=requestAnimationFrame(step)};
 st.raf=requestAnimationFrame(step)},true);
document.addEventListener('pointermove',e=>{if(st&&Math.hypot(e.clientX-st.x,e.clientY-st.y)>14)stop()},true);
['pointerup','pointercancel','pointerleave'].forEach(n=>document.addEventListener(n,stop,true));
document.addEventListener('contextmenu',e=>{if(e.target.closest&&e.target.closest('.av.big'))e.preventDefault()},true);
document.addEventListener('click',e=>{if(Date.now()-block<700&&e.target.closest&&e.target.closest('.av.big')){e.stopPropagation();e.preventDefault()}},true);
})();
