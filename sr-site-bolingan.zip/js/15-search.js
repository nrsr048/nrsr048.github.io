/* ===== Qidiruv: Brave Search API (Supabase Edge Function orqali), natijalar o'zimizning dizaynda ===== */
(function(){
const C=window.SR_CFG||{},LSG=k=>{try{return localStorage.getItem(k)}catch(e){return null}},LSS=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
const T=(a,b,c)=>[a,b,c][Math.min(typeof I=='function'?I():0,2)];
const E=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const snip=h=>{let on=false;return E(String(h||'').replace(/<\/?strong>/gi,'\u0001').replace(/<[^>]*>/g,'')).replace(/\u0001/g,()=>(on=!on)?'<b>':'</b>')+(on?'</b>':'')};
const hist=()=>{try{return JSON.parse(LSG('sr_sq')||'[]')}catch(e){return[]}};
const addH=q=>{const h=hist().filter(x=>x!=q);h.unshift(q);LSS('sr_sq',JSON.stringify(h.slice(0,8)))};
async function call(q,page){
  let s;try{s=await window.srSess()}catch(e){throw Object.assign(new Error('auth'),{code:'auth'})}
  const r=await fetch(C.SUPABASE_URL+'/functions/v1/'+(C.SEARCH_FN||'search'),{method:'POST',headers:{apikey:C.SUPABASE_KEY,Authorization:'Bearer '+s.at,'Content-Type':'application/json'},body:JSON.stringify({q,page,lang:['uz','ru','tr'][Math.min(I(),2)]})});
  let j=null;try{j=await r.json()}catch(e){}
  if(r.status===404)throw Object.assign(new Error('nofn'),{code:'nofn'});
  if(!r.ok)throw new Error((j&&(j.error||j.message))||('HTTP '+r.status));
  return j}
function card(x){
  const host=x.host||(()=>{try{return new URL(x.url).hostname}catch(e){return ''}})();
  return `<div class="card srr"><div class="srh"><img src="https://www.google.com/s2/favicons?domain=${E(host)}&sz=32" alt="" width="16" height="16" loading="lazy"><span>${E(host)}</span>${x.age?`<em>${E(x.age)}</em>`:''}</div><a class="srt" href="${E(x.url)}" target="_blank" rel="noopener">${E(x.title)}</a><p class="srd">${snip(x.desc)}</p></div>`}
function vSearchBrave(q0){
  push(()=>T('Qidiruv','Поиск','Arama'),b=>{
    b.innerHTML=`<form id="bsf" class="row" style="gap:.5rem;align-items:center"><input id="bsq" type="search" enterkeyhint="search" autocomplete="off" placeholder="🔎 ${T('Nima qidiramiz?','Что ищем?','Ne arıyoruz?')}" style="flex:1"><button class="btn pri" type="submit" style="flex:none">🔎</button></form><div id="bsh" class="row" style="flex-wrap:wrap;gap:.4rem;margin:.6rem 0"></div><div id="bsr"></div><div id="bsm"></div><div class="row" style="gap:.5rem;margin-top:.8rem"><a class="btn" id="bsg" target="_blank" rel="noopener" style="flex:1;text-align:center;text-decoration:none">Google ↗</a><a class="btn" id="bsy" target="_blank" rel="noopener" style="flex:1;text-align:center;text-decoration:none">Yandex ↗</a></div>`;
    const q$=$('#bsq'),R=$('#bsr'),M=$('#bsm');let cur='',page=0,busy=0;
    const links=()=>{const e=encodeURIComponent(q$.value.trim()||cur);$('#bsg').href='https://www.google.com/search?q='+e;$('#bsy').href='https://yandex.com/search/?text='+e};
    const chips=()=>{$('#bsh').innerHTML=hist().map(h=>`<button type="button" class="btn" data-h="${E(h)}" style="padding:.35rem .7rem;font-size:.85rem">🕘 ${E(h)}</button>`).join('')};
    const help=(code)=>{const m={auth:[T('Qidiruv uchun avval akkauntga kiring (☁ Bulut).','Для поиска войдите в аккаунт (☁ Облако).','Arama için önce hesaba girin (☁ Bulut).'),1],nofn:[T('Qidiruv serveri hali ulanmagan. docs/SOZLASH.md dagi 3-qadamni bajaring (Edge Function “search”).','Сервер поиска ещё не подключён. Выполните шаг 3 из docs/SOZLASH.md.','Arama sunucusu bağlı değil. docs/SOZLASH.md 3. adımı yapın.'),0]}[code];return m};
    async function run(q,more){
      if(busy)return;q=q.trim();if(!q)return;busy=1;if(!more){page=0;R.innerHTML='';cur=q;addH(q);chips()}
      M.innerHTML=`<p class="mu" style="text-align:center">…</p>`;links();
      try{const j=await call(q,page),a=j.results||[];
        if(!a.length&&!more)R.innerHTML=`<div class="emp"><i>🔎</i>${T('Hech narsa topilmadi','Ничего не найдено','Sonuç yok')}</div>`;
        else R.insertAdjacentHTML('beforeend',a.map(card).join(''));
        M.innerHTML=a.length>=10&&page<8?`<button class="btn" id="bmo" style="width:100%">${T('Yana ko‘rsatish','Показать ещё','Daha fazla')}</button>`:'';page++;
        const mo=$('#bmo');if(mo)mo.onclick=()=>run(cur,1)}
      catch(e){const h=help(e.code);M.innerHTML=`<div class="card" style="border-color:#ef4444"><b>⚠ ${E(h?h[0]:e.message)}</b>${h&&h[1]?`<button class="btn pri" id="bco" style="margin-top:.6rem">☁ ${T('Kirish','Войти','Giriş')}</button>`:''}</div>`;const bc=$('#bco');if(bc)bc.onclick=()=>{try{GOM().cloud()}catch(x){}}}
      busy=0}
    $('#bsf').onsubmit=e=>{e.preventDefault();run(q$.value,0);q$.blur()};q$.oninput=links;
    $('#bsh').onclick=e=>{const h=e.target.dataset.h;if(h){q$.value=h;run(h,0)}};
    chips();links();if(q0){q$.value=q0;run(q0,0)}else q$.focus()})}
window.srSearch=q=>vSearchBrave(q);window.vSearchBrave=vSearchBrave;
const G1=GOM;GOM=function(){const o=G1();o.srch=()=>vSearchBrave();return o};
})();
