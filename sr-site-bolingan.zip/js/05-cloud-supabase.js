
/* ===== Bulut (Supabase): kirish + zaxira saqlash/tiklash ===== */
(function(){
window.__H0=location.hash;const U='https://olqnhjokpufudfqyenwx.supabase.co',K='sb_publishable_QeOKzQgDKSV9nNoQj99M7w_tdcWHUs_',SK='sr_sb',L3=(a,b,c)=>[a,b,c],T=(a,b,c)=>[a,b,c][I()];
Object.assign(S,{cloud:L3("Bulut","Облако","Bulut"),cloudS:L3("Zaxira · Supabase","Резерв · Supabase","Yedek · Supabase")});
const ld=()=>{try{return JSON.parse(localStorage.getItem(SK)||'null')}catch(e){return null}};
const sv=s=>{try{s?localStorage.setItem(SK,JSON.stringify(s)):localStorage.removeItem(SK)}catch(e){}};
async function api(p,o){o=o||{};const r=await fetch(U+p,{method:o.m||'GET',headers:Object.assign({apikey:K,'Content-Type':'application/json'},o.h||{}),body:o.b?JSON.stringify(o.b):undefined});let j=null;try{j=await r.json()}catch(e){}
if(!r.ok)throw new Error((j&&(j.error_description||j.msg||j.message||j.error))||('HTTP '+r.status));return j}
const keep=j=>{if(j&&j.access_token){const s={at:j.access_token,rt:j.refresh_token,id:j.user&&j.user.id,em:j.user&&j.user.email,exp:Date.now()+(j.expires_in||3600)*1000-60000};sv(s);return s}return null};
async function sess(){let s=ld();if(!s)throw new Error(T("Avval kiring","Сначала войдите","Önce giriş yapın"));if(Date.now()>s.exp){try{s=keep(await api('/auth/v1/token?grant_type=refresh_token',{m:'POST',b:{refresh_token:s.rt}}))}catch(e){if(navigator.onLine===false||/fetch|network|load failed|timeout/i.test(String(e&&e.message)))throw new Error(T("Internet yo‘q","Нет интернета","İnternet yok"));sv(null);throw new Error(T("Seans tugadi, qayta kiring","Сессия истекла, войдите снова","Oturum bitti, tekrar girin"))}}return s}
async function auth(em,pw,reg){const s=keep(await api(reg?'/auth/v1/signup':'/auth/v1/token?grant_type=password',{m:'POST',b:{email:em,password:pw}}));if(!s)throw new Error(T("Emailga xat yuborildi: tasdiqlang, keyin kiring","Письмо отправлено: подтвердите почту и войдите","E-postaya mesaj gitti: onaylayıp giriş yapın"));return s}
async function up(){const s=await sess(),d=JSON.parse(JSON.stringify(D));if(d.ai)d.ai.key='';const x={};xks().forEach(k=>{const v=LS(k);if(v!=null)x[k]=v});{const bi=LS('betonImg');if(bi&&bi.length<2e6)x.betonImg=bi}d.__x=x;const t=Date.now();await api('/rest/v1/sr_backup?on_conflict=user_id',{m:'POST',h:{Authorization:'Bearer '+s.at,Prefer:'resolution=merge-duplicates,return=minimal'},b:{user_id:s.id,data:d,updated_at:new Date(t).toISOString()}});return t} async function down(){const s=await sess(),j=await api('/rest/v1/sr_backup?select=data,updated_at&user_id=eq.'+s.id,{h:{Authorization:'Bearer '+s.at}});if(!j||!j.length)throw new Error(T("Bulutda zaxira yo’q","В облаке нет копии","Bulutta yedek yok"));return j[0]}
const kb=n=>n>1048576?(n/1048576).toFixed(1)+' MB':Math.max(1,Math.round(n/1024))+' KB',hs=()=>{const j=JSON.stringify(D)+xks().concat(['betonImg']).map(k=>LS(k)||'').join('|');let h=5381;for(let i=0;i<j.length;i++)h=((h<<5)+h+j.charCodeAt(i))|0;return j.length+':'+h},LS=(k,v)=>{try{return v===undefined?localStorage.getItem(k):localStorage.setItem(k,v)}catch(e){}};
const XK=['srt3','srd1','srst','betonS2','betonEnc','sr_profiles'];const xks=()=>{let a=XK.slice();try{Object.keys(localStorage).forEach(k=>{if(/^sr_app_v1_/.test(k))a.push(k)})}catch(e){}return a};
async function doUp(){const t=await up();LS('sr_sb_t',new Date().toLocaleString());LS('sr_sb_h',hs());LS('sr_sb_c',String(t))}
function applyCloud(r){const k=D.ai&&D.ai.key,x=r.data.__x||{},d=Object.assign({set:{lang:'uz',theme:'tun',fs:1},tasks:[],notes:[],timer:{total:1500,left:1500,run:false,endAt:0}},r.data);delete d.__x;Object.keys(D).forEach(q=>delete D[q]);Object.assign(D,d);D.set=Object.assign({lang:'uz',theme:'tun',fs:1},D.set);if(D.ai)D.ai.key=k||'';save();Object.keys(x).forEach(q=>{if(x[q]!=null)LS(q,x[q])});LS('sr_sb_h',hs());LS('sr_sb_c',String(Date.parse(r.updated_at)));LS('sr_sb_t',new Date().toLocaleString());LS('sr_sb_rs','1');location.reload()}
async function cT(){const s=await sess(),j=await api('/rest/v1/sr_backup?select=updated_at&user_id=eq.'+s.id,{h:{Authorization:'Bearer '+s.at}});return j&&j.length?Date.parse(j[0].updated_at):0}
let _bz=0;
async function pull(f){if(_bz||!ld()||(!f&&LS('sr_auto')==='0'))return;_bz=1;try{const ct=await cT(),lc=+LS('sr_sb_c')||0;let ch=hs()!==LS('sr_sb_h');if(LS('sr_sb_rs')){LS('sr_sb_rs','');ch=false;LS('sr_sb_h',hs())}
if(!ct){if(ch||!LS('sr_sb_h'))await doUp();return}
if(ct===lc){if(ch)await doUp();return}
const r=await down(),fresh=JSON.stringify(D).length<1500&&!LS('sr_sb_h');
if(!ch||fresh){applyCloud(r);return}
if(confirm(T("Bulutda boshqa qurilmadan yangiroq ma’lumot bor.\nOK — bulutdagini olish\nBekor — bu qurilmadagini saqlash","В облаке более новые данные с другого устройства.\nOK — взять из облака\nОтмена — сохранить с этого устройства","Bulutta başka cihazdan daha yeni veri var.\nTamam — buluttakini al\nİptal — bu cihazdakini kaydet")))applyCloud(r);else await doUp()}catch(e){}finally{_bz=0}}
window.syncX=pull;window.srSess=sess;setInterval(()=>{try{if(document.hidden||!ld()||LS('sr_auto')==='0'||_bz)return;if(hs()!==LS('sr_sb_h')){clearTimeout(window._ast);window._ast=setTimeout(()=>pull(),2500)}}catch(e){}},7000);setInterval(pull,120000);setInterval(()=>mAuto(),600000);document.addEventListener('visibilitychange',()=>{pull();if(!document.hidden)mAuto()});setTimeout(()=>pull().then(()=>mAuto()),1500);
const CN={notes:'📝 Eslatmalar',tasks:'✅ Vazifalar',goals:'🎯 Maqsadlar',pics:'🖼 Rasmlar',music:'🎧 Musiqa',movies:'🎬 Kinolar',clips:'📹 Videolar',poems:'📖 She’rlar',exp:'💰 Xarajatlar',set:'⚙️ Sozlamalar',ai:'🤖 Sun’iy intellekt',lib:'📚 Kutubxona',cal:'📅 Kalendar',prava:'🚗 Prava',timer:'⏱ Taymer',lock:'🔒 Qulf',hm:'🏠 Bosh sahifa',acc:'👤 Akkaunt'};
let AM='in',AMSG='';
const ER=m=>{m=String(m||'');const x=m.toLowerCase();
if(x.includes('invalid login'))return T("Email yoki parol noto‘g‘ri","Неверный email или пароль","E-posta veya parola hatalı");
if(x.includes('not confirmed'))return T("Email tasdiqlanmagan: pochtadagi xatdagi havolani bosing","Email не подтверждён: нажмите ссылку в письме","E-posta onaylanmadı: mesajdaki bağlantıya tıklayın");
if(x.includes('already'))return T("Bu email ro‘yxatdan o‘tgan: «Kirish» ni bosing","Этот email уже зарегистрирован: нажмите «Вход»","Bu e-posta kayıtlı: «Giriş» yapın");
if(x.includes('rate limit')||x.includes('too many')||x.includes('security purposes'))return T("Juda ko‘p urinish. 1 daqiqa kutib qayta urining","Слишком много попыток. Подождите минуту","Çok fazla deneme. Bir dakika bekleyin");
if(x.includes('weak')||x.includes('password should'))return T("Parol juda oddiy. Harf va raqam ishlating","Пароль слишком простой","Parola çok basit");
if(x.includes('different from the old')||x.includes('same password'))return T("Yangi parol eskisidan farq qilsin","Новый пароль должен отличаться","Yeni parola farklı olmalı");
if(x.includes('expired')||x.includes('invalid'))return T("Kod yoki havola noto‘g‘ri yoki eskirgan. Qayta yuboring","Код или ссылка неверны или устарели","Kod veya bağlantı hatalı ya da eskimiş");
if(x.includes('fetch')||x.includes('network'))return T("Internet yo‘q yoki ulanib bo‘lmadi","Нет интернета","İnternet yok");
return m};
const pwSc=p=>(p.length>=8)+(/[A-Z]/.test(p)&&/[a-z]/.test(p))+(/\d/.test(p)&&/[A-Za-z]/.test(p))+(/[^A-Za-z0-9]/.test(p));
const rdr=()=>'?redirect_to='+encodeURIComponent(location.origin+location.pathname);
function authUI(b,R){const sm=AM=='up',fg=AM=='fp',rs=AM=='rs';
const pwf=(id,ph)=>`<div class="pw"><input id="${id}" data-pw type="password" autocomplete="${sm||rs?'new-password':'current-password'}" placeholder="${ph}"><button type="button" class="eye" data-e>👁</button></div>`;
const P1=T("Parol","Пароль","Parola"),P2=T("Yangi parol (8+, harf va raqam)","Новый пароль (8+, буквы и цифры)","Yeni parola (8+, harf ve rakam)"),P3=T("Parolni takrorlang","Повторите пароль","Parolayı tekrarlayın");
const H=rs?[T("Yangi parol o‘rnating","Задайте новый пароль","Yeni parola belirleyin"),'🔑']:fg?[T("Parolni tiklash","Восстановление пароля","Parola sıfırlama"),'🔑']:sm?[T("Yangi akkaunt yarating","Создайте аккаунт","Hesap oluşturun"),'☁️']:[T("Xush kelibsiz","Добро пожаловать","Hoş geldiniz"),'☁️'];
let body='';
if(rs)body=`${pwf('cp',P2)}${pwf('cp2',P3)}<div class="sb"><i id="cb"></i></div><button class="btn pri" id="cg">${T("Parolni saqlash","Сохранить пароль","Parolayı kaydet")}</button>`;
else if(fg)body=`<input id="ce" type="email" autocomplete="email" placeholder="Email"><button class="btn pri" id="cg">📩 ${T("Tiklash xatini yuborish","Отправить письмо","Sıfırlama gönder")}</button><small class="mu">${T("Xatdagi havolani bosing yoki xatdagi kodni pastga yozing (Spam papkasini ham ko‘ring)","Нажмите ссылку в письме или введите код ниже (проверьте Спам)","Mesajdaki bağlantıya tıklayın veya kodu yazın (Spam'a da bakın)")}</small><input id="ck" inputmode="numeric" placeholder="${T("Xatdagi kod (ixtiyoriy)","Код из письма (необязательно)","Koddan (isteğe bağlı)")}">${pwf('cp',P2)}<button class="btn" id="cv">${T("Kod bilan parolni yangilash","Обновить пароль по коду","Kodla parolayı güncelle")}</button><button class="lnk" data-m="in">← ${T("Kirishga qaytish","Назад ко входу","Girişe dön")}</button>`;
else body=`<button type="button" class="btn" id="cgo" style="width:100%">🔵 ${T("Google bilan kirish","Войти через Google","Google ile giriş")}</button><div class="mu" style="text-align:center;margin:.5rem 0">${T("yoki email bilan","или по email","veya e-posta ile")}</div><input id="ce" type="email" autocomplete="email" placeholder="Email">${pwf('cp',sm?P2:P1)}${sm?`<div class="sb"><i id="cb"></i></div>${pwf('cp2',P3)}`:''}<button class="btn pri" id="cg">${sm?T("Ro‘yxatdan o‘tish","Зарегистрироваться","Kayıt ol"):T("Kirish","Войти","Giriş")}</button>${sm?'':`<button class="lnk" data-m="fp">${T("Parolni unutdingizmi?","Забыли пароль?","Parolayı unuttunuz mu?")}</button>`}`;
b.innerHTML=`<div class="cld"><div class="cr" style="--p:0"><span>${H[1]}</span></div><b style="font-size:1.2rem">${H[0]}</b>${rs||fg?'':`<small class="mu">🔒 ${T("Ma’lumotlaringiz faqat sizniki","Данные видите только вы","Verileri yalnızca siz görürsünüz")}</small>`}</div>${rs||fg?'':`<div class="seg"><button data-m="in" class="${sm?'':'on'}">${T("Kirish","Вход","Giriş")}</button><button data-m="up" class="${sm?'on':''}">${T("Ro‘yxat","Регистрация","Kayıt")}</button></div>`}<div class="card add">${body}</div><div id="cx"></div><p class="mu" id="cm" style="text-align:center"></p>`;
const q=x=>b.querySelector(x),msg=x=>{q('#cm').textContent=x},val=id=>(q('#'+id)||{value:''}).value;
if(AMSG){msg(AMSG);AMSG=''}
b.querySelectorAll('[data-m]').forEach(e=>e.onclick=()=>{AM=e.dataset.m;R()});
b.querySelectorAll('[data-e]').forEach(e=>e.onclick=()=>b.querySelectorAll('[data-pw]').forEach(i=>i.type=i.type=='password'?'text':'password'));
const pw=q('#cp');if(pw&&q('#cb'))pw.oninput=()=>{const n=pwSc(pw.value),c=q('#cb');c.style.width=n*25+'%';c.style.background=['#ef4444','#ef4444','#f59e0b','#84cc16','#22c55e'][n]};
const run=async f=>{msg('⏳');try{await f()}catch(e){msg('⚠ '+ER(e.message))}};
const okE=e=>/^\S+@\S+\.\S+$/.test(e),okP=p=>p.length>=8&&/[A-Za-z]/.test(p)&&/\d/.test(p);
const bad=T("Parol kamida 8 belgi, harf va raqamdan iborat bo‘lsin","Пароль: минимум 8 символов, буквы и цифры","Parola en az 8 karakter, harf ve rakam içermeli");
const resend=em=>{q('#cx').innerHTML=`<button class="btn" id="cs" style="width:100%">📩 ${T("Xatni qayta yuborish","Отправить письмо ещё раз","Mesajı tekrar gönder")}</button>`;q('#cs').onclick=()=>run(async()=>{await api('/auth/v1/resend',{m:'POST',b:{type:'signup',email:em}});msg('✅ '+T("Xat yuborildi. Spam papkasini ham ko‘ring","Письмо отправлено. Проверьте Спам","Mesaj gönderildi. Spam'a da bakın"))})};
const setPw=async(at,np)=>{await api('/auth/v1/user',{m:'PUT',h:{Authorization:'Bearer '+at},b:{password:np}})};
const g=q('#cg');if(!g)return;
if(rs)g.onclick=()=>run(async()=>{const p=val('cp');if(!okP(p))throw new Error(bad);if(p!==val('cp2'))throw new Error(T("Parollar bir xil emas","Пароли не совпадают","Parolalar aynı değil"));const s=await sess();await setPw(s.at,p);AM='in';AMSG='✅ '+T("Parol yangilandi","Пароль обновлён","Parola güncellendi");R()});
else if(fg){g.onclick=()=>run(async()=>{const e=val('ce').trim();if(!okE(e))throw new Error(T("Email to‘g‘ri emas","Неверный email","E-posta hatalı"));await api('/auth/v1/recover'+rdr(),{m:'POST',b:{email:e}});msg('✅ '+T("Xat yuborildi. Pochtani (Spam ham) tekshiring","Письмо отправлено. Проверьте почту (и Спам)","Mesaj gönderildi. Postanızı (Spam dahil) kontrol edin"))});
q('#cv').onclick=()=>run(async()=>{const e=val('ce').trim(),k=val('ck').trim(),p=val('cp');if(!okE(e)||!k)throw new Error(T("Email va xatdagi kodni kiriting","Введите email и код из письма","E-posta ve kodu girin"));if(!okP(p))throw new Error(bad);const s=keep(await api('/auth/v1/verify',{m:'POST',b:{type:'recovery',email:e,token:k}}));if(!s)throw new Error('invalid');await setPw(s.at,p);AM='in';AMSG='✅ '+T("Parol yangilandi","Пароль обновлён","Parola güncellendi");R()})}
else if(sm)g.onclick=()=>run(async()=>{const e=val('ce').trim(),p=val('cp');if(!okE(e))throw new Error(T("Email to‘g‘ri emas","Неверный email","E-posta hatalı"));if(!okP(p))throw new Error(bad);if(p!==val('cp2'))throw new Error(T("Parollar bir xil emas","Пароли не совпадают","Parolalar aynı değil"));const j=await api('/auth/v1/signup'+rdr(),{m:'POST',b:{email:e,password:p}});if(keep(j)){await pull(1);mAuto(1);R();return}if(j&&j.user&&j.user.identities&&!j.user.identities.length)throw new Error('already registered');msg('✅ '+T("Xat yuborildi: pochtadagi havolani bosing, keyin «Kirish» ni bosing","Письмо отправлено: нажмите ссылку, затем «Вход»","Mesaj gönderildi: bağlantıya tıklayın, sonra «Giriş»"));resend(e)});
else g.onclick=()=>run(async()=>{const e=val('ce').trim(),p=val('cp');if(!okE(e)||!p)throw new Error(T("Email va parolni kiriting","Введите email и пароль","E-posta ve parola girin"));try{await auth(e,p,0)}catch(x){if(/not confirmed/i.test(x.message))resend(e);throw x}msg('⏳ '+T('Bulutdan ma’lumotlar tekshirilmoqda…','Проверяем данные в облаке…','Buluttaki veriler kontrol ediliyor…'));await pull(1);mAuto(1);R()})}
(async()=>{const h=location.hash;if(!/access_token=|error=/.test(h))return;const p=new URLSearchParams(h.slice(1)),at=p.get('access_token');history.replaceState(null,'',location.pathname+location.search);
if(!at){AM='fp';AMSG=T("Havola eskirgan. Qayta yuboring","Ссылка устарела. Отправьте заново","Bağlantı eskimiş. Tekrar gönderin");setTimeout(()=>{try{vCloud()}catch(e){}},500);return}
try{const u=await api('/auth/v1/user',{h:{Authorization:'Bearer '+at}});sv({at,rt:p.get('refresh_token'),id:u.id,em:u.email,exp:Date.now()+(+p.get('expires_in')||3600)*1000-60000});if(p.get('type')=='recovery')AM='rs';else pull(1);setTimeout(()=>{try{vCloud()}catch(e){}},500)}catch(e){}})();

/* ===== Media zaxira (Supabase Storage): musiqa, kino, video, rasm ===== */
const MB=1048576,MAXF=50*MB,MAXU=900*MB,BK='sr-media',MK=['music','movies','clips'];
const spx=(s,k,id)=>s.id+'/'+(ACT||'main')+'/'+k+'/'+id;
async function stApi(s,m,p,o){o=o||{};const r=await fetch(U+'/storage/v1/'+p,{method:m,headers:Object.assign({apikey:K,Authorization:'Bearer '+s.at},o.h||{}),body:o.b});if(!r.ok){let j=null;try{j=await r.json()}catch(e){}throw new Error((j&&(j.message||j.error))||('HTTP '+r.status))}return r}
async function cloudList(s){const out={},pre=s.id+'/'+(ACT||'main')+'/';for(const k of MK.concat('pics')){let off=0;for(;;){const r=await stApi(s,'POST','object/list/'+BK,{h:{'Content-Type':'application/json'},b:JSON.stringify({prefix:pre+k,limit:100,offset:off})}),j=await r.json();j.forEach(x=>{if(x.name)out[k+'/'+x.name]=(x.metadata&&x.metadata.size)||0});if(j.length<100)break;off+=100}}return out}
async function localItems(){const L=[];D.lib=D.lib||{};for(const k of MK)for(const x of D.lib[k]||[]){try{const b=await dbx('readonly',q=>q.get(x.id));if(b)L.push({k,id:String(x.id),b})}catch(e){}}try{for(const p of await pAll())if(p.blob)L.push({k:'pics',id:String(p.id),b:p.blob})}catch(e){}return L}
async function mUp(s,say){const cl=await cloudList(s),L=await localItems();let used=Object.values(cl).reduce((a,b)=>a+b,0),n=0,big=0,full=0;
for(let i=0;i<L.length;i++){const it=L[i];if(it.k+'/'+it.id in cl)continue;if(it.b.size>MAXF){big++;continue}if(used+it.b.size>MAXU){full++;continue}
say('⏳ '+(i+1)+' / '+L.length+' · '+kb(it.b.size));
await stApi(s,'POST','object/'+BK+'/'+spx(s,it.k,it.id),{h:{'x-upsert':'true','Content-Type':it.b.type||'application/octet-stream'},b:it.b});used+=it.b.size;n++}
return{n,big,full}}
async function mDown(s,say,only){const cl=await cloudList(s),have=new Set((await localItems()).map(x=>x.k+'/'+x.id)),keys=(only||Object.keys(cl)).filter(k=>!have.has(k));let n=0;
for(let i=0;i<keys.length;i++){const[k,id]=keys[i].split('/');say('⏳ '+(i+1)+' / '+keys.length);const b=await(await stApi(s,'GET','object/authenticated/'+BK+'/'+spx(s,k,id))).blob();
if(k=='pics')await pPut({id,name:'photo',ts:+id.slice(0,13)||Date.now(),blob:b,th:b});else await dbx('readwrite',q=>q.put(b,+id));n++}
return n}
function mediaCard(el,s,R){if(!el)return;
el.innerHTML='<b>🎞 '+T("Media zaxira","Резерв медиа","Medya yedeği")+'</b><div class="mu" id="mi" style="margin:.4rem 0">⏳</div><button class="btn pri" id="mu" style="width:100%;margin-bottom:.4rem">⬆ '+T("Mediani bulutga yuklash","Загрузить медиа в облако","Medyayı buluta yükle")+'</button><button class="btn" id="md" style="width:100%">⬇ '+T("Mediani bulutdan tiklash","Восстановить медиа","Medyayı buluttan geri yükle")+'</button><small class="mu" id="mm" style="display:block;margin-top:.4rem">'+T("Bitta fayl 50 MB gacha, jami 900 MB gacha. Kattalari Google Drive orqali.","Файл до 50 МБ, всего до 900 МБ. Большие — через Google Drive.","Dosya 50 MB, toplam 900 MB’a kadar. Büyükler Google Drive ile.")+'</small>';
const q=x=>el.querySelector(x),say=x=>{q('#mm').textContent=x},busy=f=>{q('#mu').disabled=q('#md').disabled=f};
const info=async()=>{try{const[L,cl]=await Promise.all([localItems(),cloudList(s)]),ls=L.reduce((a,x)=>a+x.b.size,0),cs=Object.values(cl).reduce((a,b)=>a+b,0);q('#mi').innerHTML='📱 '+T("Qurilmada","На устройстве","Cihazda")+': <b>'+L.length+'</b> · '+kb(ls)+'<br>☁️ '+T("Bulutda","В облаке","Bulutta")+': <b>'+Object.keys(cl).length+'</b> · '+kb(cs)+' / 900 MB'}catch(e){q('#mi').textContent='⚠ '+ER(e.message)}};info();
q('#mu').onclick=async()=>{busy(1);try{const r=await mUp(s,say);say('✅ '+r.n+' '+T("ta fayl yuklandi","файлов загружено","dosya yüklendi")+(r.big?' · '+r.big+' '+T("ta juda katta (50 MB+)","слишком большие","çok büyük"):'')+(r.full?' · '+r.full+' '+T("ta joy yetmadi","нет места","yer yok"):''))}catch(e){say('⚠ '+ER(e.message))}busy(0);info()};
q('#md').onclick=async()=>{busy(1);try{const n=await mDown(s,say);say('✅ '+n+' '+T("ta fayl tiklandi","файлов восстановлено","dosya geri yüklendi")+(n?' · '+T("Sahifani yangilang","Обновите страницу","Sayfayı yenileyin"):''))}catch(e){say('⚠ '+ER(e.message))}busy(0);info()}}

let _mz=0;
async function mAuto(f){if(_mz||!ld()||(!f&&LS('sr_auto')==='0'))return;_mz=1;try{const s=await sess();await mUp(s,()=>{});
const cl=await cloudList(s),L=await localItems(),have=new Set(L.map(x=>x.k+'/'+x.id)),lib=D.lib||{},first=!LS('sr_mdl');
const miss=Object.keys(cl).filter(k=>{if(have.has(k))return false;const a=k.split('/')[0],id=k.split('/')[1];return a=='pics'?first:(lib[a]||[]).some(x=>String(x.id)==id)});
if(miss.length){const sz=miss.reduce((a,k)=>a+cl[k],0);
if(sz<=30*MB||(!window._mno&&confirm(T("Bulutda "+miss.length+" ta media fayl bor ("+kb(sz)+"). Shu qurilmaga yuklab olinsinmi?","В облаке "+miss.length+" медиафайлов ("+kb(sz)+"). Скачать на это устройство?","Bulutta "+miss.length+" medya dosyası var ("+kb(sz)+"). Bu cihaza indirilsin mi?")))){LS('sr_mdl','1');const n=await mDown(s,()=>{},miss);if(n){location.reload();return}}else window._mno=1}
LS('sr_mdl','1')}catch(e){}finally{_mz=0}}
/* ===== Google Drive zaxira: hamma media (har kimning o'z Drive'iga) ===== */
const GS='https://www.googleapis.com/auth/drive.file',GFN='SR Programma',gpre=()=>(ACT||'main')+'__';
let gTok=null,gExp=0,gFold=null;
const gCid=()=>(LS('sr_gcid')||'').replace(/\s+/g,'');
function gLoad(){return new Promise((res,rej)=>{if(window.google&&google.accounts&&google.accounts.oauth2)return res();const e=document.createElement('script');e.src='https://accounts.google.com/gsi/client';e.onload=()=>res();e.onerror=()=>rej(new Error('Google yuklanmadi (internet?)'));document.head.appendChild(e)})}
async function gAuth(){if(gTok&&Date.now()<gExp)return gTok;const id=gCid();if(!id)throw new Error(T("Avval Client ID kiriting","Сначала введите Client ID","Önce Client ID girin"));if(!/^\d+-[a-z0-9]+\.apps\.googleusercontent\.com$/i.test(id))throw new Error('Client ID noto‘g‘ri: «raqam-harflar.apps.googleusercontent.com» ko‘rinishida bo‘lishi kerak');await gLoad();return new Promise((res,rej)=>{const c=google.accounts.oauth2.initTokenClient({client_id:id,scope:GS,callback:r=>{if(r.error)return rej(new Error(r.error_description||r.error));gTok=r.access_token;gExp=Date.now()+(+r.expires_in||3600)*1000-60000;res(gTok)},error_callback:e=>rej(new Error(e.type||'popup'))});c.requestAccessToken({prompt:gTok?'':'consent'})})}
async function gf(u,o){o=o||{};const t=await gAuth();const r=await fetch(u,{method:o.m||'GET',headers:Object.assign({Authorization:'Bearer '+t},o.h||{}),body:o.b});if(!r.ok){let j=null;try{j=await r.json()}catch(e){}if(r.status==401)gTok=null;throw new Error((j&&j.error&&(j.error.message||j.error))||('HTTP '+r.status))}return r}
async function gFolder(){if(gFold)return gFold;const q=encodeURIComponent("name='"+GFN+"' and mimeType='application/vnd.google-apps.folder' and trashed=false"),j=await(await gf('https://www.googleapis.com/drive/v3/files?q='+q+'&fields=files(id)')).json();if(j.files&&j.files.length)return gFold=j.files[0].id;const c=await(await gf('https://www.googleapis.com/drive/v3/files?fields=id',{m:'POST',h:{'Content-Type':'application/json'},b:JSON.stringify({name:GFN,mimeType:'application/vnd.google-apps.folder'})})).json();return gFold=c.id}
async function gList(){const f=await gFolder(),out=[];let pt='';do{const q=encodeURIComponent("'"+f+"' in parents and trashed=false"),j=await(await gf('https://www.googleapis.com/drive/v3/files?q='+q+'&pageSize=1000&fields=nextPageToken,files(id,name,size)'+(pt?'&pageToken='+pt:''))).json();(j.files||[]).forEach(x=>{if(x.name.startsWith(gpre()))out.push({id:x.id,name:x.name,size:+x.size||0})});pt=j.nextPageToken||''}while(pt);return out}
async function gPut(name,blob,eid){if(eid){await gf('https://www.googleapis.com/upload/drive/v3/files/'+eid+'?uploadType=media',{m:'PATCH',h:{'Content-Type':blob.type||'application/octet-stream'},b:blob});return}
const f=await gFolder(),r=await gf('https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields=id',{m:'POST',h:{'Content-Type':'application/json; charset=UTF-8','X-Upload-Content-Type':blob.type||'application/octet-stream','X-Upload-Content-Length':String(blob.size)},b:JSON.stringify({name,parents:[f]})}),loc=r.headers.get('Location');if(!loc)throw new Error('Drive: Location yo‘q');
const t=await gAuth(),u=await fetch(loc,{method:'PUT',headers:{'Content-Type':blob.type||'application/octet-stream'},body:blob});if(!u.ok)throw new Error('Drive HTTP '+u.status)}
const gKey=n=>{const m=n.slice(gpre().length).split('__');return m.length>=2&&m[0]!='meta.json'?m[0]+'/'+m[1]:null};
async function gUp(say){const ex=await gList(),have=new Set(ex.map(x=>gKey(x.name)).filter(Boolean)),L=await localItems();let n=0;
for(let i=0;i<L.length;i++){const it=L[i],key=it.k+'/'+it.id;if(have.has(key))continue;say('⏳ '+(i+1)+' / '+L.length+' · '+kb(it.b.size));await gPut(gpre()+it.k+'__'+it.id+'__',it.b);n++}
const meta=new Blob([JSON.stringify({lib:D.lib||{}})],{type:'application/json'}),mf=ex.find(x=>x.name==gpre()+'meta.json');await gPut(gpre()+'meta.json',meta,mf&&mf.id);return n}
async function gDown(say){const ex=await gList(),have=new Set((await localItems()).map(x=>x.k+'/'+x.id)),mf=ex.find(x=>x.name==gpre()+'meta.json');
if(mf){try{const j=JSON.parse(await(await gf('https://www.googleapis.com/drive/v3/files/'+mf.id+'?alt=media')).text());D.lib=D.lib||{};for(const k of MK){const A=D.lib[k]=D.lib[k]||[];(j.lib&&j.lib[k]||[]).forEach(x=>{if(!A.some(z=>String(z.id)==String(x.id)))A.push(x)})}save()}catch(e){}}
const todo=ex.filter(x=>{const k=gKey(x.name);return k&&!have.has(k)});let n=0;
for(let i=0;i<todo.length;i++){const[k,id]=gKey(todo[i].name).split('/');say('⏳ '+(i+1)+' / '+todo.length+' · '+kb(todo[i].size));const b=await(await gf('https://www.googleapis.com/drive/v3/files/'+todo[i].id+'?alt=media')).blob();
if(k=='pics')await pPut({id,name:'photo',ts:+id.slice(0,13)||Date.now(),blob:b,th:b});else await dbx('readwrite',q=>q.put(b,+id));n++}return n}
function driveCard(el){if(!el)return;
el.innerHTML='<b>🟢 Google Drive</b><div class="mu" style="margin:.3rem 0">'+T("Kino, musiqa, video, rasm: hammasi o‘z Google Drive’ingizga (15 GB) saqlanadi.","Кино, музыка, видео, фото: всё в ваш Google Drive (15 ГБ).","Film, müzik, video, fotoğraf: hepsi Google Drive’ınıza (15 GB) kaydedilir.")+'</div><input id="gc" placeholder="Google Client ID" value="'+esc(gCid())+'" autocomplete="off"><div class="mu" id="gi" style="margin:.4rem 0"></div><button class="btn pri" id="gu" style="width:100%;margin-bottom:.4rem">⬆ '+T("Hammasini Drive’ga yuklash","Загрузить всё на Drive","Hepsini Drive’a yükle")+'</button><button class="btn" id="gd" style="width:100%">⬇ '+T("Drive’dan tiklash","Восстановить с Drive","Drive’dan geri yükle")+'</button><small class="mu" id="gm" style="display:block;margin-top:.4rem"></small>';
const q=x=>el.querySelector(x),say=x=>{q('#gm').textContent=x},busy=f=>{q('#gu').disabled=q('#gd').disabled=f};
q('#gc').onchange=e=>{e.target.value=e.target.value.replace(/\s+/g,'');LS('sr_gcid',e.target.value);gTok=null;gFold=null;say('✓')};
const info=async()=>{if(!gCid()||!gTok){q('#gi').textContent=gCid()?T("Yuklash tugmasini bossangiz Google ruxsat so‘raydi","Нажмите «Загрузить»: Google запросит доступ","Yükle’ye basınca Google izin ister"):'';return}try{const[L,ex]=await Promise.all([localItems(),gList()]),ls=L.reduce((a,x)=>a+x.b.size,0),cs=ex.reduce((a,x)=>a+x.size,0);q('#gi').innerHTML='📱 '+L.length+' · '+kb(ls)+'<br>🟢 Drive: '+ex.length+' · '+kb(cs)}catch(e){}};info();
q('#gu').onclick=async()=>{q('#gc').onchange({target:q('#gc')});busy(1);try{const n=await gUp(say);say('✅ '+n+' '+T("ta fayl yuklandi","файлов загружено","dosya yüklendi"))}catch(e){say('⚠ '+ER(e.message))}busy(0);info()};
q('#gd').onclick=async()=>{q('#gc').onchange({target:q('#gc')});busy(1);try{const n=await gDown(say);say('✅ '+n+' '+T("ta fayl tiklandi","файлов восстановлено","dosya geri yüklendi")+(n?' · '+T("Sahifani yangilang","Обновите страницу","Sayfayı yenileyin"):''))}catch(e){say('⚠ '+ER(e.message))}busy(0);info()}}
function vCloud(){push(()=>'☁️ '+t('cloud'),b=>{const R=()=>{const s=ld();
if(!s||AM=='rs'){authUI(b,R);return}
const tot=JSON.stringify(D).length,pct=Math.min(100,Math.round(tot/5242880*100)),sy=hs()===LS('sr_sb_h'),lt=LS('sr_sb_t')||'—';
const rows=Object.keys(D).map(k=>[k,JSON.stringify(D[k]).length]).sort((x,y)=>y[1]-x[1]).slice(0,6).map(([k,n])=>`<div class="krow"><span>${CN[k]||('📁 '+esc(k))}</span><b>${kb(n)}</b></div><div class="bar" style="height:.35rem;margin:0 0 .3rem"><i style="width:${Math.max(2,Math.round(n/tot*100))}%"></i></div>`).join('');
b.innerHTML=`<div class="cld"><div class="cr" style="--p:${sy?100:60}"><span>☁️</span></div><b>${esc(s.em||'')}</b><small class="st ${sy?'ok':'warn'}">${sy?'✅ '+T("Hammasi bulutda saqlangan","Всё сохранено в облаке","Her şey bulutta kayıtlı"):'🟡 '+T("Saqlanmagan o‘zgarishlar bor","Есть несохранённые изменения","Kaydedilmemiş değişiklikler var")}</small><small class="mu">🕒 ${T("Oxirgi saqlash","Последнее сохранение","Son kayıt")}: <span id="cls">${esc(lt)}</span></small><small class="mu" id="cinfo"></small></div>
<div class="card"><b>📦 ${T("Qurilma xotirasi","Память устройства","Cihaz belleği")}</b><div class="bar"><i style="width:${Math.max(2,pct)}%"></i></div><div class="krow"><span class="mu">${kb(tot)} / 5 MB</span><span class="mu">${pct}%</span></div>${rows}</div>
<button class="btn pri" id="cu" style="width:100%;margin-bottom:.5rem">☁️ ${T("Hozir bulutga saqlash","Сохранить в облако сейчас","Şimdi buluta kaydet")}</button><button class="btn" id="cd" style="width:100%;margin-bottom:.5rem">⬇ ${T("Bulutdan tiklash","Восстановить из облака","Buluttan geri yükle")}</button>
<label class="card krow" style="align-items:center"><span>⚡ ${T("Avtomatik saqlash","Автосохранение","Otomatik kayıt")}<br><small class="mu">${T("Har 2 daqiqada va ilovadan chiqqanda","Каждые 2 мин. и при выходе","Her 2 dk ve çıkışta")}</small></span><input type="checkbox" id="ca" ${LS('sr_auto')!=='0'?'checked':''} style="width:1.4rem;height:1.4rem"></label>
<div class="card" id="cdrive"></div><div class="card" id="cmedia"></div><button class="btn bad" id="co" style="width:100%">${T("Chiqish","Выйти","Çıkış")}</button><p class="mu" id="cm" style="text-align:center"></p>`;
const m=x=>{$('#cm').textContent=x};driveCard($('#cdrive'));mediaCard($('#cmedia'),s,R);
api('/rest/v1/sr_backup?select=updated_at&user_id=eq.'+s.id,{h:{Authorization:'Bearer '+s.at,apikey:K}}).then(j=>{const e=$('#cinfo');if(e)e.textContent=j&&j.length?'☁️ '+T("Bulutdagi nusxa","Копия в облаке","Buluttaki kopya")+': '+new Date(j[0].updated_at).toLocaleString():'☁️ '+T("Bulutda hali nusxa yo‘q","В облаке ещё нет копии","Bulutta henüz kopya yok")}).catch(()=>{});
$('#cu').onclick=async()=>{m('⏳');try{if(gCid())try{await gAuth()}catch(x){}await doUp();m('⏳ '+T('Media tekshirilmoqda…','Проверяем медиа…','Medya kontrol ediliyor…'));await mAuto(1);if(gCid()&&gTok){try{await gUp(m)}catch(x){}}R();$('#cm').textContent='✅ '+T("Saqlandi","Сохранено","Kaydedildi")}catch(e){m('⚠ '+e.message)}};
$('#cd').onclick=async()=>{m('⏳');try{const r=await down(),d=new Date(r.updated_at).toLocaleString();if(!confirm(T("Bulutdagi nusxa: ","Копия в облаке: ","Buluttaki kopya: ")+d+' · '+kb(JSON.stringify(r.data).length)+'\n'+T("Qurilmadagi ma’lumotlar almashtiriladi. Davom etasizmi?","Данные на устройстве будут заменены. Продолжить?","Cihazdaki veriler değiştirilecek. Devam?"))){m('');return}applyCloud(r)}catch(e){m('⚠ '+e.message)}};
$('#ca').onchange=e=>{LS('sr_auto',e.target.checked?'1':'0');m(e.target.checked?'⚡ '+T("Avtomatik saqlash yoqildi","Автосохранение включено","Otomatik kayıt açıldı"):'')};
$('#co').onclick=()=>{sv(null);R()}};R()})}
const G1=GOM;GOM=function(){const o=G1();o.cloud=vCloud;return o};
/* ===== v11: kirish darvozasi — SR oynasidan keyin email + parol ===== */
const GK='sr_gate',GTS='sr_gate_ts',GGR='sr_gate_gr',GHD='sr_gate_hid';
const gRec=()=>{try{return JSON.parse(localStorage.getItem(GK)||'null')}catch(e){return null}};
const gGr=()=>{const v=LS(GGR);return v===null||v===undefined?0:+v||0};
const gTs=()=>LS(GTS,String(Date.now()));
const gNeed=()=>{const g=gGr();if(!g)return true;const t=+(LS(GTS)||0);return !t||Date.now()-t>g*60000};
function gSwitch(){if(!confirm(trU('Bu akkauntdan chiqilsinmi? Keyin boshqa akkaunt bilan kirasiz.')))return;['sr_gate','sr_gate_ts','sr_gate_gr','sr_gate_hid','sr_gate_bad','sr_gate_until','sr_sb','sr_sb_h','sr_sb_t'].forEach(k=>{try{localStorage.removeItem(k)}catch(e){}});location.reload()}
const gMask=e=>String(e||'').replace(/^(.{1,2}).*(@.*)$/,'$1•••$2');
async function gHash(pw,salt){try{const k=await crypto.subtle.importKey('raw',new TextEncoder().encode(pw),'PBKDF2',false,['deriveBits']);const b=await crypto.subtle.deriveBits({name:'PBKDF2',salt:ub(salt),iterations:120000,hash:'SHA-256'},k,256);return 'p'+b64(b)}catch(e){let h=await sha(salt+':'+pw);for(let i=0;i<1500;i++)h=await sha(h);return 'f'+h}}
const gErr=m=>{m=String(m||'');const x=m.toLowerCase();
 if(x.includes('invalid login'))return 'Email yoki parol noto‘g‘ri';
 if(x.includes('not confirmed'))return 'Email tasdiqlanmagan: pochtadagi xatdagi havolani bosing';
 if(x.includes('already'))return 'Bu email ro‘yxatdan o‘tgan: «Kirish» ni bosing';
 if(x.includes('rate limit')||x.includes('too many')||x.includes('security purposes'))return 'Juda ko‘p urinish. 1 daqiqa kutib qayta urining';
 if(x.includes('weak')||x.includes('password should'))return 'Parol juda oddiy. Harf va raqam ishlating';
 if(x.includes('fetch')||x.includes('network'))return 'Internet yo‘q yoki ulanib bo‘lmadi';
 return m};
const gFresh=()=>{const n=a=>Array.isArray(a)?a.length:a&&typeof a=='object'?Object.keys(a).length:0;const l=D.lib||{};
 return !(n(D.notes)||n(D.tasks)||n(D.exp)||n(D.plan)||n(D.routine)||n(D.goals)||n(D.poems)||n(D.ltc)||n(D.tk)||n(D.lg)||n(D.hm&&D.hm.tasks)||n(l.music)||n(l.movies)||n(l.clips)||(D.xp|0)||n(D.set&&D.set.alm))};
async function gRestore(){try{if(!ld()||!navigator.onLine||!gFresh())return;let r;try{r=await down()}catch(e){return}if(!r||!r.data)return;
 const k=D.ai&&D.ai.key;Object.assign(D,r.data);if(D.ai)D.ai.key=k||'';save();LS('sr_sb_h',hs());LS('sr_sb_t',new Date().toLocaleString());toast(trU('Bulutdagi ma’lumotlar tiklandi'));setTimeout(()=>location.reload(),900)}catch(e){}}
function gDone(o,pw){gTs();if(LS('sr_auto')===null||LS('sr_auto')===undefined)LS('sr_auto','1');o.classList.add('go');setTimeout(()=>o.remove(),450);
 if(pw&&navigator.onLine){const r=gRec();if(r)auth(r.em,pw,0).then(gRestore).catch(()=>gRestore())}else gRestore()}
function gShow(mode){let o=document.getElementById('srgt');if(o)o.remove();o=document.createElement('div');o.id='srgt';document.body.appendChild(o);
 const rec=gRec(),pwf=(id,ph,ac)=>`<div class="pw"><input id="${id}" data-pw type="password" autocomplete="${ac}" placeholder="${ph}"><button type="button" class="eye" data-e>👁</button></div>`;
 const langs=`<div class="chips gl" id="gl">${LG.map(l=>`<button data-l="${l}" class="${l==D.set.lang?'on':''}">${l.toUpperCase()}</button>`).join('')}</div>`;
 let up=false;
 const draw=()=>{
  if(mode=='login'){o.innerHTML=`<div class="sr gsr">SR</div><h2>Xush kelibsiz</h2><div class="mu gem">${esc(gMask(rec.em))}</div>${pwf('gp','Parol','current-password')}<button class="btn pri" id="gb">Kirish</button><button class="lnk" id="gf">Parolni unutdingizmi?</button><button class="lnk" id="gsw">Boshqa akkaunt bilan kirish</button><p class="mu gms" id="gm"></p>${langs}`}
  else if(mode=='reset'){o.innerHTML=`<div class="sr gsr">SR</div><h2>Yangi parol o‘rnating</h2>${pwf('gp','Yangi parol (8+, harf va raqam)','new-password')}${pwf('gp2','Parolni takrorlang','new-password')}<button class="btn pri" id="gb">Parolni saqlash</button><p class="mu gms" id="gm"></p>${langs}`}
  else{o.innerHTML=`<div class="sr gsr">SR</div><h2>SR Programma</h2><p class="mu gsb">Kirish uchun akkauntingiz bilan kiring. Ma’lumotlaringiz bulutda saqlanadi va boshqa telefonda ham tiklanadi.</p><input id="ge" type="email" autocomplete="email" placeholder="Email">${pwf('gp',up?'Yangi parol (8+, harf va raqam)':'Parol',up?'new-password':'current-password')}${up?pwf('gp2','Parolni takrorlang','new-password'):''}<button class="btn pri" id="gb">${up?'Ro‘yxatdan o‘tish':'Kirish'}</button>${up?'':'<button class="lnk" id="gf">Parolni unutdingizmi?</button>'}<p class="mu gms" id="gm"></p>${langs}`}
  bind()};
 const q=s=>o.querySelector(s),val=id=>(q('#'+id)||{value:''}).value,msg=s=>{q('#gm').textContent=s;if(window.relangUI)relangUI()};
 const okE=e=>/^\S+@\S+\.\S+$/.test(e),okP=p=>p.length>=8&&/[A-Za-z]/.test(p)&&/\d/.test(p);
 const shake=()=>{o.classList.add('shake');setTimeout(()=>o.classList.remove('shake'),400)};
 async function save2(em,pw){const s=b64(rnd(16));localStorage.setItem(GK,JSON.stringify({v:1,em,s,h:await gHash(pw,s)}))}
 function bind(){
  o.querySelectorAll('[data-e]').forEach(e=>e.onclick=()=>o.querySelectorAll('[data-pw]').forEach(i=>i.type=i.type=='password'?'text':'password'));
  o.querySelector('#gl').onclick=e=>{const l=e.target.dataset.l;if(l){setLang(l);[...o.querySelectorAll('#gl button')].forEach(b=>b.classList.toggle('on',b.dataset.l==l))}};
  o.querySelectorAll('[data-m]').forEach(e=>e.onclick=()=>{up=e.dataset.m=='up';draw()});
  const gb=q('#gb'),run=f=>{gb.disabled=true;msg('⏳');f().catch(e=>{msg(gErr(e.message))}).finally(()=>{gb.disabled=false})};
  const enter=f=>o.addEventListener('keydown',e=>{if(e.key=='Enter'&&e.target.tagName=='INPUT'){e.preventDefault();gb.click()}});enter();
  if(mode=='login')gb.onclick=()=>run(async()=>{const until=+(LS('sr_gate_until')||0);if(Date.now()<until){msg('Juda ko‘p urinish. Biroz kuting');return}const pw=val('gp');if(!pw){msg('');return}
    let ok=false;try{ok=(await gHash(pw,rec.s))===rec.h}catch(e){}
    if(!ok&&navigator.onLine){try{const s=await auth(rec.em,pw,0);if(s){ok=true;await save2(rec.em,pw)}}catch(e){if(!/invalid login|fetch|network/i.test(String(e.message)))throw e}}
    if(!ok){const bad=(+(LS('sr_gate_bad')||0))+1;LS('sr_gate_bad',String(bad));if(bad>=5)LS('sr_gate_until',String(Date.now()+Math.min(300000,30000*(bad-4))));shake();sfx('bad');msg('Parol noto‘g‘ri');return}
    LS('sr_gate_bad','0');sfx('ok');gDone(o,pw)});
  else if(mode=='reset')gb.onclick=()=>run(async()=>{const p=val('gp');if(!okP(p)){msg('Parol kamida 8 belgi, harf va raqamdan iborat bo‘lsin');return}if(p!==val('gp2')){msg('Parollar bir xil emas');return}
    const at=new URLSearchParams((window.__H0||'').replace(/^#/,'')).get('access_token');if(!at){msg('Havola eskirgan. Qayta yuboring');return}
    const u=await api('/auth/v1/user',{h:{Authorization:'Bearer '+at}});await api('/auth/v1/user',{m:'PUT',h:{Authorization:'Bearer '+at},b:{password:p}});
    await save2(u.email,p);AM='in';window.__H0='';sfx('ok');gDone(o,p)});
  else gb.onclick=()=>run(async()=>{const em=val('ge').trim(),pw=val('gp');if(!okE(em)){msg('Email to‘g‘ri emas');return}
    if(up){if(!okP(pw)){msg('Parol kamida 8 belgi, harf va raqamdan iborat bo‘lsin');return}if(pw!==val('gp2')){msg('Parollar bir xil emas');return}
     const j=await api('/auth/v1/signup'+rdr(),{m:'POST',b:{email:em,password:pw}});if(!keep(j)){if(j&&j.user&&j.user.identities&&!j.user.identities.length)throw new Error('already registered');msg('Xat yuborildi: pochtadagi havolani bosing, keyin «Kirish» ni bosing');return}}
    else{if(!pw){msg('');return}await auth(em,pw,0)}
    await save2(ld().em||em,pw);sfx('ok');gDone(o,pw)});
  const gsw=q('#gsw');if(gsw)gsw.onclick=gSwitch;
  const gf=q('#gf');if(gf)gf.onclick=()=>run(async()=>{const em=mode=='login'?rec.em:val('ge').trim();if(!okE(em)){msg('Email to‘g‘ri emas');return}await api('/auth/v1/recover'+rdr(),{m:'POST',b:{email:em}});msg('Xat yuborildi. Pochtani (Spam ham) tekshiring')})}
 draw()}
(function(){const H0=window.__H0||'';
 if(/type=recovery/.test(H0))gShow('reset');else if(!gRec())gShow('setup');else if(gNeed())gShow('login');
 document.addEventListener('visibilitychange',()=>{if(document.hidden){LS(GHD,String(Date.now()));gTs();return}
  if(!gRec()||document.getElementById('srgt'))return;const away=Date.now()-(+(LS(GHD)||0)),lim=Math.max(1,gGr())*60000;if(+(LS(GHD)||0)&&away>lim)gShow('login')});
 addEventListener('pagehide',()=>gTs());
 /* Xavfsizlik bo‘limiga «Kirish paroli» kartasi */
 const vs=window.vSec;if(typeof vs=='function')window.vSec=function(){vs();const b=document.getElementById('vb'),r=gRec();if(!b||!r)return;
  const opts=[[0,'Har safar'],[5,'5 daqiqa'],[30,'30 daqiqa'],[60,'1 soat']],g=gGr();
  b.insertAdjacentHTML('afterbegin',`<div class="card" id="gcs" style="margin-bottom:.8rem"><b>🔑 <span>Kirish paroli</span></b><div class="mu" style="margin:.2rem 0 .6rem">${esc(gMask(r.em))}</div><div class="mu" style="margin-bottom:.3rem">Qayta so‘rash</div><div class="chips" id="gcc">${opts.map(([v,l])=>`<button data-v="${v}" class="${v==g?'on':''}">${l}</button>`).join('')}</div><button class="btn" id="gcl" style="width:100%;margin-top:.6rem">🔒 Hozir qulflash</button><button class="btn bad" id="gco" style="width:100%;margin-top:.5rem">↪ Akkauntdan chiqish</button></div>`);
  b.querySelector('#gco').onclick=gSwitch;
  b.querySelector('#gcc').onclick=e=>{const v=e.target.dataset.v;if(v===undefined)return;LS(GGR,v);[...b.querySelectorAll('#gcc button')].forEach(x=>x.classList.toggle('on',x.dataset.v==v))};
  b.querySelector('#gcl').onclick=()=>{LS(GTS,'0');LS(GHD,'0');gShow('login')}};
 window.gShow=gShow})();
applyAll();
})();
