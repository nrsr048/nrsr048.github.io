# SR Programma — sozlash (3 qadam)

Supabase loyihangiz: `olqnhjokpufudfqyenwx` (dasturda allaqachon ulangan).

## 1) Google bilan kirish
1. **Google Cloud Console → APIs & Services → Credentials → OAuth client (Web)** (Drive uchun ochgan Client ID ni ishlatsangiz bo'ladi).
2. *Authorized redirect URIs* ga qo'shing:
   `https://olqnhjokpufudfqyenwx.supabase.co/auth/v1/callback`
3. **Supabase → Authentication → Providers → Google**: yoqing, Client ID va Client Secret ni kiriting, saqlang.
4. **Supabase → Authentication → URL Configuration**:
   - *Site URL*: `https://nrsr048.github.io/<repo-nomi>/`
   - *Redirect URLs* ga shu manzilni ham qo'shing.
5. Dasturda ☁ Bulut → «🔵 Google bilan kirish».

## 2) Ma'lumot saqlash jadvali
Dasturdagi bulut zaxirasi `sr_backup` jadvalidan foydalanadi. Agar hali yaratmagan bo'lsangiz (SQL Editor):
```sql
create table if not exists public.sr_backup (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.sr_backup enable row level security;
create policy "own rows" on public.sr_backup
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
```

## 3) Qidiruv (Brave Search)
1. **https://brave.com/search/api/** da ro'yxatdan o'ting, tarif tanlang (bepul/sinov tarifi bor; shartlarini sayt o'zida tekshiring) va **API kalit** oling.
2. **Supabase → Edge Functions → Deploy a new function → Via Editor**, nomi: `search`.
   `supabase/functions/search/index.ts` ichidagi kodni to'liq joylang → Deploy.
3. **Edge Functions → Secrets** ga qo'shing: `BRAVE_API_KEY` = (kalitingiz).
4. Dasturda tizimga kiring va Qidiruvni sinang.
> Kalitni hech qachon `index.html` yoki `js/` ichiga yozmang — u faqat Supabase Secrets'da turadi.
