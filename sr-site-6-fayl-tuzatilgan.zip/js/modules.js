/* ===== Kalendar: hafta / oy / yil, 2005–2300 (hisob-kitob asosida, internetsiz) ===== */
(function(){
const A=new Date(2005,0,1),Z=new Date(2300,11,31),L3=(a,b,c)=>[a,b,c];
Object.assign(S,{
cal:L3("Kalendar","Календарь","Takvim"),
calS:L3("Hafta, oy, yil · 2005–2300","Неделя, месяц, год · 2005–2300","Hafta, ay, yıl · 2005–2300"),
cl_rng:L3("Kalendar 2005–2300 yillar oralig’ida","Календарь: 2005–2300 годы","Takvim 2005–2300 yılları arasında"),
cl_plan:L3("📋 Kun rejasi","📋 План дня","📋 Gün planı"),
cl_none:L3("Bu kunga reja yo’q","На этот день планов нет","Bu gün için plan yok"),
cl_hn:L3("🌙 hijriy sana va hayitlar taxminiy (±1 kun)","🌙 дата хиджры и праздники приблизительны (±1 день)","🌙 hicri tarih ve bayramlar yaklaşık (±1 gün)"),
cl_in:L3("{n} kun keyin","через {n} дн.","{n} gün sonra"),
cl_ago:L3("{n} kun oldin","{n} дн. назад","{n} gün önce"),
cl_doy:L3("yilning {n}-kuni","{n}-й день года","yılın {n}. günü"),
cl_wk:L3("{n}-hafta","{n}-я неделя","{n}. hafta")});
const WF=[["Dushanba","Seshanba","Chorshanba","Payshanba","Juma","Shanba","Yakshanba"],["Понедельник","Вторник","Среда","Четверг","Пятница","Суббота","Воскресенье"],["Pazartesi","Salı","Çarşamba","Perşembe","Cuma","Cumartesi","Pazar"]];
const MG=["января","февраля","марта","апреля","мая","июня","июля","августа","сентября","октября","ноября","декабря"];
const HN=[["Muharram","Safar","Rabi’ul-avval","Rabi’ul-oxir","Jumodil-avval","Jumodil-oxir","Rajab","Sha’bon","Ramazon","Shavvol","Zulqa’da","Zulhijja"],["Мухаррам","Сафар","Раби-уль-авваль","Раби-уль-ахир","Джумада-ль-уля","Джумада-ль-ахира","Раджаб","Шаабан","Рамадан","Шавваль","Зуль-каада","Зуль-хиджжа"],["Muharrem","Safer","Rebiülevvel","Rebiülahir","Cemaziyelevvel","Cemaziyelahir","Recep","Şaban","Ramazan","Şevval","Zilkade","Zilhicce"]];
const FH={"1-1":L3("Yangi yil","Новый год","Yılbaşı"),"1-14":L3("Vatan himoyachilari kuni","День защитников Родины","Vatan Savunucuları Günü"),"3-8":L3("Xalqaro xotin-qizlar kuni","Международный женский день","Dünya Kadınlar Günü"),"3-21":L3("Navro’z","Навруз","Nevruz"),"5-9":L3("Xotira va qadrlash kuni","День памяти и почестей","Anma ve Onurlandırma Günü"),"9-1":L3("Mustaqillik kuni","День независимости","Bağımsızlık Günü"),"10-1":L3("O’qituvchi va murabbiylar kuni","День учителей и наставников","Öğretmenler ve Mentorlar Günü"),"12-8":L3("Konstitutsiya kuni","День Конституции","Anayasa Günü")};
const HH={"10-1":L3("Ro’za hayit","Ураза-байрам","Ramazan Bayramı"),"12-10":L3("Qurbon hayit","Курбан-байрам","Kurban Bayramı")};
const CV={m:'m',d:new Date(),s:new Date()};
const pd=k=>{const a=k.split('-').map(Number);return new Date(a[0],a[1]-1,a[2])};
const inR=d=>d>=A&&d<=Z,U=d=>Date.UTC(d.getFullYear(),d.getMonth(),d.getDate());
const hij=d=>{let l=Math.round(U(d)/864e5)+2440588-1948440+10632;const n=Math.floor((l-1)/10631);l=l-10631*n+354;const j=Math.floor((10985-l)/5316)*Math.floor(50*l/17719)+Math.floor(l/5670)*Math.floor(43*l/15238);l=l-Math.floor((30-j)/15)*Math.floor(17719*j/50)-Math.floor(j/16)*Math.floor(15238*j/43)+29;const m=Math.floor(24*l/709);return[30*n+j-30,m,l-Math.floor(709*m/24)]};
const isoW=d=>{const x=new Date(U(d));x.setUTCDate(x.getUTCDate()+4-(x.getUTCDay()||7));return Math.ceil(((x-Date.UTC(x.getUTCFullYear(),0,1))/864e5+1)/7)};
function hol(d){const i=I(),r=[],a=FH[(d.getMonth()+1)+'-'+d.getDate()],h=hij(d),b=HH[h[1]+'-'+h[2]];if(a)r.push(a[i]);if(b)r.push('≈ '+b[i]);return r}
function cell(d,om,mini){if(!inR(d)||(om&&mini))return'<i class="cd x"></i>';const k=dk(d),H=hol(d);
return `<button class="cd${om?' o':''}${(d.getDay()+6)%7>4?' we':''}${H.length?' hl':''}${dI(k).length?' pl':''}${k==dk(new Date())?' td':''}${k==dk(CV.s)?' sel':''}" data-k="${k}">${d.getDate()}</button>`}
function mGrid(y,m,mini){const f=new Date(y,m,1),s=ws(f),n=Math.ceil(((f.getDay()+6)%7+new Date(y,m+1,0).getDate())/7);let h='';
for(let r=0;r<n;r++){const rs=shift('d',s,r*7);if(!mini)h+=`<span class="cw">${isoW(shift('d',rs,3))}</span>`;for(let c=0;c<7;c++){const d=shift('d',rs,c);h+=cell(d,d.getMonth()!=m,mini)}}return h}
const wh=(cl)=>WN[LI()].map((x,i)=>`<span class="cwh${i>4?' we':''}">${cl?x[0]:x}</span>`).join('');
const monthH=()=>`<div class="cg"><span></span>${wh(0)}${mGrid(CV.d.getFullYear(),CV.d.getMonth(),0)}</div>`;
const yearH=()=>{const y=CV.d.getFullYear(),i=I();let h='<div class="yg">';for(let m=0;m<12;m++)h+=`<div class="ym"><button class="yt" data-m="${m}">${MN[i][m]}</button><div class="mg">${wh(1)}${mGrid(y,m,1)}</div></div>`;return h+'</div>'};
function weekH(){const s=ws(CV.d),i=I();let h='';for(let q=0;q<7;q++){const d=shift('d',s,q);if(!inR(d))continue;const k=dk(d),L=dI(k),H=hol(d),j=hij(d);
h+=`<button class="wr${k==dk(new Date())?' td':''}${k==dk(CV.s)?' sel':''}${q>4?' we':''}" data-k="${k}"><div class="wd"><b>${d.getDate()}</b><span>${WN[i][q]}</span></div><div class="wb"><div>${H.map(x=>`<span class="tg h">${esc(x)}</span>`).join('')}<span class="mu" style="font-size:.74rem">🌙 ${j[2]} ${HN[i][j[1]-1]}</span></div>${L.length?L.slice(0,3).map(x=>`<div class="wi${x.done?' dn':''}">${x.time} · ${esc(x.text)}</div>`).join('')+(L.length>3?`<div class="mu">+${L.length-3}</div>`:''):'<div class="mu">—</div>'}</div></button>`}return h}
function detail(){const i=I(),d=CV.s,k=dk(d),H=hol(d),j=hij(d),L=dI(k),n=Math.round((U(d)-U(new Date()))/864e5),y=d.getFullYear(),dy=Math.round((U(d)-Date.UTC(y,0,0))/864e5),ln=Math.round((Date.UTC(y+1,0,0)-Date.UTC(y,0,0))/864e5),
rel=n==0?t('today'):n>0?t('cl_in').replace('{n}',n):t('cl_ago').replace('{n}',-n);
return `<div class="card"><b>${WF[i][(d.getDay()+6)%7]}, ${d.getDate()} ${i==1?MG[d.getMonth()]:MN[i][d.getMonth()]} ${y}</b><div style="margin-top:.5rem"><span class="tg">${rel}</span><span class="tg">${t('cl_doy').replace('{n}',dy)} / ${ln}</span><span class="tg">${t('cl_wk').replace('{n}',isoW(d))}</span><span class="tg">🌙 ${j[2]} ${HN[i][j[1]-1]} ${j[0]}</span></div>${H.map(x=>`<div class="tg h">🎉 ${esc(x)}</div>`).join('')}<div class="mu" style="font-size:.72rem;margin:.2rem 0 .5rem">${t('cl_hn')}</div>${L.length?L.slice(0,10).map(x=>`<div class="wi${x.done?' dn':''}">${x.done?'✅':'•'} ${x.time} · ${esc(x.text)}</div>`).join('')+(L.length>10?`<div class="mu">+${L.length-10}</div>`:''):`<div class="mu">${t('cl_none')}</div>`}<button class="btn pri" data-a="pl" style="width:100%;margin-top:.6rem">${t('cl_plan')}</button></div>`}
function cLab(){const d=CV.d,m=MN[LI()];if(CV.m=='y')return''+d.getFullYear();if(CV.m=='m')return m[d.getMonth()]+' '+d.getFullYear();const a=ws(d),b=shift('d',a,6);return a.getDate()+' '+m[a.getMonth()].slice(0,3)+' – '+b.getDate()+' '+m[b.getMonth()].slice(0,3)+' '+b.getFullYear()}
function selFor(x,md){const T=new Date(),same=md=='y'?x.getFullYear()==T.getFullYear():md=='m'?x.getFullYear()==T.getFullYear()&&x.getMonth()==T.getMonth():dk(ws(x))==dk(ws(T));return same?T:x}
function step(n){const d=CV.d,y=d.getFullYear(),x=CV.m=='w'?shift('d',d,7*n):CV.m=='m'?new Date(y,d.getMonth()+n,1):new Date(y+n,d.getMonth(),1);if(x<A||x>Z){toast(t('cl_rng'));return}CV.d=x;CV.s=selFor(x,CV.m);draw()}
function vCal(){push(()=>t('cal'),b=>{const i=I(),y=CV.d.getFullYear(),m=CV.d.getMonth();let yo='';for(let q=2005;q<=2300;q++)yo+=`<option${q==y?' selected':''}>${q}</option>`;
b.innerHTML=`<div class="cl" id="clw"><div class="seg">${[['w',1],['m',2],['y',3]].map(a=>`<button data-md="${a[0]}" class="${CV.m==a[0]?'on':''}">${t('pn')[a[1]]}</button>`).join('')}</div>
<div class="nv"><button data-st="-1" aria-label="‹">‹</button><button class="lb" data-st="0">${cLab()}${CV.m=='w'?`<small class="mu">${t('cl_wk').replace('{n}',isoW(shift('d',ws(CV.d),3)))}</small>`:''}</button><button data-st="1" aria-label="›">›</button></div>
<div class="sel2"><select id="clY">${yo}</select>${CV.m=='y'?'':`<select id="clM">${MN[i].map((x,q)=>`<option value="${q}"${q==m?' selected':''}>${x}</option>`).join('')}</select>`}</div>${CV.m=='m'?monthH():CV.m=='w'?weekH():yearH()}${detail()}</div>`;
const w=$('#clw'),jump=()=>{const yy=+$('#clY').value,mm=$('#clM')?+$('#clM').value:CV.d.getMonth(),x=CV.m=='w'?new Date(yy,mm,Math.min(CV.d.getDate(),new Date(yy,mm+1,0).getDate())):new Date(yy,mm,1);CV.d=x;CV.s=selFor(x,CV.m);draw()};
$('#clY').onchange=jump;if($('#clM'))$('#clM').onchange=jump;
w.onclick=e=>{const x=e.target.closest('[data-md],[data-st],[data-k],[data-m],[data-a]');if(!x)return;const q=x.dataset;
if(q.md){CV.m=q.md;CV.d=new Date(CV.s);draw();return}
if(q.st!==undefined){if(q.st=='0'){CV.d=new Date();CV.s=new Date();draw()}else step(+q.st);return}
if(q.k){const d=pd(q.k);CV.s=d;CV.d=d;if(CV.m=='y')CV.m='m';draw();return}
if(q.m!==undefined){CV.m='m';CV.d=new Date(CV.d.getFullYear(),+q.m,1);CV.s=selFor(CV.d,'m');draw();return}
if(q.a=='pl'){cur=new Date(CV.s.getFullYear(),CV.s.getMonth(),CV.s.getDate());tp='d';vTime()}};
let X=0,Y=0;w.ontouchstart=e=>{X=e.touches[0].clientX;Y=e.touches[0].clientY};w.ontouchend=e=>{const c=e.changedTouches[0],dx=c.clientX-X,dy=c.clientY-Y;if(Math.abs(dx)>60&&Math.abs(dx)>2*Math.abs(dy))step(dx<0?1:-1)}})}
const G0=GOM;GOM=function(){const o=G0();o.cal=vCal;return o};
applyAll();
})();
;
/* ===== Bulut (Supabase): kirish + zaxira saqlash/tiklash ===== */
(function(){
window.__H0=location.hash;const U='https://olqnhjokpufudfqyenwx.supabase.co',K='sb_publishable_QeOKzQgDKSV9nNoQj99M7w_tdcWHUs_',SK='sr_sb',L3=(a,b,c)=>[a,b,c],T=(a,b,c)=>[a,b,c][I()];
Object.assign(S,{cloud:L3("Bulut","Облако","Bulut"),cloudS:L3("Zaxira · Supabase","Резерв · Supabase","Yedek · Supabase")});
const ld=()=>{try{return JSON.parse(localStorage.getItem(SK)||'null')}catch(e){return null}};
const sv=s=>{try{s?localStorage.setItem(SK,JSON.stringify(s)):localStorage.removeItem(SK)}catch(e){}};
async function api(p,o){o=o||{};const r=await fetch(U+p,{method:o.m||'GET',headers:Object.assign({apikey:K,'Content-Type':'application/json'},o.h||{}),body:o.b?JSON.stringify(o.b):undefined});let j=null;try{j=await r.json()}catch(e){}
if(!r.ok)throw new Error((j&&(j.error_description||j.msg||j.message||j.error))||('HTTP '+r.status));return j}
const keep=j=>{if(j&&j.access_token){const s={at:j.access_token,rt:j.refresh_token,id:j.user&&j.user.id,em:j.user&&j.user.email,exp:Date.now()+(j.expires_in||3600)*1000-60000};sv(s);return s}return null};
async function sess(){let s=ld();if(!s)throw new Error(T("Avval kiring","Сначала войдите","Önce giriş yapın"));if(Date.now()>s.exp){try{s=keep(await api('/auth/v1/token?grant_type=refresh_token',{m:'POST',b:{refresh_token:s.rt}}))}catch(e){if(navigator.onLine===false||/fetch|network|load failed|timeout/i.test(String(e&&e.message)))throw new Error(T("Internet yo‘q","Нет интернета","İnternet yok"));sv(null);throw new Error(T("Seans tugadi, qayta kiring","Сессия истекла, войдите снова","Oturum bitti, tekrar girin"))}}return s}
async function auth(em,pw,reg){const s=keep(await api(reg?'/auth/v1/signup':'/auth/v1/token?grant_type=password',{m:'POST',b:{email:em,password:pw}}));if(!s)throw new Error(T("Emailga xat yuborildi: tasdiqlang, keyin kiring","Письмо отправлено: подтвердите почту и войдите","E-postaya mesaj gitti: onaylayıp giriş yapın"));return s}
async function up(){const s=await sess(),d=JSON.parse(JSON.stringify(D));if(d.ai)d.ai.key='';const x={};xks().forEach(k=>{const v=LS(k);if(v!=null)x[k]=v});{const bi=LS('betonImg');if(bi&&bi.length<2e6)x.betonImg=bi}d.__x=x;const t=Date.now();await api('/rest/v1/sr_backup?on_conflict=user_id',{m:'POST',h:{Authorization:'Bearer '+s.at,Prefer:'resolution=merge-duplicates,return=minimal'},b:{user_id:s.id,data:d,updated_at:new Date(t).toISOString()}});return t} async function down(){const s=await sess(),j=await api('/rest/v1/sr_backup?select=data,updated_at&user_id=eq.'+s.id,{h:{Authorization:'Bearer '+s.at}});if(!j||!j.length)throw new Error(T("Bulutda zaxira yo’q","В облаке нет копии","Bulutta yedek yok"));return j[0]}
const kb=n=>n>1048576?(n/1048576).toFixed(1)+' MB':Math.max(1,Math.round(n/1024))+' KB',hs=()=>{const j=JSON.stringify(D)+xks().concat(['betonImg']).map(k=>LS(k)||'').join('|');let h=5381;for(let i=0;i<j.length;i++)h=((h<<5)+h+j.charCodeAt(i))|0;return j.length+':'+h},LS=(k,v)=>{try{return v===undefined?localStorage.getItem(k):localStorage.setItem(k,v)}catch(e){}};
const XK=['srt3','srd1','srst','betonS2','betonEnc','sr_profiles'];const xks=()=>{let a=XK.slice();try{Object.keys(localStorage).forEach(k=>{if(/^sr_app_v1_/.test(k))a.push(k)})}catch(e){}return a};
async function doUp(){const t=await up();LS('sr_sb_t',new Date().toLocaleString());LS('sr_sb_h',hs());LS('sr_sb_c',String(t))}
function applyCloud(r){const k=D.ai&&D.ai.key,x=r.data.__x||{},d=Object.assign({set:{lang:'uz',theme:'tun',fs:1},tasks:[],notes:[],timer:{total:1500,left:1500,run:false,endAt:0}},r.data);delete d.__x;Object.keys(D).forEach(q=>delete D[q]);Object.assign(D,d);D.set=Object.assign({lang:'uz',theme:'tun',fs:1},D.set);if(D.ai)D.ai.key=k||'';save();Object.keys(x).forEach(q=>{if(x[q]!=null)LS(q,x[q])});LS('sr_sb_h',hs());LS('sr_sb_c',String(Date.parse(r.updated_at)));LS('sr_sb_t',new Date().toLocaleString());LS('sr_sb_rs','1');location.reload()}
async function cT(){const s=await sess(),j=await api('/rest/v1/sr_backup?select=updated_at&user_id=eq.'+s.id,{h:{Authorization:'Bearer '+s.at}});return j&&j.length?Date.parse(j[0].updated_at):0}
let _bz=0;
async function pull(f){if(_bz||!ld()||(!f&&LS('sr_auto')==='0'))return;_bz=1;try{const ct=await cT(),lc=+LS('sr_sb_c')||0;let ch=hs()!==LS('sr_sb_h');if(LS('sr_sb_rs')){LS('sr_sb_rs','');ch=false;LS('sr_sb_h',hs())}
if(!ct){if(ch||!LS('sr_sb_h'))await doUp();return}
if(ct===lc){if(ch)await doUp();return}
const r=await down(),fresh=JSON.stringify(D).length<1500&&!LS('sr_sb_h');
if(!ch||fresh){applyCloud(r);return}
if(confirm(T("Bulutda boshqa qurilmadan yangiroq ma’lumot bor.\nOK — bulutdagini olish\nBekor — bu qurilmadagini saqlash","В облаке более новые данные с другого устройства.\nOK — взять из облака\nОтмена — сохранить с этого устройства","Bulutta başka cihazdan daha yeni veri var.\nTamam — buluttakini al\nİptal — bu cihazdakini kaydet")))applyCloud(r);else await doUp()}catch(e){}finally{_bz=0}}
window.syncX=pull;window.srSess=sess;setInterval(()=>{try{if(document.hidden||!ld()||LS('sr_auto')==='0'||_bz)return;if(hs()!==LS('sr_sb_h')){clearTimeout(window._ast);window._ast=setTimeout(()=>pull(),2500)}}catch(e){}},7000);setInterval(pull,120000);setInterval(()=>mAuto(),600000);document.addEventListener('visibilitychange',()=>{pull();if(!document.hidden)mAuto()});setTimeout(()=>pull().then(()=>mAuto()),1500);
const CN={notes:'📝 Eslatmalar',tasks:'✅ Vazifalar',goals:'🎯 Maqsadlar',pics:'🖼 Rasmlar',music:'🎧 Musiqa',movies:'🎬 Kinolar',clips:'📹 Videolar',poems:'📖 She’rlar',exp:'💰 Xarajatlar',set:'⚙️ Sozlamalar',ai:'🤖 Sun’iy intellekt',lib:'📚 Kutubxona',cal:'📅 Kalendar',prava:'🚗 Prava',timer:'⏱ Taymer',lock:'🔒 Qulf',hm:'🏠 Bosh sahifa',acc:'👤 Akkaunt'};
let AM='in',AMSG='';
const ER=m=>{m=String(m||'');const x=m.toLowerCase();
if(x.includes('invalid login'))return T("Email yoki parol noto‘g‘ri","Неверный email или пароль","E-posta veya parola hatalı");
if(x.includes('not confirmed'))return T("Email tasdiqlanmagan: pochtadagi xatdagi havolani bosing","Email не подтверждён: нажмите ссылку в письме","E-posta onaylanmadı: mesajdaki bağlantıya tıklayın");
if(x.includes('already'))return T("Bu email ro‘yxatdan o‘tgan: «Kirish» ni bosing","Этот email уже зарегистрирован: нажмите «Вход»","Bu e-posta kayıtlı: «Giriş» yapın");
if(x.includes('rate limit')||x.includes('too many')||x.includes('security purposes'))return T("Juda ko‘p urinish. 1 daqiqa kutib qayta urining","Слишком много попыток. Подождите минуту","Çok fazla deneme. Bir dakika bekleyin");
if(x.includes('weak')||x.includes('password should'))return T("Parol juda oddiy. Harf va raqam ishlating","Пароль слишком простой","Parola çok basit");
if(x.includes('different from the old')||x.includes('same password'))return T("Yangi parol eskisidan farq qilsin","Новый пароль должен отличаться","Yeni parola farklı olmalı");
if(x.includes('expired')||x.includes('invalid'))return T("Kod yoki havola noto‘g‘ri yoki eskirgan. Qayta yuboring","Код или ссылка неверны или устарели","Kod veya bağlantı hatalı ya da eskimiş");
if(x.includes('fetch')||x.includes('network'))return T("Internet yo‘q yoki ulanib bo‘lmadi","Нет интернета","İnternet yok");
return m};
const pwSc=p=>(p.length>=8)+(/[A-Z]/.test(p)&&/[a-z]/.test(p))+(/\d/.test(p)&&/[A-Za-z]/.test(p))+(/[^A-Za-z0-9]/.test(p));
const rdr=()=>'?redirect_to='+encodeURIComponent(location.origin+location.pathname);
function authUI(b,R){const sm=AM=='up',fg=AM=='fp',rs=AM=='rs';
const pwf=(id,ph)=>`<div class="pw"><input id="${id}" data-pw type="password" autocomplete="${sm||rs?'new-password':'current-password'}" placeholder="${ph}"><button type="button" class="eye" data-e>👁</button></div>`;
const P1=T("Parol","Пароль","Parola"),P2=T("Yangi parol (8+, harf va raqam)","Новый пароль (8+, буквы и цифры)","Yeni parola (8+, harf ve rakam)"),P3=T("Parolni takrorlang","Повторите пароль","Parolayı tekrarlayın");
const H=rs?[T("Yangi parol o‘rnating","Задайте новый пароль","Yeni parola belirleyin"),'🔑']:fg?[T("Parolni tiklash","Восстановление пароля","Parola sıfırlama"),'🔑']:sm?[T("Yangi akkaunt yarating","Создайте аккаунт","Hesap oluşturun"),'☁️']:[T("Xush kelibsiz","Добро пожаловать","Hoş geldiniz"),'☁️'];
let body='';
if(rs)body=`${pwf('cp',P2)}${pwf('cp2',P3)}<div class="sb"><i id="cb"></i></div><button class="btn pri" id="cg">${T("Parolni saqlash","Сохранить пароль","Parolayı kaydet")}</button>`;
else if(fg)body=`<input id="ce" type="email" autocomplete="email" placeholder="Email"><button class="btn pri" id="cg">📩 ${T("Tiklash xatini yuborish","Отправить письмо","Sıfırlama gönder")}</button><small class="mu">${T("Xatdagi havolani bosing yoki xatdagi kodni pastga yozing (Spam papkasini ham ko‘ring)","Нажмите ссылку в письме или введите код ниже (проверьте Спам)","Mesajdaki bağlantıya tıklayın veya kodu yazın (Spam'a da bakın)")}</small><input id="ck" inputmode="numeric" placeholder="${T("Xatdagi kod (ixtiyoriy)","Код из письма (необязательно)","Koddan (isteğe bağlı)")}">${pwf('cp',P2)}<button class="btn" id="cv">${T("Kod bilan parolni yangilash","Обновить пароль по коду","Kodla parolayı güncelle")}</button><button class="lnk" data-m="in">← ${T("Kirishga qaytish","Назад ко входу","Girişe dön")}</button>`;
else body=`<button type="button" class="btn" id="cgo" style="width:100%">🔵 ${T("Google bilan kirish","Войти через Google","Google ile giriş")}</button><div class="mu" style="text-align:center;margin:.5rem 0">${T("yoki email bilan","или по email","veya e-posta ile")}</div><input id="ce" type="email" autocomplete="email" placeholder="Email">${pwf('cp',sm?P2:P1)}${sm?`<div class="sb"><i id="cb"></i></div>${pwf('cp2',P3)}`:''}<button class="btn pri" id="cg">${sm?T("Ro‘yxatdan o‘tish","Зарегистрироваться","Kayıt ol"):T("Kirish","Войти","Giriş")}</button>${sm?'':`<button class="lnk" data-m="fp">${T("Parolni unutdingizmi?","Забыли пароль?","Parolayı unuttunuz mu?")}</button>`}`;
b.innerHTML=`<div class="cld"><div class="cr" style="--p:0"><span>${H[1]}</span></div><b style="font-size:1.2rem">${H[0]}</b>${rs||fg?'':`<small class="mu">🔒 ${T("Ma’lumotlaringiz faqat sizniki","Данные видите только вы","Verileri yalnızca siz görürsünüz")}</small>`}</div>${rs||fg?'':`<div class="seg"><button data-m="in" class="${sm?'':'on'}">${T("Kirish","Вход","Giriş")}</button><button data-m="up" class="${sm?'on':''}">${T("Ro‘yxat","Регистрация","Kayıt")}</button></div>`}<div class="card add">${body}</div><div id="cx"></div><p class="mu" id="cm" style="text-align:center"></p>`;
const q=x=>b.querySelector(x),msg=x=>{q('#cm').textContent=x},val=id=>(q('#'+id)||{value:''}).value;
if(AMSG){msg(AMSG);AMSG=''}
b.querySelectorAll('[data-m]').forEach(e=>e.onclick=()=>{AM=e.dataset.m;R()});
b.querySelectorAll('[data-e]').forEach(e=>e.onclick=()=>b.querySelectorAll('[data-pw]').forEach(i=>i.type=i.type=='password'?'text':'password'));
const pw=q('#cp');if(pw&&q('#cb'))pw.oninput=()=>{const n=pwSc(pw.value),c=q('#cb');c.style.width=n*25+'%';c.style.background=['#ef4444','#ef4444','#f59e0b','#84cc16','#22c55e'][n]};
const run=async f=>{msg('⏳');try{await f()}catch(e){msg('⚠ '+ER(e.message))}};
const okE=e=>/^\S+@\S+\.\S+$/.test(e),okP=p=>p.length>=8&&/[A-Za-z]/.test(p)&&/\d/.test(p);
const bad=T("Parol kamida 8 belgi, harf va raqamdan iborat bo‘lsin","Пароль: минимум 8 символов, буквы и цифры","Parola en az 8 karakter, harf ve rakam içermeli");
const resend=em=>{q('#cx').innerHTML=`<button class="btn" id="cs" style="width:100%">📩 ${T("Xatni qayta yuborish","Отправить письмо ещё раз","Mesajı tekrar gönder")}</button>`;q('#cs').onclick=()=>run(async()=>{await api('/auth/v1/resend',{m:'POST',b:{type:'signup',email:em}});msg('✅ '+T("Xat yuborildi. Spam papkasini ham ko‘ring","Письмо отправлено. Проверьте Спам","Mesaj gönderildi. Spam'a da bakın"))})};
const setPw=async(at,np)=>{await api('/auth/v1/user',{m:'PUT',h:{Authorization:'Bearer '+at},b:{password:np}})};
const g=q('#cg');if(!g)return;
if(rs)g.onclick=()=>run(async()=>{const p=val('cp');if(!okP(p))throw new Error(bad);if(p!==val('cp2'))throw new Error(T("Parollar bir xil emas","Пароли не совпадают","Parolalar aynı değil"));const s=await sess();await setPw(s.at,p);AM='in';AMSG='✅ '+T("Parol yangilandi","Пароль обновлён","Parola güncellendi");R()});
else if(fg){g.onclick=()=>run(async()=>{const e=val('ce').trim();if(!okE(e))throw new Error(T("Email to‘g‘ri emas","Неверный email","E-posta hatalı"));await api('/auth/v1/recover'+rdr(),{m:'POST',b:{email:e}});msg('✅ '+T("Xat yuborildi. Pochtani (Spam ham) tekshiring","Письмо отправлено. Проверьте почту (и Спам)","Mesaj gönderildi. Postanızı (Spam dahil) kontrol edin"))});
q('#cv').onclick=()=>run(async()=>{const e=val('ce').trim(),k=val('ck').trim(),p=val('cp');if(!okE(e)||!k)throw new Error(T("Email va xatdagi kodni kiriting","Введите email и код из письма","E-posta ve kodu girin"));if(!okP(p))throw new Error(bad);const s=keep(await api('/auth/v1/verify',{m:'POST',b:{type:'recovery',email:e,token:k}}));if(!s)throw new Error('invalid');await setPw(s.at,p);AM='in';AMSG='✅ '+T("Parol yangilandi","Пароль обновлён","Parola güncellendi");R()})}
else if(sm)g.onclick=()=>run(async()=>{const e=val('ce').trim(),p=val('cp');if(!okE(e))throw new Error(T("Email to‘g‘ri emas","Неверный email","E-posta hatalı"));if(!okP(p))throw new Error(bad);if(p!==val('cp2'))throw new Error(T("Parollar bir xil emas","Пароли не совпадают","Parolalar aynı değil"));const j=await api('/auth/v1/signup'+rdr(),{m:'POST',b:{email:e,password:p}});if(keep(j)){await pull(1);mAuto(1);R();return}if(j&&j.user&&j.user.identities&&!j.user.identities.length)throw new Error('already registered');msg('✅ '+T("Xat yuborildi: pochtadagi havolani bosing, keyin «Kirish» ni bosing","Письмо отправлено: нажмите ссылку, затем «Вход»","Mesaj gönderildi: bağlantıya tıklayın, sonra «Giriş»"));resend(e)});
else g.onclick=()=>run(async()=>{const e=val('ce').trim(),p=val('cp');if(!okE(e)||!p)throw new Error(T("Email va parolni kiriting","Введите email и пароль","E-posta ve parola girin"));try{await auth(e,p,0)}catch(x){if(/not confirmed/i.test(x.message))resend(e);throw x}msg('⏳ '+T('Bulutdan ma’lumotlar tekshirilmoqda…','Проверяем данные в облаке…','Buluttaki veriler kontrol ediliyor…'));await pull(1);mAuto(1);R()})}
(async()=>{const h=location.hash;if(!/access_token=|error=/.test(h))return;const p=new URLSearchParams(h.slice(1)),at=p.get('access_token');history.replaceState(null,'',location.pathname+location.search);
if(!at){AM='fp';AMSG=T("Havola eskirgan. Qayta yuboring","Ссылка устарела. Отправьте заново","Bağlantı eskimiş. Tekrar gönderin");setTimeout(()=>{try{vCloud()}catch(e){}},500);return}
try{const u=await api('/auth/v1/user',{h:{Authorization:'Bearer '+at}});sv({at,rt:p.get('refresh_token'),id:u.id,em:u.email,exp:Date.now()+(+p.get('expires_in')||3600)*1000-60000});if(p.get('type')=='recovery')AM='rs';else pull(1);setTimeout(()=>{try{vCloud()}catch(e){}},500)}catch(e){}})();

/* ===== Media zaxira (Supabase Storage): musiqa, kino, video, rasm ===== */
const MB=1048576,MAXF=50*MB,MAXU=900*MB,BK='sr-media',MK=['music','movies','clips'];
const spx=(s,k,id)=>s.id+'/'+(ACT||'main')+'/'+k+'/'+id;
async function stApi(s,m,p,o){o=o||{};const r=await fetch(U+'/storage/v1/'+p,{method:m,headers:Object.assign({apikey:K,Authorization:'Bearer '+s.at},o.h||{}),body:o.b});if(!r.ok){let j=null;try{j=await r.json()}catch(e){}throw new Error((j&&(j.message||j.error))||('HTTP '+r.status))}return r}
async function cloudList(s){const out={},pre=s.id+'/'+(ACT||'main')+'/';for(const k of MK.concat('pics')){let off=0;for(;;){const r=await stApi(s,'POST','object/list/'+BK,{h:{'Content-Type':'application/json'},b:JSON.stringify({prefix:pre+k,limit:100,offset:off})}),j=await r.json();j.forEach(x=>{if(x.name)out[k+'/'+x.name]=(x.metadata&&x.metadata.size)||0});if(j.length<100)break;off+=100}}return out}
async function localItems(){const L=[];D.lib=D.lib||{};for(const k of MK)for(const x of D.lib[k]||[]){try{const b=await dbx('readonly',q=>q.get(x.id));if(b)L.push({k,id:String(x.id),b})}catch(e){}}try{for(const p of await pAll())if(p.blob)L.push({k:'pics',id:String(p.id),b:p.blob})}catch(e){}return L}
async function mUp(s,say){const cl=await cloudList(s),L=await localItems();let used=Object.values(cl).reduce((a,b)=>a+b,0),n=0,big=0,full=0;
for(let i=0;i<L.length;i++){const it=L[i];if(it.k+'/'+it.id in cl)continue;if(it.b.size>MAXF){big++;continue}if(used+it.b.size>MAXU){full++;continue}
say('⏳ '+(i+1)+' / '+L.length+' · '+kb(it.b.size));
await stApi(s,'POST','object/'+BK+'/'+spx(s,it.k,it.id),{h:{'x-upsert':'true','Content-Type':it.b.type||'application/octet-stream'},b:it.b});used+=it.b.size;n++}
return{n,big,full}}
async function mDown(s,say,only){const cl=await cloudList(s),have=new Set((await localItems()).map(x=>x.k+'/'+x.id)),keys=(only||Object.keys(cl)).filter(k=>!have.has(k));let n=0;
for(let i=0;i<keys.length;i++){const[k,id]=keys[i].split('/');say('⏳ '+(i+1)+' / '+keys.length);const b=await(await stApi(s,'GET','object/authenticated/'+BK+'/'+spx(s,k,id))).blob();
if(k=='pics')await pPut({id,name:'photo',ts:+id.slice(0,13)||Date.now(),blob:b,th:b});else await dbx('readwrite',q=>q.put(b,+id));n++}
return n}
function mediaCard(el,s,R){if(!el)return;
el.innerHTML='<b>🎞 '+T("Media zaxira","Резерв медиа","Medya yedeği")+'</b><div class="mu" id="mi" style="margin:.4rem 0">⏳</div><button class="btn pri" id="mu" style="width:100%;margin-bottom:.4rem">⬆ '+T("Mediani bulutga yuklash","Загрузить медиа в облако","Medyayı buluta yükle")+'</button><button class="btn" id="md" style="width:100%">⬇ '+T("Mediani bulutdan tiklash","Восстановить медиа","Medyayı buluttan geri yükle")+'</button><small class="mu" id="mm" style="display:block;margin-top:.4rem">'+T("Bitta fayl 50 MB gacha, jami 900 MB gacha. Kattalari Google Drive orqali.","Файл до 50 МБ, всего до 900 МБ. Большие — через Google Drive.","Dosya 50 MB, toplam 900 MB’a kadar. Büyükler Google Drive ile.")+'</small>';
const q=x=>el.querySelector(x),say=x=>{q('#mm').textContent=x},busy=f=>{q('#mu').disabled=q('#md').disabled=f};
const info=async()=>{try{const[L,cl]=await Promise.all([localItems(),cloudList(s)]),ls=L.reduce((a,x)=>a+x.b.size,0),cs=Object.values(cl).reduce((a,b)=>a+b,0);q('#mi').innerHTML='📱 '+T("Qurilmada","На устройстве","Cihazda")+': <b>'+L.length+'</b> · '+kb(ls)+'<br>☁️ '+T("Bulutda","В облаке","Bulutta")+': <b>'+Object.keys(cl).length+'</b> · '+kb(cs)+' / 900 MB'}catch(e){q('#mi').textContent='⚠ '+ER(e.message)}};info();
q('#mu').onclick=async()=>{busy(1);try{const r=await mUp(s,say);say('✅ '+r.n+' '+T("ta fayl yuklandi","файлов загружено","dosya yüklendi")+(r.big?' · '+r.big+' '+T("ta juda katta (50 MB+)","слишком большие","çok büyük"):'')+(r.full?' · '+r.full+' '+T("ta joy yetmadi","нет места","yer yok"):''))}catch(e){say('⚠ '+ER(e.message))}busy(0);info()};
q('#md').onclick=async()=>{busy(1);try{const n=await mDown(s,say);say('✅ '+n+' '+T("ta fayl tiklandi","файлов восстановлено","dosya geri yüklendi")+(n?' · '+T("Sahifani yangilang","Обновите страницу","Sayfayı yenileyin"):''))}catch(e){say('⚠ '+ER(e.message))}busy(0);info()}}

let _mz=0;
async function mAuto(f){if(_mz||!ld()||(!f&&LS('sr_auto')==='0'))return;_mz=1;try{const s=await sess();await mUp(s,()=>{});
const cl=await cloudList(s),L=await localItems(),have=new Set(L.map(x=>x.k+'/'+x.id)),lib=D.lib||{},first=!LS('sr_mdl');
const miss=Object.keys(cl).filter(k=>{if(have.has(k))return false;const a=k.split('/')[0],id=k.split('/')[1];return a=='pics'?first:(lib[a]||[]).some(x=>String(x.id)==id)});
if(miss.length){const sz=miss.reduce((a,k)=>a+cl[k],0);
if(sz<=30*MB||(!window._mno&&confirm(T("Bulutda "+miss.length+" ta media fayl bor ("+kb(sz)+"). Shu qurilmaga yuklab olinsinmi?","В облаке "+miss.length+" медиафайлов ("+kb(sz)+"). Скачать на это устройство?","Bulutta "+miss.length+" medya dosyası var ("+kb(sz)+"). Bu cihaza indirilsin mi?")))){LS('sr_mdl','1');const n=await mDown(s,()=>{},miss);if(n){location.reload();return}}else window._mno=1}
LS('sr_mdl','1')}catch(e){}finally{_mz=0}}
/* ===== Google Drive zaxira: hamma media (har kimning o'z Drive'iga) ===== */
const GS='https://www.googleapis.com/auth/drive.file',GFN='SR Programma',gpre=()=>(ACT||'main')+'__';
let gTok=null,gExp=0,gFold=null;
const gCid=()=>(LS('sr_gcid')||'').replace(/\s+/g,'');
function gLoad(){return new Promise((res,rej)=>{if(window.google&&google.accounts&&google.accounts.oauth2)return res();const e=document.createElement('script');e.src='https://accounts.google.com/gsi/client';e.onload=()=>res();e.onerror=()=>rej(new Error('Google yuklanmadi (internet?)'));document.head.appendChild(e)})}
async function gAuth(){if(gTok&&Date.now()<gExp)return gTok;const id=gCid();if(!id)throw new Error(T("Avval Client ID kiriting","Сначала введите Client ID","Önce Client ID girin"));if(!/^\d+-[a-z0-9]+\.apps\.googleusercontent\.com$/i.test(id))throw new Error('Client ID noto‘g‘ri: «raqam-harflar.apps.googleusercontent.com» ko‘rinishida bo‘lishi kerak');await gLoad();return new Promise((res,rej)=>{const c=google.accounts.oauth2.initTokenClient({client_id:id,scope:GS,callback:r=>{if(r.error)return rej(new Error(r.error_description||r.error));gTok=r.access_token;gExp=Date.now()+(+r.expires_in||3600)*1000-60000;res(gTok)},error_callback:e=>rej(new Error(e.type||'popup'))});c.requestAccessToken({prompt:gTok?'':'consent'})})}
async function gf(u,o){o=o||{};const t=await gAuth();const r=await fetch(u,{method:o.m||'GET',headers:Object.assign({Authorization:'Bearer '+t},o.h||{}),body:o.b});if(!r.ok){let j=null;try{j=await r.json()}catch(e){}if(r.status==401)gTok=null;throw new Error((j&&j.error&&(j.error.message||j.error))||('HTTP '+r.status))}return r}
async function gFolder(){if(gFold)return gFold;const q=encodeURIComponent("name='"+GFN+"' and mimeType='application/vnd.google-apps.folder' and trashed=false"),j=await(await gf('https://www.googleapis.com/drive/v3/files?q='+q+'&fields=files(id)')).json();if(j.files&&j.files.length)return gFold=j.files[0].id;const c=await(await gf('https://www.googleapis.com/drive/v3/files?fields=id',{m:'POST',h:{'Content-Type':'application/json'},b:JSON.stringify({name:GFN,mimeType:'application/vnd.google-apps.folder'})})).json();return gFold=c.id}
async function gList(){const f=await gFolder(),out=[];let pt='';do{const q=encodeURIComponent("'"+f+"' in parents and trashed=false"),j=await(await gf('https://www.googleapis.com/drive/v3/files?q='+q+'&pageSize=1000&fields=nextPageToken,files(id,name,size)'+(pt?'&pageToken='+pt:''))).json();(j.files||[]).forEach(x=>{if(x.name.startsWith(gpre()))out.push({id:x.id,name:x.name,size:+x.size||0})});pt=j.nextPageToken||''}while(pt);return out}
async function gPut(name,blob,eid){if(eid){await gf('https://www.googleapis.com/upload/drive/v3/files/'+eid+'?uploadType=media',{m:'PATCH',h:{'Content-Type':blob.type||'application/octet-stream'},b:blob});return}
const f=await gFolder(),r=await gf('https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields=id',{m:'POST',h:{'Content-Type':'application/json; charset=UTF-8','X-Upload-Content-Type':blob.type||'application/octet-stream','X-Upload-Content-Length':String(blob.size)},b:JSON.stringify({name,parents:[f]})}),loc=r.headers.get('Location');if(!loc)throw new Error('Drive: Location yo‘q');
const t=await gAuth(),u=await fetch(loc,{method:'PUT',headers:{'Content-Type':blob.type||'application/octet-stream'},body:blob});if(!u.ok)throw new Error('Drive HTTP '+u.status)}
const gKey=n=>{const m=n.slice(gpre().length).split('__');return m.length>=2&&m[0]!='meta.json'?m[0]+'/'+m[1]:null};
async function gUp(say){const ex=await gList(),have=new Set(ex.map(x=>gKey(x.name)).filter(Boolean)),L=await localItems();let n=0;
for(let i=0;i<L.length;i++){const it=L[i],key=it.k+'/'+it.id;if(have.has(key))continue;say('⏳ '+(i+1)+' / '+L.length+' · '+kb(it.b.size));await gPut(gpre()+it.k+'__'+it.id+'__',it.b);n++}
const meta=new Blob([JSON.stringify({lib:D.lib||{}})],{type:'application/json'}),mf=ex.find(x=>x.name==gpre()+'meta.json');await gPut(gpre()+'meta.json',meta,mf&&mf.id);return n}
async function gDown(say){const ex=await gList(),have=new Set((await localItems()).map(x=>x.k+'/'+x.id)),mf=ex.find(x=>x.name==gpre()+'meta.json');
if(mf){try{const j=JSON.parse(await(await gf('https://www.googleapis.com/drive/v3/files/'+mf.id+'?alt=media')).text());D.lib=D.lib||{};for(const k of MK){const A=D.lib[k]=D.lib[k]||[];(j.lib&&j.lib[k]||[]).forEach(x=>{if(!A.some(z=>String(z.id)==String(x.id)))A.push(x)})}save()}catch(e){}}
const todo=ex.filter(x=>{const k=gKey(x.name);return k&&!have.has(k)});let n=0;
for(let i=0;i<todo.length;i++){const[k,id]=gKey(todo[i].name).split('/');say('⏳ '+(i+1)+' / '+todo.length+' · '+kb(todo[i].size));const b=await(await gf('https://www.googleapis.com/drive/v3/files/'+todo[i].id+'?alt=media')).blob();
if(k=='pics')await pPut({id,name:'photo',ts:+id.slice(0,13)||Date.now(),blob:b,th:b});else await dbx('readwrite',q=>q.put(b,+id));n++}return n}
function driveCard(el){if(!el)return;
el.innerHTML='<b>🟢 Google Drive</b><div class="mu" style="margin:.3rem 0">'+T("Kino, musiqa, video, rasm: hammasi o‘z Google Drive’ingizga (15 GB) saqlanadi.","Кино, музыка, видео, фото: всё в ваш Google Drive (15 ГБ).","Film, müzik, video, fotoğraf: hepsi Google Drive’ınıza (15 GB) kaydedilir.")+'</div><input id="gc" placeholder="Google Client ID" value="'+esc(gCid())+'" autocomplete="off"><div class="mu" id="gi" style="margin:.4rem 0"></div><button class="btn pri" id="gu" style="width:100%;margin-bottom:.4rem">⬆ '+T("Hammasini Drive’ga yuklash","Загрузить всё на Drive","Hepsini Drive’a yükle")+'</button><button class="btn" id="gd" style="width:100%">⬇ '+T("Drive’dan tiklash","Восстановить с Drive","Drive’dan geri yükle")+'</button><small class="mu" id="gm" style="display:block;margin-top:.4rem"></small>';
const q=x=>el.querySelector(x),say=x=>{q('#gm').textContent=x},busy=f=>{q('#gu').disabled=q('#gd').disabled=f};
q('#gc').onchange=e=>{e.target.value=e.target.value.replace(/\s+/g,'');LS('sr_gcid',e.target.value);gTok=null;gFold=null;say('✓')};
const info=async()=>{if(!gCid()||!gTok){q('#gi').textContent=gCid()?T("Yuklash tugmasini bossangiz Google ruxsat so‘raydi","Нажмите «Загрузить»: Google запросит доступ","Yükle’ye basınca Google izin ister"):'';return}try{const[L,ex]=await Promise.all([localItems(),gList()]),ls=L.reduce((a,x)=>a+x.b.size,0),cs=ex.reduce((a,x)=>a+x.size,0);q('#gi').innerHTML='📱 '+L.length+' · '+kb(ls)+'<br>🟢 Drive: '+ex.length+' · '+kb(cs)}catch(e){}};info();
q('#gu').onclick=async()=>{q('#gc').onchange({target:q('#gc')});busy(1);try{const n=await gUp(say);say('✅ '+n+' '+T("ta fayl yuklandi","файлов загружено","dosya yüklendi"))}catch(e){say('⚠ '+ER(e.message))}busy(0);info()};
q('#gd').onclick=async()=>{q('#gc').onchange({target:q('#gc')});busy(1);try{const n=await gDown(say);say('✅ '+n+' '+T("ta fayl tiklandi","файлов восстановлено","dosya geri yüklendi")+(n?' · '+T("Sahifani yangilang","Обновите страницу","Sayfayı yenileyin"):''))}catch(e){say('⚠ '+ER(e.message))}busy(0);info()}}
function vCloud(){push(()=>'☁️ '+t('cloud'),b=>{const R=()=>{const s=ld();
if(!s||AM=='rs'){authUI(b,R);return}
const tot=JSON.stringify(D).length,pct=Math.min(100,Math.round(tot/5242880*100)),sy=hs()===LS('sr_sb_h'),lt=LS('sr_sb_t')||'—';
const rows=Object.keys(D).map(k=>[k,JSON.stringify(D[k]).length]).sort((x,y)=>y[1]-x[1]).slice(0,6).map(([k,n])=>`<div class="krow"><span>${CN[k]||('📁 '+esc(k))}</span><b>${kb(n)}</b></div><div class="bar" style="height:.35rem;margin:0 0 .3rem"><i style="width:${Math.max(2,Math.round(n/tot*100))}%"></i></div>`).join('');
b.innerHTML=`<div class="cld"><div class="cr" style="--p:${sy?100:60}"><span>☁️</span></div><b>${esc(s.em||'')}</b><small class="st ${sy?'ok':'warn'}">${sy?'✅ '+T("Hammasi bulutda saqlangan","Всё сохранено в облаке","Her şey bulutta kayıtlı"):'🟡 '+T("Saqlanmagan o‘zgarishlar bor","Есть несохранённые изменения","Kaydedilmemiş değişiklikler var")}</small><small class="mu">🕒 ${T("Oxirgi saqlash","Последнее сохранение","Son kayıt")}: <span id="cls">${esc(lt)}</span></small><small class="mu" id="cinfo"></small></div>
<div class="card"><b>📦 ${T("Qurilma xotirasi","Память устройства","Cihaz belleği")}</b><div class="bar"><i style="width:${Math.max(2,pct)}%"></i></div><div class="krow"><span class="mu">${kb(tot)} / 5 MB</span><span class="mu">${pct}%</span></div>${rows}</div>
<button class="btn pri" id="cu" style="width:100%;margin-bottom:.5rem">☁️ ${T("Hozir bulutga saqlash","Сохранить в облако сейчас","Şimdi buluta kaydet")}</button><button class="btn" id="cd" style="width:100%;margin-bottom:.5rem">⬇ ${T("Bulutdan tiklash","Восстановить из облака","Buluttan geri yükle")}</button>
<label class="card krow" style="align-items:center"><span>⚡ ${T("Avtomatik saqlash","Автосохранение","Otomatik kayıt")}<br><small class="mu">${T("Har 2 daqiqada va ilovadan chiqqanda","Каждые 2 мин. и при выходе","Her 2 dk ve çıkışta")}</small></span><input type="checkbox" id="ca" ${LS('sr_auto')!=='0'?'checked':''} style="width:1.4rem;height:1.4rem"></label>
<div class="card" id="cdrive"></div><div class="card" id="cmedia"></div><button class="btn bad" id="co" style="width:100%">${T("Chiqish","Выйти","Çıkış")}</button><p class="mu" id="cm" style="text-align:center"></p>`;
const m=x=>{$('#cm').textContent=x};driveCard($('#cdrive'));mediaCard($('#cmedia'),s,R);
api('/rest/v1/sr_backup?select=updated_at&user_id=eq.'+s.id,{h:{Authorization:'Bearer '+s.at,apikey:K}}).then(j=>{const e=$('#cinfo');if(e)e.textContent=j&&j.length?'☁️ '+T("Bulutdagi nusxa","Копия в облаке","Buluttaki kopya")+': '+new Date(j[0].updated_at).toLocaleString():'☁️ '+T("Bulutda hali nusxa yo‘q","В облаке ещё нет копии","Bulutta henüz kopya yok")}).catch(()=>{});
$('#cu').onclick=async()=>{m('⏳');try{if(gCid())try{await gAuth()}catch(x){}await doUp();m('⏳ '+T('Media tekshirilmoqda…','Проверяем медиа…','Medya kontrol ediliyor…'));await mAuto(1);if(gCid()&&gTok){try{await gUp(m)}catch(x){}}R();$('#cm').textContent='✅ '+T("Saqlandi","Сохранено","Kaydedildi")}catch(e){m('⚠ '+e.message)}};
$('#cd').onclick=async()=>{m('⏳');try{const r=await down(),d=new Date(r.updated_at).toLocaleString();if(!confirm(T("Bulutdagi nusxa: ","Копия в облаке: ","Buluttaki kopya: ")+d+' · '+kb(JSON.stringify(r.data).length)+'\n'+T("Qurilmadagi ma’lumotlar almashtiriladi. Davom etasizmi?","Данные на устройстве будут заменены. Продолжить?","Cihazdaki veriler değiştirilecek. Devam?"))){m('');return}applyCloud(r)}catch(e){m('⚠ '+e.message)}};
$('#ca').onchange=e=>{LS('sr_auto',e.target.checked?'1':'0');m(e.target.checked?'⚡ '+T("Avtomatik saqlash yoqildi","Автосохранение включено","Otomatik kayıt açıldı"):'')};
$('#co').onclick=()=>{sv(null);R()}};R()})}
const G1=GOM;GOM=function(){const o=G1();o.cloud=vCloud;return o};
/* ===== v11: kirish darvozasi — SR oynasidan keyin email + parol ===== */
const GK='sr_gate',GTS='sr_gate_ts',GGR='sr_gate_gr',GHD='sr_gate_hid';
const gRec=()=>{try{return JSON.parse(localStorage.getItem(GK)||'null')}catch(e){return null}};
const gGr=()=>{const v=LS(GGR);return v===null||v===undefined?0:+v||0};
const gTs=()=>LS(GTS,String(Date.now()));
const gNeed=()=>{const sk=+(LS('sr_gate_skip')||0);if(sk){LS('sr_gate_skip','');if(Date.now()-sk<30000)return false}const g=gGr();if(!g)return true;const t=+(LS(GTS)||0);return !t||Date.now()-t>g*60000};
function gSwitch(){if(!confirm(trU('Bu akkauntdan chiqilsinmi? Keyin boshqa akkaunt bilan kirasiz.')))return;['sr_gate','sr_gate_g','sr_gate_ts','sr_gate_gr','sr_gate_hid','sr_gate_bad','sr_gate_until','sr_gate_rsd','sr_gate_skip','sr_sb','sr_sb_h','sr_sb_c','sr_sb_t'].forEach(k=>{try{localStorage.removeItem(k)}catch(e){}});location.reload()}
const gMask=e=>String(e||'').replace(/^(.{1,2}).*(@.*)$/,'$1•••$2');
async function gHash(pw,salt){try{const k=await crypto.subtle.importKey('raw',new TextEncoder().encode(pw),'PBKDF2',false,['deriveBits']);const b=await crypto.subtle.deriveBits({name:'PBKDF2',salt:ub(salt),iterations:120000,hash:'SHA-256'},k,256);return 'p'+b64(b)}catch(e){let h=await sha(salt+':'+pw);for(let i=0;i<1500;i++)h=await sha(h);return 'f'+h}}
const gErr=m=>{m=String(m||'');const x=m.toLowerCase();
 if(x.includes('invalid login'))return 'Email yoki parol noto‘g‘ri';
 if(x.includes('not confirmed'))return 'Email tasdiqlanmagan: pochtadagi xatdagi havolani bosing';
 if(x.includes('already'))return 'Bu email ro‘yxatdan o‘tgan: «Kirish» ni bosing';
 if(x.includes('rate limit')||x.includes('too many')||x.includes('security purposes'))return 'Juda ko‘p urinish. 1 daqiqa kutib qayta urining';
 if(x.includes('weak')||x.includes('password should'))return 'Parol juda oddiy. Harf va raqam ishlating';
 if(x.includes('fetch')||x.includes('network'))return 'Internet yo‘q yoki ulanib bo‘lmadi';
 return m};
const gFresh=()=>{const n=a=>Array.isArray(a)?a.length:a&&typeof a=='object'?Object.keys(a).length:0;const l=D.lib||{};
 return !(n(D.notes)||n(D.tasks)||n(D.exp)||n(D.plan)||n(D.routine)||n(D.goals)||n(D.poems)||n(D.ltc)||n(D.tk)||n(D.lg)||n(D.hm&&D.hm.tasks)||n(l.music)||n(l.movies)||n(l.clips)||(D.xp|0)||n(D.set&&D.set.alm))};
async function gRestore(){try{if(!ld()||!navigator.onLine||!gFresh())return;let r;try{r=await down()}catch(e){return}if(!r||!r.data)return;
 const stamp=String(r.updated_at||'');if(LS('sr_gate_rsd')===stamp)return;LS('sr_gate_rsd',stamp);
 const k=D.ai&&D.ai.key,x=r.data.__x||{},d=Object.assign({},r.data);delete d.__x;Object.assign(D,d);D.set=Object.assign({lang:'uz',theme:'tun',fs:1},D.set);if(D.ai)D.ai.key=k||'';save();Object.keys(x).forEach(q=>{if(x[q]!=null)LS(q,x[q])});
 LS('sr_sb_h',hs());LS('sr_sb_c',String(Date.parse(r.updated_at)||0));LS('sr_sb_t',new Date().toLocaleString());LS('sr_sb_rs','1');
 if(gFresh()&&!Object.keys(x).length)return;
 toast(trU('Bulutdagi ma’lumotlar tiklandi'));LS('sr_gate_skip',String(Date.now()));setTimeout(()=>location.reload(),900)}catch(e){}}
function gDone(o,pw){gTs();if(LS('sr_auto')===null||LS('sr_auto')===undefined)LS('sr_auto','1');o.classList.add('go');setTimeout(()=>o.remove(),450);
 if(pw&&navigator.onLine){const r=gRec();if(r)auth(r.em,pw,0).then(gRestore).catch(()=>gRestore())}else gRestore()}
function gShow(mode){let o=document.getElementById('srgt');if(o)o.remove();o=document.createElement('div');o.id='srgt';document.body.appendChild(o);
 const rec=gRec(),pwf=(id,ph,ac)=>`<div class="pw"><input id="${id}" data-pw type="password" autocomplete="${ac}" placeholder="${ph}"><button type="button" class="eye" data-e>👁</button></div>`;
 const langs=`<div class="chips gl" id="gl">${LG.map(l=>`<button data-l="${l}" class="${l==D.set.lang?'on':''}">${l.toUpperCase()}</button>`).join('')}</div>`;
 let up=false;
 const draw=()=>{
  if(mode=='login'){o.innerHTML=`<div class="sr gsr">SR</div><h2>Xush kelibsiz</h2><div class="mu gem">${esc(gMask(rec.em))}</div>${pwf('gp','Parol','current-password')}<button class="btn pri" id="gb">Kirish</button><button class="lnk" id="gf">Parolni unutdingizmi?</button><button class="lnk" id="gsw">Boshqa akkaunt bilan kirish</button><p class="mu gms" id="gm"></p>${langs}`}
  else if(mode=='reset'){o.innerHTML=`<div class="sr gsr">SR</div><h2>Yangi parol o‘rnating</h2>${pwf('gp','Yangi parol (8+, harf va raqam)','new-password')}${pwf('gp2','Parolni takrorlang','new-password')}<button class="btn pri" id="gb">Parolni saqlash</button><p class="mu gms" id="gm"></p>${langs}`}
  else{o.innerHTML=`<div class="sr gsr">SR</div><h2>SR Programma</h2><p class="mu gsb">Kirish uchun akkauntingiz bilan kiring. Ma’lumotlaringiz bulutda saqlanadi va boshqa telefonda ham tiklanadi.</p><button type="button" class="btn" id="cgo" style="width:100%">🔵 Google bilan kirish</button><div class="mu" style="text-align:center;margin:.3rem 0">yoki email bilan</div><input id="ge" type="email" autocomplete="email" placeholder="Email">${pwf('gp',up?'Yangi parol (8+, harf va raqam)':'Parol',up?'new-password':'current-password')}${up?pwf('gp2','Parolni takrorlang','new-password'):''}<button class="btn pri" id="gb">${up?'Ro‘yxatdan o‘tish':'Kirish'}</button>${up?'':'<button class="lnk" id="gf">Parolni unutdingizmi?</button>'}<p class="mu gms" id="gm"></p>${langs}`}
  bind()};
 const q=s=>o.querySelector(s),val=id=>(q('#'+id)||{value:''}).value,msg=s=>{q('#gm').textContent=s;if(window.relangUI)relangUI()};
 const okE=e=>/^\S+@\S+\.\S+$/.test(e),okP=p=>p.length>=8&&/[A-Za-z]/.test(p)&&/\d/.test(p);
 const shake=()=>{o.classList.add('shake');setTimeout(()=>o.classList.remove('shake'),400)};
 async function save2(em,pw){const s=b64(rnd(16));localStorage.setItem(GK,JSON.stringify({v:1,em,s,h:await gHash(pw,s)}))}
 function bind(){
  o.querySelectorAll('[data-e]').forEach(e=>e.onclick=()=>o.querySelectorAll('[data-pw]').forEach(i=>i.type=i.type=='password'?'text':'password'));
  o.querySelector('#gl').onclick=e=>{const l=e.target.dataset.l;if(l){setLang(l);[...o.querySelectorAll('#gl button')].forEach(b=>b.classList.toggle('on',b.dataset.l==l))}};
  o.querySelectorAll('[data-m]').forEach(e=>e.onclick=()=>{up=e.dataset.m=='up';draw()});
  const gb=q('#gb'),run=f=>{gb.disabled=true;msg('⏳');f().catch(e=>{msg(gErr(e.message))}).finally(()=>{gb.disabled=false})};
  const enter=f=>o.addEventListener('keydown',e=>{if(e.key=='Enter'&&e.target.tagName=='INPUT'){e.preventDefault();gb.click()}});enter();
  if(mode=='login')gb.onclick=()=>run(async()=>{const until=+(LS('sr_gate_until')||0);if(Date.now()<until){msg('Juda ko‘p urinish. Biroz kuting');return}const pw=val('gp');if(!pw){msg('');return}
    let ok=false;try{ok=(await gHash(pw,rec.s))===rec.h}catch(e){}
    if(!ok&&navigator.onLine){try{const s=await auth(rec.em,pw,0);if(s){ok=true;await save2(rec.em,pw)}}catch(e){if(!/invalid login|fetch|network/i.test(String(e.message)))throw e}}
    if(!ok){const bad=(+(LS('sr_gate_bad')||0))+1;LS('sr_gate_bad',String(bad));if(bad>=5)LS('sr_gate_until',String(Date.now()+Math.min(300000,30000*(bad-4))));shake();sfx('bad');msg('Parol noto‘g‘ri');return}
    LS('sr_gate_bad','0');sfx('ok');gDone(o,pw)});
  else if(mode=='reset')gb.onclick=()=>run(async()=>{const p=val('gp');if(!okP(p)){msg('Parol kamida 8 belgi, harf va raqamdan iborat bo‘lsin');return}if(p!==val('gp2')){msg('Parollar bir xil emas');return}
    const at=new URLSearchParams((window.__H0||'').replace(/^#/,'')).get('access_token');if(!at){msg('Havola eskirgan. Qayta yuboring');return}
    const u=await api('/auth/v1/user',{h:{Authorization:'Bearer '+at}});await api('/auth/v1/user',{m:'PUT',h:{Authorization:'Bearer '+at},b:{password:p}});
    await save2(u.email,p);AM='in';window.__H0='';sfx('ok');gDone(o,p)});
  else gb.onclick=()=>run(async()=>{const em=val('ge').trim(),pw=val('gp');if(!okE(em)){msg('Email to‘g‘ri emas');return}
    if(up){if(!okP(pw)){msg('Parol kamida 8 belgi, harf va raqamdan iborat bo‘lsin');return}if(pw!==val('gp2')){msg('Parollar bir xil emas');return}
     const j=await api('/auth/v1/signup'+rdr(),{m:'POST',b:{email:em,password:pw}});if(!keep(j)){if(j&&j.user&&j.user.identities&&!j.user.identities.length)throw new Error('already registered');msg('Xat yuborildi: pochtadagi havolani bosing, keyin «Kirish» ni bosing');return}}
    else{if(!pw){msg('');return}await auth(em,pw,0)}
    await save2(ld().em||em,pw);sfx('ok');gDone(o,pw)});
  const gsw=q('#gsw');if(gsw)gsw.onclick=gSwitch;
  const gf=q('#gf');if(gf)gf.onclick=()=>run(async()=>{const em=mode=='login'?rec.em:val('ge').trim();if(!okE(em)){msg('Email to‘g‘ri emas');return}await api('/auth/v1/recover'+rdr(),{m:'POST',b:{email:em}});msg('Xat yuborildi. Pochtani (Spam ham) tekshiring')})}
 draw()}
(function(){const H0=window.__H0||'';
 if(/type=recovery/.test(H0))gShow('reset');else if(!gRec()){if(/access_token=/.test(H0)&&/provider_token=/.test(H0))LS('sr_gate_g','1');if(!(LS('sr_gate_g')&&(ld()||/provider_token=/.test(H0))))gShow('setup')}else if(gNeed())gShow('login');
 document.addEventListener('visibilitychange',()=>{if(document.hidden){LS(GHD,String(Date.now()));gTs();return}
  if(!gRec()||document.getElementById('srgt'))return;const away=Date.now()-(+(LS(GHD)||0)),lim=Math.max(1,gGr())*60000;if(+(LS(GHD)||0)&&away>lim)gShow('login')});
 addEventListener('pagehide',()=>gTs());
 /* Xavfsizlik bo‘limiga «Kirish paroli» kartasi */
 const vs=window.vSec;if(typeof vs=='function')window.vSec=function(){vs();const b=document.getElementById('vb'),r=gRec();if(!b||!r)return;
  const opts=[[0,'Har safar'],[5,'5 daqiqa'],[30,'30 daqiqa'],[60,'1 soat']],g=gGr();
  b.insertAdjacentHTML('afterbegin',`<div class="card" id="gcs" style="margin-bottom:.8rem"><b>🔑 <span>Kirish paroli</span></b><div class="mu" style="margin:.2rem 0 .6rem">${esc(gMask(r.em))}</div><div class="mu" style="margin-bottom:.3rem">Qayta so‘rash</div><div class="chips" id="gcc">${opts.map(([v,l])=>`<button data-v="${v}" class="${v==g?'on':''}">${l}</button>`).join('')}</div><button class="btn" id="gcl" style="width:100%;margin-top:.6rem">🔒 Hozir qulflash</button><button class="btn bad" id="gco" style="width:100%;margin-top:.5rem">↪ Akkauntdan chiqish</button></div>`);
  b.querySelector('#gco').onclick=gSwitch;
  b.querySelector('#gcc').onclick=e=>{const v=e.target.dataset.v;if(v===undefined)return;LS(GGR,v);[...b.querySelectorAll('#gcc button')].forEach(x=>x.classList.toggle('on',x.dataset.v==v))};
  b.querySelector('#gcl').onclick=()=>{LS(GTS,'0');LS(GHD,'0');gShow('login')}};
 window.gShow=gShow})();
applyAll();
})();
;
/* ===== v7: profil paneli (Sozlamalar, Til, Mavzu, Telefon, Bulut, Akkaunt) ===== */
(function(){
const pT=(a,b,c)=>(LI()>2&&window.XP&&XP[a]&&XP[a][LI()-3])||[a,b,c][I()],cs=()=>{try{return JSON.parse(localStorage.getItem('sr_sb')||'null')}catch(e){return null}},
uid=()=>{let u=localStorage.getItem('sr_uid');if(!u){u=String(Math.floor(1e9+Math.random()*9e9));localStorage.setItem('sr_uid',u)}return u},
nmx=()=>(D.set.nm||'SR').trim()||'SR';
function chip(){const s=cs(),n=nmx();$('#pnm2').textContent=n;$('#pav').style.cssText=D.set.pic?"background-image:url('"+D.set.pic+"');background-size:cover;background-position:center":'';$('#pav').innerHTML=(D.set.pic?'':esc(n[0].toUpperCase()))+`<i class="${s?'on':''}"></i>`;
 $('#pst').textContent='👤 '+(s&&s.em?s.em.split('@')[0]:pT('Profil','Профиль','Profil'))+' ›'}
const row=(r,ic,c,l,v)=>`<button class="prow" data-r="${r}"><i style="background:${c}">${ic}</i><span>${l}</span><em>${esc(v||'')}</em><u>›</u></button>`;
function vProf(){push(()=>pT('Profil','Профиль','Profil'),b=>{const s=cs(),n=nmx(),th=['tun','kun','okean'],ln=['Oʻzbekcha','Русский','Türkçe','English','Тоҷикӣ','Deutsch','한국어'][I()];
 b.innerHTML=`<div class="pf"><div class="av big" data-r="pic" style="${D.set.pic?`background-image:url('${D.set.pic}');background-size:cover;background-position:center`:''}">${D.set.pic?'':esc(n[0].toUpperCase())}<em>📷</em></div>${D.set.pic?`<div class="hh"><b>⏱</b>${pT('Olib tashlash: rasmni bosib turing','Удалить: удерживайте фото','Kaldırmak için fotoğrafa basılı tut')}</div>`:''}<h2 data-r="nm" style="margin:.2rem 0 .5rem">${esc(n)} ✎</h2><div class="idp" data-r="id">ID: ${uid()} 📋</div></div>
<h4 class="sec">${pT('Sizning akkauntingiz','Ваш аккаунт','Hesabınız')}</h4><div class="pcard">${row('cl','☁️','#0ea5e9',pT('Bulut','Облако','Bulut'),s&&s.em?s.em:pT('Kirish','Войти','Giriş'))}${row('ph','📞','#22c55e',pT('Telefon raqam','Номер телефона','Telefon numarası'),D.set.ph||pT('Qo’shish','Добавить','Ekle'))}${row('ac','👤','#a855f7',pT('Akkaunt va zaxira','Аккаунт и резерв','Hesap ve yedek'),'')}</div>
<h4 class="sec">${pT('Umumiy','Общее','Genel')}</h4><div class="pcard">${row('sn','🔊','#ef4444',pT('Ovoz','Звук','Ses'),snDesc())}${row('sc','🛡️','#10b981',pT('Xavfsizlik','Безопасность','Güvenlik'),secDesc())}${row('st','⚙️','#64748b',pT('Sozlamalar','Настройки','Ayarlar'),'')}</div>`;
 b.onclick=e=>{const l=e.target.dataset.l;if(l){setLang(l);return}const r=(e.target.closest('[data-r]')||{dataset:{}}).dataset.r;if(!r)return;
  if(r=='cl')GOM().cloud();else if(r=='ac')GOM().acc();else if(r=='st')vSet();
  else if(r=='sn')vSnd();else if(r=='sc')vSec();
  else if(r=='th'){D.set.theme=th[(th.indexOf(D.set.theme)+1)%3];save();applyAll()}
  else if(r=='ph'){const v=prompt(pT('Telefon raqam','Номер телефона','Telefon numarası'),D.set.ph||'+998');if(v!==null){D.set.ph=v.trim();save();draw()}}
  else if(r=='pic'){if(D.set.pic)window.picMenu();else window.pickPic()}else if(r=='pd'){delete D.set.pic;save();applyAll();draw()}
  else if(r=='nm'){const v=prompt(pT('Ism','Имя','Ad'),nmx());if(v&&v.trim()){D.set.nm=v.trim();save();chip();draw()}}
  else if(r=='id'){try{navigator.clipboard.writeText(uid());toast('✓')}catch(x){}}}})}
$('#pc').onclick=vProf;
const A0=applyAll;applyAll=function(){A0();chip()};chip();setInterval(chip,1500);
})();
;
/* ===== v8: ovoz, xavfsizlik, namoz ===== */
(function(){
const P=(a,b,c)=>(LI()>2&&window.XP&&XP[a]&&XP[a][LI()-3])||[a,b,c][I()],SV=(k,d)=>D.set[k]===undefined?d:D.set[k],A=(u,r,k)=>[u,r||u,k||u];
window.qOK=n=>{if(n=='tick'&&D.set.tick===false)return false;const q=D.set.qh;if(q&&q.on){const d=new Date(),m=d.getHours()*60+d.getMinutes(),f=h=>{const[a,b]=h.split(':');return a*60+ +b},a=f(q.f||'22:00'),b=f(q.t||'07:00');if(a>b?(m>=a||m<b):(m>=a&&m<b))return false}return true};
window.vibX=n=>{if(D.set.vib===false||!navigator.vibrate||!{tick:1,ok:1,bad:1}[n])return;const k=6+SV('vs',50)*.6;try{navigator.vibrate(n=='bad'?[k*2,40,k*2]:n=='ok'?[k,30,k]:k)}catch(e){}};
try{const o=speechSynthesis.speak.bind(speechSynthesis);speechSynthesis.speak=u=>{u.volume=SV('sp',100)/100;u.rate=(u.rate||1)*SV('sr',100)/100;o(u)}}catch(e){}
window.snDesc=()=>D.set.snd===false?P('O‘chiq','Выкл','Kapalı'):P('Yoqilgan','Включён','Açık');
window.secDesc=()=>{const n=(LM().length)+(D.lock&&D.lock.cred?1:0);return n?n+' / 4':P('O‘chiq','Выкл','Kapalı')};
function vSnd(){push(()=>P('Ovoz','Звук','Ses'),b=>{const on=D.set.snd!==false,vb=D.set.vib!==false,vt=SV('vtl',0),q=D.set.qh||{};
 const sl=(k,ic,l,mn,mx,d,f)=>{const v=SV(k,d);return`<div class="sl"><div class="sh"><i>${ic}</i><span>${l}</span><b id="v_${k}">${f(v)}</b></div><input type="range" min="${mn}" max="${mx}" value="${v}" data-k="${k}" style="--p:${(v-mn)/(mx-mn)*100}%"></div>`},pc=v=>v+'%';
 const tg=(k,ic,l,s,o)=>`<button class="tg ${o?'on':''}" data-t="${k}"><i>${ic}</i><b>${l}</b><small>${s}</small></button>`;
 b.innerHTML=`<div class="sbig">${tg('snd',on?'🔊':'🔇',P('Ovoz','Звук','Ses'),on?P('Yoqilgan','Включён','Açık'):P('O‘chiq','Выкл','Kapalı'),on)}${tg('vib','📳',P('Tebranish','Вибрация','Titreşim'),vb?P('Yoqilgan','Включена','Açık'):P('O‘chiq','Выкл','Kapalı'),vb)}</div>
<div class="chips" id="vw"><button data-v="0" class="${vt?'':'on'}">▬ ${P('Gorizontal','Горизонтально','Yatay')}</button><button data-v="1" class="${vt?'on':''}">▮ ${P('Vertikal','Вертикально','Dikey')}</button></div>
<div class="slg ${vt?'vert':''}">${sl('vp','🎵',P('Ilova ovozi','Звук приложения','Uygulama sesi'),0,100,100,pc)}${sl('sp','🗣',P('Talaffuz ovozi','Громкость речи','Konuşma sesi'),0,100,100,pc)}${sl('sr','⏩',P('Talaffuz tezligi','Скорость речи','Konuşma hızı'),50,150,100,v=>'×'+(v/100).toFixed(1))}${sl('vs','📳',P('Tebranish kuchi','Сила вибрации','Titreşim gücü'),0,100,50,pc)}</div>
<h4 class="sec">${P('Qo‘shimcha','Дополнительно','Ek')}</h4><div class="pcard"><button class="prow" data-t="tick"><i style="background:#06b6d4">👆</i><span>${P('Tugma tovushi','Звук нажатий','Tuş sesi')}</span><em>${D.set.tick===false?P('O‘chiq','Выкл','Kapalı'):P('Yoqilgan','Вкл','Açık')}</em></button><button class="prow" data-t="qh"><i style="background:#6366f1">🌙</i><span>${P('Jim soatlar','Тихие часы','Sessiz saatler')}</span><em>${q.on?(q.f||'22:00')+'–'+(q.t||'07:00'):P('O‘chiq','Выкл','Kapalı')}</em></button>${q.on?`<div class="prow"><span>${P('Dan','С','Başl.')}</span><input type="time" data-q="f" value="${q.f||'22:00'}"><span>${P('Gacha','До','Bitiş')}</span><input type="time" data-q="t" value="${q.t||'07:00'}"></div>`:''}</div>
<div class="row" style="margin-top:1rem"><button class="btn" id="ts">🔔 ${P('Ovoz','Звук','Ses')}</button><button class="btn" id="tv">📳 ${P('Tebranish','Вибр.','Titreşim')}</button><button class="btn" id="tt">🗣 ${P('Talaffuz','Речь','Konuşma')}</button></div>`;
 b.oninput=e=>{const k=e.target.dataset.k;if(!k)return;const v=+e.target.value,mn=+e.target.min,mx=+e.target.max;D.set[k]=v;e.target.style.setProperty('--p',(v-mn)/(mx-mn)*100+'%');$('#v_'+k).textContent=k=='sr'?'×'+(v/100).toFixed(1):v+'%'};
 b.onchange=e=>{if(e.target.dataset.k){save()}const q2=e.target.dataset.q;if(q2){D.set.qh=D.set.qh||{on:1};D.set.qh[q2]=e.target.value;save()}};
 b.onclick=e=>{const el=e.target.closest('[data-t],[data-v],#ts,#tv,#tt');if(!el)return;const t=el.dataset.t;
  if(t=='snd')D.set.snd=!on;else if(t=='vib')D.set.vib=!vb;else if(t=='tick')D.set.tick=D.set.tick===false;else if(t=='qh')D.set.qh=Object.assign({f:'22:00',t:'07:00'},q,{on:q.on?0:1});
  else if(el.dataset.v!==undefined)D.set.vtl=+el.dataset.v;
  else if(el.id=='ts'){sfx('ok');return}else if(el.id=='tv'){if(!navigator.vibrate)toast(P('Bu qurilma tebranishni qo‘llamaydi','Устройство не поддерживает вибрацию','Cihaz titreşimi desteklemiyor'));else{const s=D.set.vib;D.set.vib=true;vibX('bad');D.set.vib=s}return}else if(el.id=='tt'){try{speak('Merhaba! Türkçe öğreniyorum.','tr')}catch(x){}return}
  save();draw()}})}
window.vSnd=vSnd;
function vSec(){push(()=>P('Xavfsizlik','Безопасность','Güvenlik'),b=>{const n=LM().length+(D.lock&&D.lock.cred?1:0);
 b.innerHTML=`<div class="shd ${n?'on':''}"><div class="sh1">🛡️</div><h2>${n?P('Himoya yoqilgan','Защита включена','Koruma açık'):P('Himoya o‘chiq','Защита выключена','Koruma kapalı')}</h2><div class="bars">${[0,1,2,3].map(i=>`<u class="${i<n?'on':''}"></u>`).join('')}</div><p class="mu">${P('Usullar: parol · PIN-kod · grafik kalit · yuz/barmoq izi','Способы: пароль · PIN · графический ключ · лицо/отпечаток','Yöntemler: parola · PIN · desen · yüz/parmak izi')}</p></div><div id="sc"></div>${window.isSecureContext?'':`<div class="card" style="margin-top:1rem">🙂👆 ${P('Yuz / barmoq izi faqat https orqali ishlaydi. Hozirgi ochilish usulida brauzer bunga ruxsat bermaydi, parol, PIN va grafik kalit ishlaydi.','Лицо/отпечаток работают только через https. При текущем способе открытия браузер это блокирует; пароль, PIN и ключ работают.','Yüz/parmak izi yalnızca https ile çalışır. Şu anki açılışta tarayıcı izin vermiyor; parola, PIN ve desen çalışır.')}</div>`}`;secUI()})}
window.vSec=vSec;
/* --- Namoz --- */
const CT=[['Toshkent',41.2995,69.2401],['Samarqand',39.6542,66.9597],['Buxoro',39.7747,64.4286],['Namangan',41.0011,71.6726],['Andijon',40.7821,72.3442],['Farg‘ona',40.3864,71.7864],['Qarshi',38.8606,65.789],['Jizzax',40.1158,67.8422],['Guliston',40.4897,68.7842],['Navoiy',40.0844,65.3792],['Termiz',37.2242,67.2783],['Urganch',41.5506,60.6317],['Nukus',42.4531,59.6103]];
const NM=[A('Bomdod','Фаджр','Sabah'),A('Quyosh','Восход','Güneş'),A('Peshin','Зухр','Öğle'),A('Asr','Аср','İkindi'),A('Shom','Магриб','Akşam'),A('Xufton','Иша','Yatsı')],R=Math.PI/180;
function ptm(dt,lat,lon){const tz=-dt.getTimezoneOffset()/60,dd=(Date.UTC(dt.getFullYear(),dt.getMonth(),dt.getDate())-Date.UTC(2000,0,1))/864e5-.5-lon/360,g=((357.529+.98560028*dd)%360)*R,q=(280.459+.98564736*dd)%360,L=((q+1.915*Math.sin(g)+.02*Math.sin(2*g))%360)*R,e=(23.439-3.6e-7*dd)*R,
 RA=((Math.atan2(Math.cos(e)*Math.sin(L),Math.cos(L))/R/15)%24+24)%24,dec=Math.asin(Math.sin(e)*Math.sin(L)),Eq=(((q/15-RA)+12)%24+24)%24-12,noon=12+tz-lon/15-Eq,la=lat*R,
 ang=a=>Math.acos(Math.max(-1,Math.min(1,(-Math.sin(a*R)-Math.sin(la)*Math.sin(dec))/(Math.cos(la)*Math.cos(dec)))))/R/15,
 A2=Math.atan(1/(2+Math.tan(Math.abs(la-dec)))),asr=noon+Math.acos((Math.sin(A2)-Math.sin(la)*Math.sin(dec))/(Math.cos(la)*Math.cos(dec)))/R/15;
 return[noon-ang(15.5),noon-ang(.833),noon+2/60,asr,noon+ang(.833)+4/60,noon+ang(16)].map(h=>Math.round(h*60))}
const hm=m=>String(Math.floor(m/60)%24).padStart(2,'0')+':'+String(m%60).padStart(2,'0'),dkey=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
const qib=(lat,lon)=>{const a=lat*R,b=21.4225*R,d=(39.8262-lon)*R;return(Math.atan2(Math.sin(d),Math.cos(a)*Math.tan(b)-Math.sin(a)*Math.cos(d))/R+360)%360};
let cmp=null;
function vNmz(){push(()=>P('Namoz','Намаз','Namaz'),b=>{const z=D.nz=D.nz||{c:0,d:{}},c=z.g||{n:CT[z.c][0],lat:CT[z.c][1],lon:CT[z.c][2]},now=new Date(),T=ptm(now,c.lat,c.lon),k=dkey(now),dn=z.d[k]=z.d[k]||[0,0,0,0,0],FI=[0,2,3,4,5],nm=NM.map(x=>x[I()]),cur=now.getHours()*60+now.getMinutes();
 let ni=T.findIndex(x=>x>cur),nt=ni<0?ptm(new Date(now.getTime()+864e5),c.lat,c.lon)[0]+1440:T[ni];if(ni<0)ni=0;
 const week=[...Array(7)].map((_,i)=>{const d=new Date(now.getTime()-(6-i)*864e5),a=z.d[dkey(d)]||[];return`<div class="wd"><u style="--p:${a.filter(Boolean).length*20}%"></u><small>${['Ya','Du','Se','Ch','Pa','Ju','Sh'][d.getDay()]}</small></div>`}).join(''),qb=Math.round(qib(c.lat,c.lon));
 b.innerHTML=`<div class="add"><select id="nc" style="flex:1">${CT.map((x,i)=>`<option value="${i}" ${!z.g&&i==z.c?'selected':''}>${x[0]}</option>`).join('')}${z.g?`<option selected>📍 ${P('Joylashuvim','Моё место','Konumum')}</option>`:''}</select><button class="btn" id="ng">📍</button></div>
<div class="nxc"><small>${P('Keyingi namoz','Следующий намаз','Sıradaki vakit')}</small><h2>${nm[ni]} · ${hm(nt)}</h2><div id="nx" data-t="${nt}">--:--:--</div></div>
<div class="pcard">${T.map((m,i)=>{const f=FI.indexOf(i),pas=m<=cur&&(T[i+1]===undefined||T[i+1]>cur);return`<div class="prow nr ${i==ni?'nx':''} ${pas?'cu':''}"><i>${['🌙','🌅','☀️','🌤','🌇','🌌'][i]}</i><span>${nm[i]}</span><em>${hm(m)}</em>${f<0?'<u></u>':`<button class="ck ${dn[f]?'on':''}" data-f="${f}">${dn[f]?'✓':''}</button>`}</div>`}).join('')}</div>
<h4 class="sec">${P('Oxirgi 7 kun','Последние 7 дней','Son 7 gün')} · ${dn.filter(Boolean).length}/5</h4><div class="wk">${week}</div>
<h4 class="sec">${P('Qibla','Кибла','Kıble')}</h4><div class="card qb"><div class="cp"><div class="ar" id="ar" style="transform:rotate(${qb}deg)">🕋<i></i></div></div><div><b>${qb}°</b><div class="mu">${P('Shimoldan soat mili bo‘ylab. Telefon kompasi ishlasa, strelka o‘zi buriladi.','От севера по часовой. Если есть компас, стрелка поворачивается сама.','Kuzeyden saat yönünde. Pusula varsa ok kendiliğinden döner.')}</div></div></div>
<p class="mu">${P('Vaqtlar hisoblab chiqiladi (Muftiyat jadvaliga yaqin, ±3 daqiqa). Rasmiy jadval bilan solishtiring.','Время рассчитано (близко к таблице муфтията, ±3 мин). Сверяйте с официальной.','Vakitler hesaplanır (±3 dk). Resmî takvimle karşılaştırın.')}</p>`;
 const tick=()=>{const e=$('#nx');if(!e){clearInterval(vNmz.t);return}let s=Math.max(0,Math.round(e.dataset.t*60-(Date.now()-new Date().setHours(0,0,0,0))/1000));e.textContent=[Math.floor(s/3600),Math.floor(s/60)%60,s%60].map(x=>String(x).padStart(2,'0')).join(':')};clearInterval(vNmz.t);vNmz.t=setInterval(tick,1000);tick();
 $('#nc').onchange=e=>{z.c=+e.target.value;delete z.g;save();draw()};
 $('#ng').onclick=()=>{if(!navigator.geolocation)return toast(P('Joylashuv qo‘llanmaydi','Геолокация недоступна','Konum desteklenmiyor'));navigator.geolocation.getCurrentPosition(p=>{z.g={n:'GPS',lat:p.coords.latitude,lon:p.coords.longitude};save();draw()},()=>toast(P('Joylashuvga ruxsat berilmadi. Shaharni ro‘yxatdan tanlang.','Нет доступа к геопозиции. Выберите город.','Konum izni yok. Listeden şehir seçin.')))};
 b.onclick=e=>{const f=e.target.dataset.f;if(f!==undefined){dn[f]=dn[f]?0:1;save();sfx(dn[f]?'ok':'tick');draw()}};
 if(cmp)window.removeEventListener('deviceorientationabsolute',cmp);cmp=ev=>{const h=ev.webkitCompassHeading!==undefined?ev.webkitCompassHeading:ev.alpha!=null?360-ev.alpha:null,a=$('#ar');if(h!==null&&a)a.style.transform=`rotate(${qb-h}deg)`;};window.addEventListener('deviceorientationabsolute',cmp,true)})}
window.vNmz=vNmz;
Object.assign(S,{nmz:A('Namoz','Намаз','Namaz'),nmzS:A('Vaqtlar · Qibla · hisob','Время · Кибла · учёт','Vakitler · Kıble · takip')});
const G1=GOM;GOM=function(){const o=G1();o.nmz=vNmz;return o};applyAll();
})();
;
/* ===== v9: Namoz bo'limi to'liq (Qibla kompas, kitob, duolar, qazo, tasbeh, hijriy taqvim, sozlamalar) ===== */
(function(){
const P=(a,b,c)=>(LI()>2&&window.XP&&XP[a]&&XP[a][LI()-3])||[a,b,c][I()],A=(u,r,k)=>[u,r||u,k||u],R=Math.PI/180,NZ=()=>D.nz=D.nz||{c:0,d:{}};
const CT=[['Toshkent',41.2995,69.2401],['Samarqand',39.6542,66.9597],['Buxoro',39.7747,64.4286],['Namangan',41.0011,71.6726],['Andijon',40.7821,72.3442],['Farg‘ona',40.3864,71.7864],['Qarshi',38.8606,65.789],['Jizzax',40.1158,67.8422],['Guliston',40.4897,68.7842],['Navoiy',40.0844,65.3792],['Termiz',37.2242,67.2783],['Urganch',41.5506,60.6317],['Nukus',42.4531,59.6103]],
MT=[['Muftiyat (O‘zbekiston)',15.5,16],['MWL',18,17],['Karachi',18,18],['Umm al-Qura',18.5,0]],
NM=[A('Bomdod','Фаджр','Sabah'),A('Quyosh','Восход','Güneş'),A('Peshin','Зухр','Öğle'),A('Asr','Аср','İkindi'),A('Shom','Магриб','Akşam'),A('Xufton','Иша','Yatsı')],
HM=['Muharram','Safar','Rabiul avval','Rabiul oxir','Jumodul avval','Jumodul oxir','Rajab','Sha’bon','Ramazon','Shavvol','Zulqa’da','Zulhijja'],
GM=['Yanvar','Fevral','Mart','Aprel','May','Iyun','Iyul','Avgust','Sentyabr','Oktyabr','Noyabr','Dekabr'],
cty=()=>{const z=NZ();return z.g||{n:CT[z.c||0][0],lat:CT[z.c||0][1],lon:CT[z.c||0][2]}},
dkey=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'),
hm=m=>String(((Math.floor(m/60)%24)+24)%24).padStart(2,'0')+':'+String(((m%60)+60)%60).padStart(2,'0');
function sol(dt,lon){const dd=(Date.UTC(dt.getFullYear(),dt.getMonth(),dt.getDate())-Date.UTC(2000,0,1))/864e5-.5-lon/360,g=((357.529+.98560028*dd)%360)*R,q=(280.459+.98564736*dd)%360,L=((q+1.915*Math.sin(g)+.02*Math.sin(2*g))%360)*R,e=(23.439-3.6e-7*dd)*R,RA=((Math.atan2(Math.cos(e)*Math.sin(L),Math.cos(L))/R/15)%24+24)%24,dec=Math.asin(Math.sin(e)*Math.sin(L)),Eq=(((q/15-RA)+12)%24+24)%24-12;return{dec,noon:12-dt.getTimezoneOffset()/60-lon/15-Eq}}
function ptm2(dt,lat,lon){const z=NZ(),m=MT[z.m||0],af=z.a||2,o=z.o||[0,0,0,0,0,0],{dec,noon}=sol(dt,lon),la=lat*R,
 ang=a=>Math.acos(Math.max(-1,Math.min(1,(-Math.sin(a*R)-Math.sin(la)*Math.sin(dec))/(Math.cos(la)*Math.cos(dec)))))/R/15,
 A2=Math.atan(1/(af+Math.tan(Math.abs(la-dec)))),asr=noon+Math.acos((Math.sin(A2)-Math.sin(la)*Math.sin(dec))/(Math.cos(la)*Math.cos(dec)))/R/15,mg=noon+ang(.833)+4/60;
 return[noon-ang(m[1]),noon-ang(.833),noon+2/60,asr,mg,m[2]?noon+ang(m[2]):mg+1.5].map((h,i)=>Math.round(h*60)+(o[i]||0))}
function sunPos(dt,lat,lon){const{dec,noon}=sol(dt,lon),la=lat*R,H=((dt.getHours()+dt.getMinutes()/60)-noon)*15*R;return{alt:Math.asin(Math.sin(la)*Math.sin(dec)+Math.cos(la)*Math.cos(dec)*Math.cos(H))/R,az:(Math.atan2(Math.sin(H),Math.cos(H)*Math.sin(la)-Math.tan(dec)*Math.cos(la))/R+180+360)%360}}
const qib=(lat,lon)=>{const a=lat*R,b=21.4225*R,d=(39.8262-lon)*R;return(Math.atan2(Math.sin(d),Math.cos(a)*Math.tan(b)-Math.sin(a)*Math.cos(d))/R+360)%360};
function g2h(d){const jd=Math.floor(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate())/864e5+2440588);let l=jd-1948440+10632;const n=Math.floor((l-1)/10631);l=l-10631*n+354;const j=(Math.floor((10985-l)/5316))*(Math.floor((50*l)/17719))+(Math.floor(l/5670))*(Math.floor((43*l)/15238));l=l-(Math.floor((30-j)/15))*(Math.floor((17719*j)/50))-(Math.floor(j/16))*(Math.floor((15238*j)/43))+29;const m=Math.floor((24*l)/709);return{d:l-Math.floor((709*m)/24),m:m-1,y:30*n+j-30}}
function h2g(y,m,d){const jd=Math.floor((11*y+3)/30)+354*y+30*(m+1)-Math.floor(m/2)+d+1948440-385;return new Date((jd-2440588)*864e5+12*36e5)}
const hs=d=>{const h=g2h(d);return h.d+' '+HM[h.m]+' '+h.y}, WD=['Yakshanba','Dushanba','Seshanba','Chorshanba','Payshanba','Juma','Shanba'];
/* kompas */
let cOff=null;function compass(cb){if(cOff)cOff();const h=ev=>{const v=ev.webkitCompassHeading!=null?ev.webkitCompassHeading:((ev.type=='deviceorientationabsolute'||ev.absolute)&&ev.alpha!=null?360-ev.alpha:null);if(v!=null)cb(v)};window.addEventListener('deviceorientationabsolute',h,true);window.addEventListener('deviceorientation',h,true);cOff=()=>{window.removeEventListener('deviceorientationabsolute',h,true);window.removeEventListener('deviceorientation',h,true);cOff=null}}
function vQbl(){push(()=>P('Qibla','Кибла','Kıble'),b=>{const c=cty(),qb=qib(c.lat,c.lon),sp=sunPos(new Date(),c.lat,c.lon);let ticks='';for(let a=0;a<360;a+=5){const m=a%30==0;ticks+=`<line x1="0" y1="-${m?148:151}" x2="0" y2="-158" stroke="currentColor" stroke-width="${m?3:1.4}" opacity="${m?1:.6}" transform="rotate(${a})"/>`}
 let lb='';for(let a=0;a<360;a+=30){const t=({0:'N',90:'E',180:'S',270:'W'})[a]||a;lb+=`<text transform="rotate(${a}) translate(0,-128)" text-anchor="middle" dominant-baseline="middle" font-size="${typeof t=='string'?15:12}" font-weight="800" fill="${a==0?'#ef4444':'currentColor'}">${t}</text>`}
 b.innerHTML=`<div class="qh"><b>${P('Qibla','Кибла','Kıble')}: ${qb.toFixed(2)}° (${c.n})</b><div id="hd">—</div></div><div class="dl"><svg id="dsv" viewBox="-175 -175 350 350"><g id="rot" style="color:var(--tx,#e5e7eb)">${ticks}${lb}<g transform="rotate(${qb})"><path d="M0,-118 L-24,-34 A28,28 0 1,0 24,-34 Z" fill="var(--bg,#0b0b14)" stroke="currentColor" stroke-width="2.5"/><circle r="24" cy="0" fill="#fff"/><text y="1" text-anchor="middle" dominant-baseline="middle" font-size="26">🕋</text></g><g transform="rotate(${sp.az})" opacity="${sp.alt>0?1:.3}"><text y="-78" text-anchor="middle" dominant-baseline="middle" font-size="26">☀️</text></g></g><line x1="0" y1="-170" x2="0" y2="-150" stroke="#10b981" stroke-width="4" stroke-linecap="round" id="mk"/></svg></div><div class="row"><button class="btn pri" id="cmb">🧭 ${P('Kompasni yoqish','Включить компас','Pusulayı aç')}</button></div><p class="mu" id="cmn">${P('Telefonni tekis ushlang va temir buyumlardan uzoqroq tuting. Yashil chiziq Kaaba belgisiga to‘g‘ri kelganda qibla shu tomonda.','Держите телефон ровно, вдали от металла. Когда зелёная метка совпадёт с Каабой, это направление Киблы.','Telefonu düz tutun. Yeşil çizgi Kâbe ile hizalanınca kıble o yöndedir.')}</p>`;
 let h0=null,ok=0;const rot=$('#rot'),upd=v=>{if(!$('#rot'))return cOff&&cOff();h0=h0==null?v:h0+((((v-h0)%360)+540)%360-180)*.3;const hh=(h0+360)%360;rot.setAttribute('transform','rotate('+(-hh)+')');$('#hd').textContent=hh.toFixed(2)+'°';const dif=Math.abs(((hh-qb)+540)%360-180);$('#mk').setAttribute('stroke',dif<3?'#22c55e':'#ef4444');if(dif<3&&!ok){ok=1;vibX('ok')}if(dif>8)ok=0};
 const go=()=>{compass(upd);$('#cmn').dataset.w=1;setTimeout(()=>{const nn=$('#cmn');if(nn&&h0==null)nn.textContent=P('Kompas sensori ma’lumot bermayapti (brauzer ruxsat bermagan bo‘lishi mumkin). Shimol tepada, Kaaba yo‘nalishi '+qb.toFixed(0)+'°. Sayt (https) orqali ochsangiz ishlaydi.','Датчик компаса не отвечает. Север сверху, направление на Каабу '+qb.toFixed(0)+'°.','Pusula sensörü yanıt vermiyor. Kuzey üstte, Kâbe yönü '+qb.toFixed(0)+'°.')},2500)};
 $('#cmb').onclick=async()=>{try{if(window.DeviceOrientationEvent&&DeviceOrientationEvent.requestPermission)await DeviceOrientationEvent.requestPermission()}catch(e){}go();$('#cmb').hidden=true};go();$('#cmb').hidden=true})}
/* kitob */
const KT=[['Iymon','Iymon, Islom, aqida va niyatning ahamiyati','<p><b>Iymonning olti shartiga</b> ishonish: Allohga, farishtalariga, kitoblariga, payg‘ambarlariga, oxirat kuniga va yaxshi-yomon taqdir Allohdan ekaniga.</p><p><b>Islomning besh rukni:</b> shahodat kalimasi, namoz, zakot, ro‘za (Ramazon) va imkoni borlar uchun haj.</p><p>Har bir amal niyatga qarab baholanadi: niyat qalbdagi qasd, uni tilda aytish shart emas.</p>'],
['Poklanish','G‘usl, tahorat va tayammum haqida','<p><b>Tahorat farzlari (4 ta):</b> yuzni yuvish; qo‘llarni tirsak bilan qo‘shib yuvish; boshning to‘rtdan birini mash qilish; oyoqlarni to‘piq bilan qo‘shib yuvish.</p><p><b>Tartibi:</b> niyat va “Bismillah” → qo‘llarni yuvish → og‘iz va burunni chayish → yuz → qo‘llar → bosh va quloqlar mashi → oyoqlar.</p><p><b>Tahoratni buzadi:</b> old-orqa yo‘ldan biror narsa chiqishi, qon yoki yiring oqib chiqishi, to‘la og‘iz qayt qilish, uxlab qolish, hushdan ketish.</p><p><b>G‘usl farzlari (3 ta):</b> og‘izni chayish, burunni chayish, butun badanni yuvish.</p><p><b>Tayammum:</b> suv topilmaganda yoki ishlatib bo‘lmaganda pok tuproq bilan yuz va qo‘llarni mash qilish.</p>'],
['Namozga kirish','Namoz shartlari, vaqtlari va qiblani topish','<p><b>Namoz shartlari:</b> hadasdan pok bo‘lish, badan-kiyim-joy najosatdan pok bo‘lishi, avratni yopish, qiblaga yo‘nalish, vaqt kirishi va niyat.</p><p><b>Besh vaqt:</b> Bomdod (tong yorishidan quyosh chiqquncha), Peshin (quyosh qiyomdan og‘gach), Asr, Shom (quyosh botgach), Xufton (shafaq yo‘qolgach).</p><p>Quyosh chiqishi, tush payti va botish paytida namoz o‘qilmaydi (karohat vaqtlari).</p><p>Qiblani “Qibla” bo‘limidagi kompas orqali aniqlang.</p>'],
['Namoz','Farz, vojib, sunnat namozlarini o‘qish tartibi','<p><b>Rakatlar (hanafiy mazhabi):</b></p><table><tr><td>Bomdod</td><td>2 sunnat + 2 farz</td></tr><tr><td>Peshin</td><td>4 sunnat + 4 farz + 2 sunnat</td></tr><tr><td>Asr</td><td>4 farz (oldidan 4 sunnat – g‘ayri muakkada)</td></tr><tr><td>Shom</td><td>3 farz + 2 sunnat</td></tr><tr><td>Xufton</td><td>4 farz + 2 sunnat + 3 vitr (vojib)</td></tr></table><p><b>Tartib:</b> niyat va takbir (“Allohu akbar”) → qiyom: Sano, A’uzu, Basmala, Fotiha va sura → ruku → qavma (“Sami’allohu liman hamidah”) → sajda → jalsa → ikkinchi sajda. Ikki rakatdan keyin qa’da: Tahiyyot; oxirgi qa’dada Salovat va duo → ikki tomonga salom.</p><p class="mu">Batafsil o‘rganish uchun ishonchli imom yoki ustozga murojaat qiling.</p>']];
function vKit(){push(()=>P('Namoz kitobi','Книга намаза','Namaz kitabı'),b=>{b.innerHTML=KT.map((k,i)=>`<button class="card kt" data-i="${i}"><b>${k[0]}</b><span class="mu">${k[1]}</span></button>`).join('');b.onclick=e=>{const i=(e.target.closest('[data-i]')||{dataset:{}}).dataset.i;if(i!==undefined)push(()=>KT[i][0],bb=>{bb.innerHTML='<div class="kb">'+KT[i][2]+'</div>'})}})}
/* duolar */
const DU=[['Tahoratdan oldin','بِسْمِ اللّٰهِ','Alloh nomi bilan.'],['Tahoratdan keyin','أَشْهَدُ أَنْ لَا إِلٰهَ إِلَّا اللّٰهُ وَحْدَهُ لَا شَرِيكَ لَهُ، وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ','Allohdan o‘zga iloh yo‘qligiga, U yagona va sherigi yo‘qligiga, Muhammad Uning bandasi va elchisi ekaniga guvohlik beraman.'],['Ovqatdan oldin','بِسْمِ اللّٰهِ وَعَلَىٰ بَرَكَةِ اللّٰهِ','Alloh nomi bilan va Alloh barakasi bilan.'],['Ovqatdan keyin','الْحَمْدُ لِلّٰهِ الَّذِي أَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مُسْلِمِينَ','Bizni to‘ydirgan, ichirgan va musulmon qilgan Allohga hamd bo‘lsin.'],['Uyquga yotishda','اللّٰهُمَّ بِاسْمِكَ أَمُوتُ وَأَحْيَا','Allohim, Sening isming bilan o‘laman va tirilaman.'],['Uyg‘onganda','الْحَمْدُ لِلّٰهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ','Bizni o‘ldirganidan keyin tiriltirgan Allohga hamd bo‘lsin, qaytish Uning huzuriga.'],['Uydan chiqishda','بِسْمِ اللّٰهِ تَوَكَّلْتُ عَلَى اللّٰهِ، وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللّٰهِ','Alloh nomi bilan, Allohga tavakkal qildim. Allohsiz kuch va quvvat yo‘q.'],['Masjidga kirishda','اللّٰهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ','Allohim, menga rahmating eshiklarini och.'],['Masjiddan chiqishda','اللّٰهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ','Allohim, Sendan fazlingni so‘rayman.'],['Azondan keyin','اللّٰهُمَّ رَبَّ هٰذِهِ الدَّعْوَةِ التَّامَّةِ وَالصَّلَاةِ الْقَائِمَةِ آتِ مُحَمَّدًا الْوَسِيلَةَ وَالْفَضِيلَةَ وَابْعَثْهُ مَقَامًا مَحْمُودًا الَّذِي وَعَدْتَهُ','Ey, bu mukammal da’vat va qoim namozning Rabbi Allohim, Muhammadga vasila va fazilatni ber va uni va’da qilgan maqtovli maqomda tiriltir.'],['Safar duosi','سُبْحَانَ الَّذِي سَخَّرَ لَنَا هٰذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ وَإِنَّا إِلَىٰ رَبِّنَا لَمُنقَلِبُونَ','Buni bizga bo‘ysundirgan zot pok. Biz unga qodir emas edik, albatta Rabbimiz huzuriga qaytuvchimiz.'],['Dunyo va oxirat yaxshiligi','رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ','Rabbimiz, bizga dunyoda ham, oxiratda ham yaxshilik ber va do‘zax azobidan saqla.'],['Istig‘for','أَسْتَغْفِرُ اللّٰهَ','Allohdan mag‘firat so‘rayman.']];
function vDua(){push(()=>P('Duolar','Дуа','Dualar'),b=>{b.innerHTML=DU.map((d,i)=>`<div class="card du"><b class="gt">${d[0]}</b><div class="ar2" dir="rtl">${d[1]}</div><p>${d[2]}</p><button class="btn" data-i="${i}">📋</button></div>`).join('');b.onclick=e=>{const i=e.target.dataset.i;if(i!==undefined){try{navigator.clipboard.writeText(DU[i][1]+'\n'+DU[i][2]);toast('✓')}catch(x){}}}})}
/* qazo */
function vQz(){push(()=>P('Qazo namozlar','Каза-намазы','Kaza namazları'),b=>{const z=NZ(),q=z.q=z.q||[0,0,0,0,0,0],nm=['Bomdod','Peshin','Asr','Shom','Xufton','Vitr'],tot=q.reduce((a,x)=>a+x,0);
 b.innerHTML=`<div class="nxc"><small>${P('Jami qazo','Всего каза','Toplam kaza')}</small><div id="nx" style="font-size:3rem">${tot}</div></div><div class="pcard">${nm.map((n,i)=>`<div class="prow"><span>${n}</span><button class="btn" data-i="${i}" data-d="-1">✓ −1</button><b style="min-width:2.5rem;text-align:center">${q[i]}</b><button class="btn" data-i="${i}" data-d="1">+1</button></div>`).join('')}</div><div class="row" style="margin-top:1rem"><button class="btn" id="qa">＋ ${P('Kunlar bo‘yicha qo‘shish','Добавить по дням','Gün ekle')}</button><button class="btn bad" id="qr">${P('Tozalash','Сброс','Sıfırla')}</button></div><p class="mu">${P('“✓ −1” bosilsa bitta qazo o‘qilgan hisoblanadi. “Kunlar bo‘yicha” har bir vaqtga shuncha qazo qo‘shadi.','«✓ −1» отмечает один прочитанный каза.','«✓ −1» bir kazanın kılındığını işaretler.')}</p>`;
 b.onclick=e=>{const el=e.target.closest('[data-i],#qa,#qr');if(!el)return;if(el.id=='qa'){const n=parseInt(prompt(P('Necha kunlik qazo?','Сколько дней?','Kaç günlük?'),'30'));if(n>0)q.forEach((_,i)=>q[i]+=n)}else if(el.id=='qr'){if(confirm('OK?'))q.fill(0)}else{const i=+el.dataset.i;q[i]=Math.max(0,q[i]+ +el.dataset.d);if(el.dataset.d=='-1')sfx('ok')}save();draw()}})}
/* tasbeh */
const ZK=[['سُبْحَانَ اللّٰه','Subhanalloh'],['الْحَمْدُ لِلّٰه','Alhamdulillah'],['اللّٰهُ أَكْبَر','Allohu akbar'],['لَا إِلٰهَ إِلَّا اللّٰه','La ilaha illalloh']];
function vTs(){push(()=>P('Tasbeh','Тасбих','Tesbih'),b=>{const z=NZ(),t=z.t=z.t||{n:0,tg:33,tot:0,z:0,r:0},C=2*Math.PI*118;
 b.innerHTML=`<div class="chips" id="zk">${ZK.map((x,i)=>`<button data-z="${i}" class="${i==t.z?'on':''}">${x[1]}</button>`).join('')}</div><div class="tsw"><svg viewBox="-135 -135 270 270"><circle r="118" fill="none" stroke="rgba(127,127,127,.25)" stroke-width="14"/><circle id="trg" r="118" fill="none" stroke="url(#tg)" stroke-width="14" stroke-linecap="round" transform="rotate(-90)" stroke-dasharray="${C}" stroke-dashoffset="${t.tg?C*(1-t.n/t.tg):0}"/><defs><linearGradient id="tg"><stop offset="0" stop-color="#10b981"/><stop offset="1" stop-color="#22d3ee"/></linearGradient></defs></svg><button id="tap"><div class="ar2" dir="rtl">${ZK[t.z][0]}</div><b id="tn">${t.n}</b><small>${t.tg?'/ '+t.tg:'∞'}</small></button></div><div class="chips" id="tgc">${[33,99,100,0].map(x=>`<button data-t="${x}" class="${t.tg==x?'on':''}">${x||'∞'}</button>`).join('')}</div><p class="mu" style="text-align:center">${P('Aylanishlar','Круги','Tur')}: ${t.r} · ${P('Jami','Всего','Toplam')}: ${t.tot}</p><div class="row" style="justify-content:center"><button class="btn" id="trs">↺ ${P('Nolga','Сброс','Sıfırla')}</button></div>`;
 $('#tap').onclick=()=>{t.n++;t.tot++;vibX('tick');sfx('tick');if(t.tg&&t.n>=t.tg){t.n=0;t.r++;sfx('ok');vibX('ok');toast('✓ '+t.tg)}save();draw()};
 b.onclick=e=>{const z2=e.target.dataset.z,tg=e.target.dataset.t;if(z2!==undefined){t.z=+z2;t.n=0}else if(tg!==undefined){t.tg=+tg;t.n=0}else if(e.target.id=='trs'){t.n=0;t.r=0}else return;save();draw()}})}
/* hijriy taqvim */
function vHj(){push(()=>P('Hijriy taqvim','Хиджра','Hicri takvim'),b=>{const z=NZ();z.hm=z.hm||0;const now=new Date(),d0=new Date(now.getFullYear(),now.getMonth()+z.hm,1),first=(d0.getDay()+6)%7,days=new Date(d0.getFullYear(),d0.getMonth()+1,0).getDate(),th=g2h(now);
 let cells='<i></i>'.repeat(first);for(let i=1;i<=days;i++){const dd=new Date(d0.getFullYear(),d0.getMonth(),i),h=g2h(dd),td=dkey(dd)==dkey(now);cells+=`<div class="hc ${td?'td':''}"><span>${i}</span><small>${h.d==1?HM[h.m].slice(0,4):h.d}</small></div>`}
 const ev=[[0,10,'Ashuro kuni'],[6,27,'Isro va Me’roj'],[7,15,'Baro’at kechasi'],[8,1,'Ramazon boshlanishi'],[8,27,'Qadr kechasi (27-kecha)'],[9,1,'Hayit Ramazon'],[11,9,'Arafa kuni'],[11,10,'Hayit Qurbon']],up=[];[th.y,th.y+1].forEach(y=>ev.forEach(e=>{const g=h2g(y,e[0],e[1]);if(g>=new Date(now.getFullYear(),now.getMonth(),now.getDate()))up.push([g,e[2]+' · '+e[1]+' '+HM[e[0]]+' '+y])}));up.sort((a,b)=>a[0]-b[0]);
 b.innerHTML=`<div class="nxc"><small>${P('Bugun','Сегодня','Bugün')}</small><h2>${hs(now)}</h2></div><div class="add" style="justify-content:space-between"><button class="btn" data-m="-1">‹</button><b>${GM[d0.getMonth()]} ${d0.getFullYear()}</b><button class="btn" data-m="1">›</button></div><div class="hg">${['du','se','ch','pa','ju','sh','ya'].map(x=>`<u>${x}</u>`).join('')}${cells}</div><h4 class="sec">${P('Muborak kunlar','Священные дни','Mübarek günler')}</h4><div class="pcard">${up.slice(0,6).map(u=>`<div class="prow"><span>${u[1]}</span><em>${u[0].getDate()} ${GM[u[0].getMonth()].slice(0,3)}</em></div>`).join('')}</div><p class="mu">${P('Hijriy sana hisob-kitob asosida, haqiqiy ko‘rinish bilan ±1 kun farq qilishi mumkin.','Дата расчётная, возможна разница ±1 день.','Tarih hesaplamadır, ±1 gün fark olabilir.')}</p>`;
 b.onclick=e=>{const m=e.target.dataset.m;if(m){z.hm+=+m;save();draw()}}})}
/* namoz sozlamalari */
function vNst(){push(()=>P('Namoz sozlamalari','Настройки намаза','Namaz ayarları'),b=>{const z=NZ(),m=z.m||0,a=z.a||2,o=z.o=z.o||[0,0,0,0,0,0],nm=NM.map(x=>x[I()]);
 b.innerHTML=`<h4 class="sec">${P('Hisoblash usuli','Метод расчёта','Hesaplama yöntemi')}</h4><div class="chips">${MT.map((x,i)=>`<button data-m="${i}" class="${i==m?'on':''}">${x[0]}</button>`).join('')}</div><h4 class="sec">Asr</h4><div class="chips"><button data-a="2" class="${a==2?'on':''}">${P('Hanafiy','Ханафитский','Hanefî')}</button><button data-a="1" class="${a==1?'on':''}">${P('Shofe’iy','Шафиитский','Şâfiî')}</button></div><h4 class="sec">${P('Vaqtni to‘g‘rilash (daqiqa)','Коррекция (мин)','Düzeltme (dk)')}</h4><div class="pcard">${nm.map((n,i)=>`<div class="prow"><span>${n}</span><button class="btn" data-o="${i}" data-d="-1">−</button><b style="min-width:2.4rem;text-align:center">${o[i]>0?'+':''}${o[i]}</b><button class="btn" data-o="${i}" data-d="1">+</button></div>`).join('')}</div><div class="pcard" style="margin-top:1rem"><button class="prow" data-al="1"><i style="background:#f59e0b">🔔</i><span>${P('Namoz vaqtida eslatma (ilova ochiq bo‘lsa)','Напоминание (приложение открыто)','Vakitte hatırlatma (uygulama açıkken)')}</span><em>${z.al?P('Yoqilgan','Вкл','Açık'):P('O‘chiq','Выкл','Kapalı')}</em></button></div>`;
 b.onclick=e=>{const d=e.target.dataset;if(d.m!==undefined)z.m=+d.m;else if(d.a!==undefined)z.a=+d.a;else if(d.o!==undefined)o[d.o]+=+d.d;else if(e.target.closest('[data-al]'))z.al=!z.al;else return;save();draw()}})}
/* asosiy namoz sahifasi */
function vNmz2(){push(()=>P('Namoz','Намаз','Namaz'),b=>{const z=NZ(),c=cty(),now=new Date(),T=ptm2(now,c.lat,c.lon),k=dkey(now),dn=z.d[k]=z.d[k]||[0,0,0,0,0],FI=[0,2,3,4,5],nm=NM.map(x=>x[I()]),cur=now.getHours()*60+now.getMinutes();
 let ni=T.findIndex(x=>x>cur),nt=ni<0?ptm2(new Date(now.getTime()+864e5),c.lat,c.lon)[0]+1440:T[ni];if(ni<0)ni=0;
 const week=[...Array(7)].map((_,i)=>{const d=new Date(now.getTime()-(6-i)*864e5),a=z.d[dkey(d)]||[];return`<div class="wd"><u style="--p:${a.filter(Boolean).length*20}%"></u><small>${['Ya','Du','Se','Ch','Pa','Ju','Sh'][d.getDay()]}</small></div>`}).join('');
 const SC=[['qb','🧭',P('Qibla','Кибла','Kıble'),'#0ea5e9'],['kt','📖',P('Namoz kitobi','Книга','Kitap'),'#8b5cf6'],['du','🤲',P('Duolar','Дуа','Dualar'),'#ec4899'],['qz','✅',P('Qazo namozlar','Каза','Kaza'),'#f97316'],['ts','📿',P('Tasbeh','Тасбих','Tesbih'),'#10b981'],['hj','📅',P('Hijriy taqvim','Хиджра','Hicri'),'#14b8a6'],['st','⚙️',P('Sozlamalar','Настройки','Ayarlar'),'#64748b']];
 b.innerHTML=`<div class="add"><select id="nc" style="flex:1">${CT.map((x,i)=>`<option value="${i}" ${!z.g&&i==(z.c||0)?'selected':''}>${x[0]}</option>`).join('')}${z.g?`<option selected>📍 ${P('Joylashuvim','Моё место','Konumum')}</option>`:''}</select><button class="btn" id="ng">📍</button></div><p class="mu" style="margin:.2rem .3rem">📅 ${WD[now.getDay()]}, ${now.getDate()} ${GM[now.getMonth()]} · ${hs(now)}</p>
<div class="nxc"><small>${P('Keyingi namoz','Следующий намаз','Sıradaki vakit')}</small><h2>${nm[ni]} · ${hm(nt)}</h2><div id="nx" data-t="${nt}">--:--:--</div></div>
<div class="pcard">${T.map((m,i)=>{const f=FI.indexOf(i),pas=m<=cur&&(T[i+1]===undefined||T[i+1]>cur);return`<div class="prow nr ${i==ni?'nx':''} ${pas?'cu':''}"><i>${['🌙','🌅','☀️','🌤','🌇','🌌'][i]}</i><span>${nm[i]}</span><em>${hm(m)}</em>${f<0?'<u></u>':`<button class="ck ${dn[f]?'on':''}" data-f="${f}">${dn[f]?'✓':''}</button>`}</div>`}).join('')}</div>
<h4 class="sec">${P('Oxirgi 7 kun','Последние 7 дней','Son 7 gün')} · ${dn.filter(Boolean).length}/5</h4><div class="wk">${week}</div>
<h4 class="sec">${P('Bo‘limlar','Разделы','Bölümler')}</h4><div class="ngrid">${SC.map(s=>`<button data-s="${s[0]}" style="--c:${s[3]}"><i>${s[1]}</i><span>${s[2]}</span></button>`).join('')}</div>
<p class="mu">${P('Vaqtlar hisoblab chiqiladi (Muftiyat jadvaliga yaqin, ±3 daqiqa). Rasmiy jadval bilan solishtiring.','Время рассчитано (±3 мин). Сверяйте с официальной таблицей.','Vakitler hesaplanır (±3 dk). Resmî takvimle karşılaştırın.')}</p>`;
 const tick=()=>{const e=$('#nx');if(!e||!e.dataset.t){clearInterval(vNmz2.t);return}const s=Math.max(0,Math.round(e.dataset.t*60-(Date.now()-new Date().setHours(0,0,0,0))/1000));e.textContent=[Math.floor(s/3600),Math.floor(s/60)%60,s%60].map(x=>String(x).padStart(2,'0')).join(':')};clearInterval(vNmz2.t);vNmz2.t=setInterval(tick,1000);tick();
 $('#nc').onchange=e=>{z.c=+e.target.value;delete z.g;save();draw()};
 $('#ng').onclick=()=>{if(!navigator.geolocation)return toast(P('Joylashuv qo‘llanmaydi','Геолокация недоступна','Konum desteklenmiyor'));navigator.geolocation.getCurrentPosition(p=>{z.g={n:'GPS',lat:p.coords.latitude,lon:p.coords.longitude};save();draw()},()=>toast(P('Joylashuvga ruxsat berilmadi. Shaharni ro‘yxatdan tanlang.','Нет доступа к геопозиции. Выберите город.','Konum izni yok. Listeden şehir seçin.')))};
 b.onclick=e=>{const f=e.target.dataset.f;if(f!==undefined){dn[f]=dn[f]?0:1;save();sfx(dn[f]?'ok':'tick');draw();return}const s=(e.target.closest('[data-s]')||{dataset:{}}).dataset.s;if(s)({qb:vQbl,kt:vKit,du:vDua,qz:vQz,ts:vTs,hj:vHj,st:vNst})[s]()}})}
setInterval(()=>{const z=D.nz;if(!z||!z.al)return;const c=cty(),n=new Date(),i=ptm2(n,c.lat,c.lon).indexOf(n.getHours()*60+n.getMinutes());if(i<0||i==1)return;const k=dkey(n)+i;if(window._nal==k)return;window._nal=k;toast('🕌 '+NM[i][I()]+' '+P('vaqti','время','vakti'));sfx('intro');try{navigator.vibrate&&navigator.vibrate([200,100,200])}catch(e){}},20000);
Object.assign(S,{nmzS:A('Vaqtlar · Qibla · Duo · Tasbeh','Время · Кибла · Дуа · Тасбих','Vakitler · Kıble · Dua · Tesbih')});
const G3=GOM;GOM=function(){const o=G3();o.nmz=vNmz2;return o};applyAll();
})();
;
/* ===== Soat: soat, budilnik, dunyo, taymer, sekundomer; tile belgilari; profil rasmi ===== */
(function(){
const P=(a,b,c)=>(LI()>2&&window.XP&&XP[a]&&XP[a][LI()-3])||[a,b,c][I()],z=n=>String(n).padStart(2,'0'),G=id=>document.getElementById(id);
Object.assign(S,{clk:["Soat","Часы","Saat"],calS:["2005–2300","2005–2300","2005–2300"]});
const WD=[["Yakshanba","Dushanba","Seshanba","Chorshanba","Payshanba","Juma","Shanba"],["Воскресенье","Понедельник","Вторник","Среда","Четверг","Пятница","Суббота"],["Pazar","Pazartesi","Salı","Çarşamba","Perşembe","Cuma","Cumartesi"],["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],["Якшанбе","Душанбе","Сешанбе","Чоршанба","Панҷшанбе","Ҷумъа","Шанбе"],["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"],["일요일","월요일","화요일","수요일","목요일","금요일","토요일"]];
const CT=[['Toshkent','Asia/Tashkent'],['Istanbul','Europe/Istanbul'],['Moskva','Europe/Moscow'],['Dubay','Asia/Dubai'],['Makka','Asia/Riyadh'],['London','Europe/London'],['Parij','Europe/Paris'],['Berlin','Europe/Berlin'],['Madrid','Europe/Madrid'],['Rim','Europe/Rome'],['Kiyev','Europe/Kiev'],['Nyu-York','America/New_York'],['Chikago','America/Chicago'],['Los-Anjeles','America/Los_Angeles'],['Sakramento','America/Los_Angeles'],['Toronto','America/Toronto'],['Meksika','America/Mexico_City'],['San-Paulu','America/Sao_Paulo'],['Tokio','Asia/Tokyo'],['Seul','Asia/Seoul'],['Pekin','Asia/Shanghai'],['Singapur','Asia/Singapore'],['Jakarta','Asia/Jakarta'],['Dehli','Asia/Kolkata'],['Almati','Asia/Almaty'],['Bishkek','Asia/Bishkek'],['Dushanbe','Asia/Dushanbe'],['Ashgabat','Asia/Ashgabat'],['Kobul','Asia/Kabul'],['Tehron','Asia/Tehran'],['Boku','Asia/Baku'],['Tbilisi','Asia/Tbilisi'],['Qohira','Africa/Cairo'],['Sidney','Australia/Sydney']];
const AL=()=>D.set.alm||(D.set.alm=[]),WC=()=>D.set.wc||(D.set.wc=['Toshkent','Istanbul','Sakramento']);
let tab='c',ci=0,ls=-1,ad=[],aud=null,rg=null,tm={set:300,end:0,rem:0,run:0},sw={run:0,t0:0,acc:0,laps:[]};
const tzOff=(tz,d)=>{const f=new Intl.DateTimeFormat('en-US',{timeZone:tz,hourCycle:'h23',year:'numeric',month:'numeric',day:'numeric',hour:'numeric',minute:'numeric',second:'numeric'}).formatToParts(d).reduce((a,p)=>(a[p.type]=+p.value,a),{});return Date.UTC(f.year,f.month-1,f.day,f.hour%24,f.minute,f.second)-Math.floor(d/1000)*1000};
const fmtT=s=>z(Math.floor(s/3600))+':'+z(Math.floor(s%3600/60))+':'+z(s%60),el=()=>sw.acc+(sw.run?Date.now()-sw.t0:0),fmtS=ms=>{const h=Math.floor(ms/36e5);return(h?h+':':'')+z(Math.floor(ms/6e4)%60)+':'+z(Math.floor(ms/1000)%60)+'.'+z(Math.floor(ms%1000/10))};
const dsc=a=>!a.d||!a.d.length?P('Bir marta','Один раз','Bir kez'):a.d.length==7?P('Har kuni','Каждый день','Her gün'):a.d.map(x=>WN[LI()][x-1]).join(' ');
/* signal */
addEventListener('pointerdown',()=>{try{aud=aud||new(window.AudioContext||window.webkitAudioContext)();aud.resume()}catch(e){}},{once:true});
function beep(){try{aud=aud||new(window.AudioContext||window.webkitAudioContext)();if(aud.state=='suspended')aud.resume();const o=aud.createOscillator(),g=aud.createGain();o.frequency.value=880;g.gain.value=.25;o.connect(g);g.connect(aud.destination);o.start();o.stop(aud.currentTime+.18)}catch(e){}}
function stopRing(){clearInterval(rg);rg=null;const d=document.querySelector('.ckov');if(d)d.remove();try{navigator.vibrate&&navigator.vibrate(0)}catch(e){}}
function ring(ti,su,snz){stopRing();const d=document.createElement('div');d.className='ckov';d.innerHTML=`<div class="ckb"><div class="ckbell">⏰</div><h2>${esc(ti)}</h2><p class="mu">${esc(su||'')}</p>${snz?`<button class="btn" id="cks">💤 ${P('5 daqiqa','5 минут','5 dakika')}</button>`:''}<button class="btn pri" id="cko">${P('To‘xtatish','Стоп','Durdur')}</button></div>`;document.body.appendChild(d);let n=0;rg=setInterval(()=>{beep();try{navigator.vibrate&&navigator.vibrate(300)}catch(e){}if(++n>90)stopRing()},700);G('cko').onclick=stopRing;if(snz)G('cks').onclick=()=>{stopRing();setTimeout(()=>ring(ti,su,snz),3e5)}}
let lm='';setInterval(()=>{const n=new Date(),hm=z(n.getHours())+':'+z(n.getMinutes());if(lm!=dk(n)+hm){lm=dk(n)+hm;const w=n.getDay()||7;AL().forEach(a=>{if(a.on&&a.t==hm&&(!a.d||!a.d.length||a.d.includes(w))){if(!a.d||!a.d.length)a.on=false;save();ring(a.l||P('Budilnik','Будильник','Alarm'),a.t,1)}})}
if(tm.run&&Date.now()>=tm.end){tm.run=0;tm.rem=0;ring(P('Taymer tugadi','Таймер завершён','Zamanlayıcı bitti'),fmtT(tm.set));if(G('ckT'))body()}},1000);
function nextAl(){const n=new Date();let b=null;AL().forEach(a=>{if(!a.on)return;const[h,m]=a.t.split(':').map(Number);for(let o=0;o<8;o++){const c=new Date(n.getFullYear(),n.getMonth(),n.getDate()+o,h,m);if(c<=n)continue;if(a.d&&a.d.length&&!a.d.includes(c.getDay()||7))continue;if(!b||c<b)b=c;break}});if(!b)return'';const mn=Math.round((b-n)/6e4),d=Math.floor(mn/1440),h=Math.floor(mn%1440/60);return'⏰ '+P('','через ','')+(d?d+P(' kun ',' дн ',' gün '):'')+(h?h+P(' soat ',' ч ',' sa '):'')+mn%60+P(' daqiqadan keyin',' мин',' dk sonra')}
/* ko'rinishlar */
function face(id){let t='';for(let i=0;i<60;i++)t+=`<line x1="100" y1="8" x2="100" y2="${i%5?13:20}" class="${i%5?'t1':'t5'}" transform="rotate(${i*6} 100 100)"/>`;for(let i=1;i<=12;i++){const a=i*Math.PI/6;t+=`<text x="${(100+70*Math.sin(a)).toFixed(1)}" y="${(105-70*Math.cos(a)).toFixed(1)}">${i}</text>`}
return`<svg id="${id}" class="ckface" viewBox="0 0 200 200"><circle class="bg" cx="100" cy="100" r="96"/>${t}<line id="ckh" class="hh" x1="100" y1="100" x2="100" y2="58"/><line id="ckm" class="mh" x1="100" y1="100" x2="100" y2="36"/><line id="cks2" class="sh2" x1="100" y1="114" x2="100" y2="26"/><circle cx="100" cy="100" r="5" fill="#ef4444"/></svg>`}
const tabC=()=>{const n=new Date();return`<div class="ckcard">${face('ckA')}<div class="ckdg" id="ckd"></div><div class="ckdt">${WD[LI()][n.getDay()]}, ${n.getDate()} ${MN[LI()][n.getMonth()]} ${n.getFullYear()}</div><div class="cksm">${esc(Intl.DateTimeFormat().resolvedOptions().timeZone||'')}</div><div class="cksm">${nextAl()}</div></div>`};
const tabA=()=>`<div class="ckcard">${AL().length?[...AL()].sort((a,b)=>a.t<b.t?-1:1).map(a=>`<div class="alr${a.on?' on':''}"><div><b>${a.t}</b><small>${esc(a.l||'')} ${a.l?'· ':''}${dsc(a)}</small></div><button class="sw${a.on?' on':''}" data-a="asw" data-i="${a.id}"></button><button class="x" data-a="adel" data-i="${a.id}">✕</button></div>`).join(''):`<p class="mu" style="text-align:center">${P('Budilnik yo‘q','Будильников нет','Alarm yok')}</p>`}<div class="cksm">${nextAl()}</div></div>
<div class="ckcard"><b>＋ ${P('Yangi budilnik','Новый будильник','Yeni alarm')}</b><input type="time" id="aT" value="07:00" style="margin:.6rem 0"><input id="aL" placeholder="${P('Nomi (ixtiyoriy)','Название','Ad (isteğe bağlı)')}"><div class="dch">${WN[LI()].map((x,i)=>`<button data-a="ad" data-i="${i+1}" class="${ad.includes(i+1)?'on':''}">${x}</button>`).join('')}</div><button class="btn pri" data-a="aadd" style="width:100%">${P('Qo‘shish','Добавить','Ekle')}</button></div>`;
function wrows(n){const lo=-n.getTimezoneOffset()*6e4;return WC().map(nm=>{const c=CT.find(x=>x[0]==nm);if(!c)return'';const o=tzOff(c[1],n),d=new Date(n.getTime()+o),ld=new Date(n.getTime()+lo),df=Math.round((o-lo)/36e4)/10,dd=d.getUTCDate()==ld.getUTCDate()?P('Bugun','Сегодня','Bugün'):d>ld?P('Ertaga','Завтра','Yarın'):P('Kecha','Вчера','Dün'),h=d.getUTCHours();return`<div class="wcr"><i style="font-style:normal;font-size:1.5rem">${h>=6&&h<19?'☀️':'🌙'}</i><div><b>${nm}</b><small>${dd} · ${df==0?P('bir xil vaqt','то же время','aynı saat'):(df>0?'+':'')+df+' '+P('soat','ч','sa')}</small></div><strong>${z(h)}:${z(d.getUTCMinutes())}</strong><button class="x" data-a="wx" data-i="${nm}">✕</button></div>`}).join('')}
const tabW=()=>`<div class="ckcard" id="ckW">${wrows(new Date())}</div><div class="ckcard" style="display:flex;gap:.5rem"><select id="wS" style="flex:1">${CT.filter(c=>!WC().includes(c[0])).map(c=>`<option>${c[0]}</option>`).join('')}</select><button class="btn pri" data-a="wadd">＋</button></div>`;
function tabT(){const act=tm.run||tm.rem>0,h=Math.floor(tm.set/3600),m=Math.floor(tm.set%3600/60),s=tm.set%60;return`<div class="ckcard" id="ckT">`+(act?`<svg class="tring" viewBox="0 0 200 200"><circle cx="100" cy="100" r="88" fill="none" stroke="rgba(127,127,127,.25)" stroke-width="10"/><circle id="ckR" cx="100" cy="100" r="88" fill="none" style="stroke:var(--g3)" stroke-width="10" stroke-linecap="round" stroke-dasharray="552.9" transform="rotate(-90 100 100)"/><text id="ckTd" x="100" y="112"></text></svg>`:`<div class="tpk">${[['h',h,3600,P('soat','час','sa')],['m',m,60,P('min','мин','dk')],['s',s,1,P('sek','сек','sn')]].map(a=>`<div><button data-a="tu" data-i="${a[2]}">▲</button><b>${z(a[1])}</b><small>${a[3]}</small><button data-a="tu" data-i="-${a[2]}">▼</button></div>`).join('')}</div><div class="chips">${[[60,'1 min'],[300,'5 min'],[600,'10 min'],[900,'15 min'],[1800,'30 min'],[3600,'1 '+P('soat','час','sa')]].map(p=>`<button data-a="tp" data-i="${p[0]}">${p[1]}</button>`).join('')}</div>`)+`<div class="rbs"><button class="rb" data-a="trst">↺</button><button class="rb go" data-a="tgo">${tm.run?'⏸':'▶'}</button></div></div>`}
const tabS=()=>`<div class="ckcard"><div class="swd" id="ckS">${fmtS(el())}</div><div class="rbs"><button class="rb" data-a="srst">↺</button><button class="rb go" data-a="sgo">${sw.run?'⏸':'▶'}</button><button class="rb" data-a="slap">🏁</button></div>${sw.laps.map(l=>`<div class="lp"><span>#${l.n}</span><b>${fmtS(l.lap)}</b><span>${fmtS(l.tot)}</span></div>`).join('')}</div>`;
function tick(){const n=new Date();let live=0;const A=G('ckA');if(A){live=1;const s=n.getSeconds()+n.getMilliseconds()/1e3,m=n.getMinutes()+s/60,h=n.getHours()%12+m/60,r=(i,d)=>G(i).setAttribute('transform','rotate('+d+' 100 100)');r('ckh',h*30);r('ckm',m*6);r('cks2',s*6);G('ckd').textContent=z(n.getHours())+':'+z(n.getMinutes())+':'+z(n.getSeconds())}
if(G('ckW')){live=1;if(n.getSeconds()!=ls){ls=n.getSeconds();G('ckW').innerHTML=wrows(n)}}
if(G('ckS')){live=1;G('ckS').textContent=fmtS(el())}
if(G('ckTd')){live=1;const r=tm.run?Math.max(0,Math.ceil((tm.end-Date.now())/1e3)):tm.rem;G('ckTd').textContent=fmtT(r);G('ckR').style.strokeDashoffset=552.9*(1-(tm.set?r/tm.set:0))}
if(!live){clearInterval(ci);ci=0}}
function body(){const B=G('ckB');if(!B)return;B.innerHTML={c:tabC,a:tabA,w:tabW,t:tabT,s:tabS}[tab]();B.onclick=clk;if(!ci)ci=setInterval(tick,100);tick()}
function clk(e){const x=e.target.closest('[data-a]');if(!x)return;const a=x.dataset.a,i=x.dataset.i,now=Date.now();
if(a=='asw'){const o=AL().find(q=>q.id==i);o.on=!o.on;save();body()}else if(a=='adel'){D.set.alm=AL().filter(q=>q.id!=i);save();body()}
else if(a=='ad'){const v=+i;ad=ad.includes(v)?ad.filter(q=>q!=v):[...ad,v];x.classList.toggle('on')}
else if(a=='aadd'){AL().push({id:now,t:G('aT').value||'07:00',l:G('aL').value.trim(),on:true,d:[...ad].sort()});ad=[];save();body()}
else if(a=='wx'){D.set.wc=WC().filter(q=>q!=i);save();body()}else if(a=='wadd'){const v=G('wS').value;if(v){WC().push(v);save();body()}}
else if(a=='tu'){tm.set=Math.max(0,Math.min(359999,tm.set+ +i));body()}else if(a=='tp'){tm.set=+i;body()}
else if(a=='tgo'){if(tm.run){tm.rem=Math.max(1,Math.ceil((tm.end-now)/1e3));tm.run=0}else{if(!tm.rem)tm.rem=tm.set;if(tm.rem>0){tm.end=now+tm.rem*1e3;tm.run=1}}body()}else if(a=='trst'){tm.run=0;tm.rem=0;body()}
else if(a=='sgo'){if(sw.run){sw.acc+=now-sw.t0;sw.run=0}else{sw.t0=now;sw.run=1}body()}else if(a=='srst'){sw={run:0,t0:0,acc:0,laps:[]};body()}
else if(a=='slap'){const t=el();if(t){sw.laps.unshift({n:sw.laps.length+1,tot:t,lap:t-(sw.laps[0]?sw.laps[0].tot:0)});body()}}}
function vClock(){push(()=>P('Soat','Часы','Saat'),b=>{b.innerHTML=`<div class="cknav">${[['c','🕒',P('Soat','Часы','Saat')],['a','⏰',P('Budilnik','Будильник','Alarm')],['w','🌍',P('Dunyo','Мир','Dünya')],['t','⏳',P('Taymer','Таймер','Sayaç')],['s','⏱️',P('Sekund.','Секунд.','Kronom.')]].map(a=>`<button data-t="${a[0]}" class="${tab==a[0]?'on':''}"><i>${a[1]}</i>${a[2]}</button>`).join('')}</div><div id="ckB"></div>`;b.querySelector('.cknav').onclick=e=>{const x=e.target.closest('[data-t]');if(x){tab=x.dataset.t;draw()}};body()})}
/* bosh sahifa: jonli belgilar */
function home(){const n=new Date(),a=G('tmI'),c=G('clI'),s=G('clS');if(a){const L=dI(dk(n)),dn=L.filter(x=>x.done).length,tt=L.length,f=tt?dn/tt:(n.getHours()*60+n.getMinutes())/1440;a.innerHTML=`<svg viewBox="0 0 40 40" width="36" height="36"><circle cx="20" cy="20" r="16" fill="none" stroke="#fff5" stroke-width="4"/><circle cx="20" cy="20" r="16" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-dasharray="${(f*100.5).toFixed(1)} 100.5" transform="rotate(-90 20 20)"/><text x="20" y="24" text-anchor="middle" font-size="11" font-weight="800" fill="#fff">${tt?dn+'/'+tt:Math.round(f*100)+'%'}</text></svg>`}
if(c){const m=n.getMinutes()+n.getSeconds()/60,h=n.getHours()%12+m/60;c.innerHTML=`<svg viewBox="0 0 40 40" width="36" height="36"><circle cx="20" cy="20" r="17" fill="none" stroke="#fff" stroke-width="2.5"/><line x1="20" y1="20" x2="20" y2="11" stroke="#fff" stroke-width="3" stroke-linecap="round" transform="rotate(${h*30} 20 20)"/><line x1="20" y1="20" x2="20" y2="6" stroke="#fff" stroke-width="2" stroke-linecap="round" transform="rotate(${m*6} 20 20)"/><circle cx="20" cy="20" r="1.8" fill="#fff"/></svg>`}
if(s)s.textContent=z(n.getHours())+':'+z(n.getMinutes())+' · '+WD[LI()][n.getDay()]}
setInterval(home,1000);home();
/* profil rasmi */
window.pickPic=()=>{const i=document.createElement('input');i.type='file';i.accept='image/*';i.onchange=()=>{const f=i.files[0];if(!f)return;const u=URL.createObjectURL(f),im=new Image();im.onload=()=>{const c=document.createElement('canvas'),m=Math.min(im.width,im.height);c.width=c.height=256;c.getContext('2d').drawImage(im,(im.width-m)/2,(im.height-m)/2,m,m,0,0,256,256);D.set.pic=c.toDataURL('image/jpeg',.82);save();URL.revokeObjectURL(u);applyAll();draw()};im.src=u};i.click()};
const G9=GOM;GOM=function(){const o=G9();o.clock=vClock;return o};
applyAll();
})();
;
/* ===== Bosh sahifa: guruhlash ===== */
(function(){
const P=(a,b,c)=>(LI()>2&&window.XP&&XP[a]&&XP[a][LI()-3])||[a,b,c][I()],H=document.getElementById('home'),hero=H.querySelector('.hero');
const GR=[[["Reja va vaqt","Планы и время","Plan ve zaman"],['time','cal','clock'],0,['time']],
[["Ibodat va bilim","Вера и знания","İbadet ve bilgi"],['nmz','hemis'],0,['nmz','hemis']],
[["Qidiruv, AI va hisob","Поиск, ИИ и расчёты","Arama, YZ ve hesap"],['srch','ai','trn','beton'],0,[]],
[["Til va o‘qish","Языки и чтение","Dil ve okuma"],['langs','read','lessons','prava'],0,[]],
[["Media","Медиа","Medya"],['music','movies','clips','pics','poem'],0,['poem']],
[["Vositalar","Инструменты","Araçlar"],['calc','notes','exp'],1,[]]];
let last=hero;
GR.forEach(([h,ks,c3,cp])=>{const els=ks.map(k=>H.querySelector('[data-go="'+k+'"]')).filter(Boolean);if(!els.length)return;
const t=document.createElement('h4');t.className='hg';t.dataset.h=JSON.stringify(h);t.textContent=h[I()];
const s=document.createElement('section');s.className='grid grp'+(c3?' g3':'');
els.forEach(e=>{e.classList.remove('w','tc');if(cp.includes(e.dataset.go))e.classList.add('w','tc');s.appendChild(e)});
last.after(t);t.after(s);last=s});
H.querySelectorAll('section.grid').forEach(s=>{if(!s.children.length)s.remove()});{const bt=H.querySelector('[data-go="beton"]');if(bt&&bt.parentNode)bt.parentNode.classList.add('g4')}
const A1=applyAll;applyAll=function(){A1();H.querySelectorAll('.hg').forEach(h=>h.textContent=(window.hdT?hdT(JSON.parse(h.dataset.h)):JSON.parse(h.dataset.h)[I()]))};
/* Vaqt rejimi: keyingi vazifa */
const sm=H.querySelector('[data-go="time"] small');if(sm)sm.removeAttribute('data-k');
function nx(){if(!sm)return;const n=new Date(),hm=String(n.getHours()).padStart(2,'0')+':'+String(n.getMinutes()).padStart(2,'0'),L=dI(dk(n)),u=L.filter(x=>!x.done).sort((a,b)=>(a.time||'99')<(b.time||'99')?-1:1),nt=u.find(x=>x.time&&x.time>=hm)||u[0];
sm.textContent=!L.length?S.timeS[I()]:!u.length?'✅ '+P('Bugungi vazifalar bajarildi','Все задачи на сегодня выполнены','Bugünkü görevler tamam'):P('Keyingi','Далее','Sıradaki')+': '+(nt.time?nt.time+' · ':'')+nt.text}
setInterval(nx,5000);nx();applyAll();
})();
;
/* ===== Profil rasmi: bosib turib o'chirish (halqa to'lguncha), "Qaytarish" bilan ===== */
(function(){
const T=(a,b,c)=>[a,b,c][I()],HOLD=900;
window.picMenu=function(){window.pickPic()};            // oddiy bosish = rasmni almashtirish
let st=null,block=0;
function reset(el){if(!el)return;el.classList.remove('holding');el.style.removeProperty('--p');el.style.filter='';el.style.opacity='';el.style.transform='';}
function burst(el){const r=el.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,col=['#f87171','#fbbf24','#1cb0f6','#a78bfa','#34d399'];
 for(let i=0;i<18;i++){const d=document.createElement('i');d.style.cssText=`position:fixed;left:${cx}px;top:${cy}px;width:${6+Math.random()*6}px;height:${6+Math.random()*6}px;border-radius:50%;background:${col[i%5]};z-index:10001;pointer-events:none`;document.body.appendChild(d);
  const a=Math.random()*6.283,k=70+Math.random()*90;d.animate([{transform:'translate(-50%,-50%) scale(1)',opacity:1},{transform:`translate(calc(-50% + ${Math.cos(a)*k}px),calc(-50% + ${Math.sin(a)*k}px)) scale(.2)`,opacity:0}],{duration:650+Math.random()*250,easing:'cubic-bezier(.2,.7,.3,1)'}).onfinish=()=>d.remove()}}
function undoBar(old){const o=document.querySelector('.snk');if(o)o.remove();const n=document.createElement('div');n.className='snk';n.innerHTML='<span>🗑 '+T('Rasm olib tashlandi','Фото удалено','Fotoğraf kaldırıldı')+'</span><button>↩ '+T('Qaytarish','Вернуть','Geri al')+'</button>';document.body.appendChild(n);
 requestAnimationFrame(()=>n.classList.add('on'));let done=0;const close=()=>{n.classList.remove('on');setTimeout(()=>n.remove(),300)};
 n.querySelector('button').onclick=()=>{if(done)return;done=1;D.set.pic=old;save();applyAll();draw();close()};setTimeout(()=>{if(!done){done=1;close()}},6000)}
function finish(el){const old=D.set.pic;if(!old)return;block=Date.now();try{navigator.vibrate&&navigator.vibrate(40)}catch(e){}burst(el);
 el.animate([{transform:'scale(.85)',opacity:.4},{transform:'scale(.2)',opacity:0}],{duration:260,fill:'forwards'}).onfinish=()=>{delete D.set.pic;save();applyAll();draw();undoBar(old)}}
function stop(){if(!st)return;cancelAnimationFrame(st.raf);if(!st.done)reset(st.el);st=null}
document.addEventListener('pointerdown',e=>{const el=e.target.closest&&e.target.closest('.av.big');if(!el||!D.set.pic||st)return;
 if(!el.querySelector('.hr')){const r=document.createElement('span');r.className='hr';el.appendChild(r)}
 st={el,t0:performance.now(),x:e.clientX,y:e.clientY,done:0};
 const step=now=>{if(!st||st.el!==el)return;const p=Math.min(1,(now-st.t0)/HOLD);if(p>.12)el.classList.add('holding');el.style.setProperty('--p',p*100);el.style.filter=`blur(${p*3}px)`;el.style.opacity=1-p*.55;el.style.transform=`scale(${1-p*.08})`;
  if(p>=1){st.done=1;const s=st;st=null;reset(el);finish(el)}else st.raf=requestAnimationFrame(step)};
 st.raf=requestAnimationFrame(step)},true);
document.addEventListener('pointermove',e=>{if(st&&Math.hypot(e.clientX-st.x,e.clientY-st.y)>14)stop()},true);
['pointerup','pointercancel','pointerleave'].forEach(n=>document.addEventListener(n,stop,true));
document.addEventListener('contextmenu',e=>{if(e.target.closest&&e.target.closest('.av.big'))e.preventDefault()},true);
document.addEventListener('click',e=>{if(Date.now()-block<700&&e.target.closest&&e.target.closest('.av.big')){e.stopPropagation();e.preventDefault()}},true);
})();
