# AI javob (Claude) — sozlash

1. https://console.anthropic.com → API Keys → kalit yarating (hisobda balans kerak).
2. Supabase → Edge Functions → Deploy a new function → Via Editor → nomi: `ai-answer`
   → `supabase/functions/ai-answer/index.ts` ichidagini joylang → Deploy.
3. Edge Functions → Secrets → `ANTHROPIC_API_KEY` = kalitingiz.
4. Dasturda qidiring: natija tepasida «✨ AI javob» chiqadi. Ekrandagi tugma bilan o'chirib qo'yish mumkin.
Kalitni hech qachon index.html yoki GitHub'ga yozmang.
